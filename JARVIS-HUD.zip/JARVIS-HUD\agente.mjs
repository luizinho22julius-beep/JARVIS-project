// JARVIS — agente programador local e gratuito: o modelo do Ollama escreve código (Python, Lua/Luau, JavaScript...)
// numa pasta própria, executa para testar, e age direto no Roblox Studio pelo MCP oficial do Studio.
// Roda em segundo plano e manda o progresso ao HUD.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFile, execFileSync, spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";

export const PASTA_PROJETOS = path.join(os.homedir(), "JARVIS-Projetos");
const PASSOS_MAX = 24;
const BASE_BLENDER = path.join(path.dirname(fileURLToPath(import.meta.url)), "blender_base.py");

/** Acha o blender.exe mais novo instalado. */
export function acharBlender() {
  const raiz = path.join(process.env.ProgramFiles ?? "C:/Program Files", "Blender Foundation");
  try {
    return fs.readdirSync(raiz).map((v) => path.join(raiz, v, "blender.exe")).filter((f) => fs.existsSync(f)).sort().pop() ?? null;
  } catch {
    return null;
  }
}

// ---------- Roblox Studio (MCP) ----------

/** Acha o StudioMCP.exe da versão do Studio mais recente instalada. */
function executavelStudioMcp() {
  const versoes = path.join(os.homedir(), "AppData", "Local", "Roblox", "Versions");
  try {
    return fs.readdirSync(versoes)
      .map((v) => path.join(versoes, v, "StudioMCP.exe"))
      .filter((f) => fs.existsSync(f))
      .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0] ?? null;
  } catch {
    return null;
  }
}

// só as ferramentas do Studio que um agente de código precisa (menos ferramentas = modelo local mais certeiro)
const FERRAMENTAS_STUDIO = new Set([
  "get_studio_state", "search_game_tree", "inspect_instance", "script_search", "script_grep", "script_read",
  "multi_edit", "execute_luau", "get_console_output", "start_stop_play", "generate_procedural_model", "search_asset", "insert_asset",
]);

let studio = null; // { cliente, ferramentas }
export async function conectarStudio() {
  if (studio) return studio;
  const exe = executavelStudioMcp();
  if (!exe) throw new Error("Roblox Studio não está instalado neste PC.");
  const cliente = new Client({ name: "jarvis-hud", version: "1.0.0" });
  await cliente.connect(new StdioClientTransport({ command: exe, args: [], stderr: "ignore" }));
  const { tools } = await cliente.listTools();
  cliente.onclose = () => { studio = null; };
  studio = { cliente, ferramentas: tools.filter((t) => FERRAMENTAS_STUDIO.has(t.name)) };
  return studio;
}

// ---------- ferramentas locais (sempre dentro da pasta de projetos) ----------

function caminhoSeguro(relativo) {
  const alvo = path.resolve(PASTA_PROJETOS, String(relativo ?? ""));
  const rel = path.relative(PASTA_PROJETOS, alvo);
  if (rel.startsWith("..") || path.isAbsolute(rel)) throw new Error("Só posso mexer em arquivos dentro da pasta JARVIS-Projetos.");
  return alvo;
}

export function acharPython() {
  const candidatos = [path.join(os.homedir(), "AppData", "Local", "Python", "bin", "python.exe"), "python", "py"];
  for (const c of candidatos) {
    try { execFileSync(c, ["--version"], { stdio: "ignore", timeout: 5000 }); return c; } catch {}
  }
  return null;
}
function acharLua() {
  for (const c of ["lua", "luajit", "luau", "lua54"]) {
    try { execFileSync(c, ["-v"], { stdio: "ignore", timeout: 5000 }); return c; } catch {}
  }
  return null;
}

const FERRAMENTAS_LOCAIS = [
  {
    type: "function",
    function: {
      name: "criar_arquivo",
      description: "Cria ou substitui um arquivo de código dentro da pasta de projetos. Use caminhos relativos, como 'jogo/main.py'.",
      parameters: { type: "object", properties: { caminho: { type: "string" }, conteudo: { type: "string" } }, required: ["caminho", "conteudo"] },
    },
  },
  {
    type: "function",
    function: {
      name: "ler_arquivo",
      description: "Lê um arquivo da pasta de projetos.",
      parameters: { type: "object", properties: { caminho: { type: "string" } }, required: ["caminho"] },
    },
  },
  {
    type: "function",
    function: { name: "listar_arquivos", description: "Lista os arquivos da pasta de projetos.", parameters: { type: "object", properties: {} } },
  },
  {
    type: "function",
    function: {
      name: "executar_codigo",
      description: "Executa um arquivo (Python .py, JavaScript .js ou Lua .lua) e devolve a saída e os erros, para testar o código. Luau de Roblox não roda aqui: use execute_luau do Roblox Studio.",
      parameters: { type: "object", properties: { caminho: { type: "string" }, entrada: { type: "string", description: "Texto opcional enviado na entrada padrão" } }, required: ["caminho"] },
    },
  },
  {
    type: "function",
    function: {
      name: "blender",
      description: "Cria um modelo 3D no Blender. O script já tem estas funções prontas (use-as; não importe nada; não limpe a cena; não crie câmera nem luz; não salve): material(nome, cor=(r,g,b), metal=0, rugosidade=0.5, emissao=0) | cubo(nome, tamanho=(larg,prof,alt), pos=(x,y,z), rot=(rx,ry,rz), cor, chanfro=0) | cilindro(nome, raio, altura, pos, rot, cor, chanfro=0, lados=32) | esfera(nome, raio, pos, cor, escala=(1,1,1)) | cone(nome, raio, raio_topo=0, altura, pos, rot, cor) | toro(nome, raio, espessura, pos, rot, cor) | plano(nome, tamanho, pos, cor) | repetir(obj, quantidade, deslocamento=(dx,dy,dz)) | espelhar(obj, eixo='X') | subdividir(obj, nivel=2) | girar_copias([objs], quantidade, centro=(0,0,0)). Unidades em metros, Z para cima, chão em z=0 e pos é o CENTRO do objeto; rotações em radianos (math.radians). 'cor' aceita (r,g,b) de 0 a 1 ou um material. O sistema enquadra, gera a prévia, salva .blend e exporta .glb, e devolve a saída ou o erro.",
      parameters: { type: "object", properties: { nome: { type: "string", description: "nome curto do modelo, sem espaços (ex.: casa_moderna)" }, script: { type: "string", description: "código Python bpy completo" } }, required: ["nome", "script"] },
    },
  },
];

export async function rodarBlender(nome, script) {
  const blender = acharBlender();
  if (!blender) return "O Blender não está instalado neste PC.";
  const limpo = String(nome || "modelo").replace(/[^\w-]+/g, "_").slice(0, 40) || "modelo";
  const pasta = path.join(PASTA_PROJETOS, "blender");
  fs.mkdirSync(pasta, { recursive: true });
  const arquivoScript = path.join(pasta, limpo + ".py");
  fs.writeFileSync(arquivoScript, String(script ?? ""));
  const base = path.join(pasta, limpo);
  return await new Promise((ok) => {
    execFile(blender, ["--background", "--factory-startup", "--python-exit-code", "1", "--python", BASE_BLENDER, "--", arquivoScript, base],
      { timeout: 420000, maxBuffer: 4 << 20, windowsHide: true }, (erro, saida, erros) => {
        const log = `${saida}\n${erros}`;
        if (/JARVIS_OK/.test(log)) return ok({ ok: true, texto: `Modelo pronto: ${limpo}.blend, ${limpo}.glb e prévia ${limpo}.png em ${pasta}. ${log.match(/JARVIS_OK.*/)[0]}`, nome: limpo });
        const linhasErro = log.split("\n").filter((l) => /Error|Traceback|JARVIS_ERRO|line \d+/.test(l)).slice(-12).join("\n");
        ok({ ok: false, texto: `ERRO no Blender${erro?.killed ? " (tempo esgotado)" : ""}:\n${linhasErro || log.slice(-1500)}` });
      });
  });
}

/** Abre um modelo salvo na interface do Blender. */
export function abrirNoBlender(nome) {
  const blender = acharBlender();
  const arquivo = path.join(PASTA_PROJETOS, "blender", String(nome).replace(/[^\w-]+/g, "_") + ".blend");
  if (!blender || !fs.existsSync(arquivo)) return false;
  spawn(blender, [arquivo], { detached: true, stdio: "ignore" }).unref();
  return true;
}

async function executarLocal(nome, args) {
  if (nome === "blender") return rodarBlender(args.nome, args.script);
  if (nome === "criar_arquivo") {
    const alvo = caminhoSeguro(args.caminho);
    fs.mkdirSync(path.dirname(alvo), { recursive: true });
    fs.writeFileSync(alvo, String(args.conteudo ?? ""));
    return `Arquivo salvo: ${path.relative(PASTA_PROJETOS, alvo)} (${String(args.conteudo ?? "").split("\n").length} linhas)`;
  }
  if (nome === "ler_arquivo") return fs.readFileSync(caminhoSeguro(args.caminho), "utf8").slice(0, 12000);
  if (nome === "listar_arquivos") {
    const lista = [];
    const andar = (dir) => { for (const f of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, f.name); f.isDirectory() ? andar(p) : lista.push(path.relative(PASTA_PROJETOS, p)); } };
    andar(PASTA_PROJETOS);
    return lista.length ? lista.slice(0, 200).join("\n") : "(pasta vazia)";
  }
  if (nome === "executar_codigo") {
    const alvo = caminhoSeguro(args.caminho);
    const ext = path.extname(alvo).toLowerCase();
    const interprete = ext === ".py" ? acharPython() : ext === ".js" || ext === ".mjs" ? process.execPath : ext === ".lua" ? acharLua() : null;
    if (!interprete) return ext === ".lua" ? "Não há interpretador Lua instalado neste PC. Para Luau, teste no Roblox Studio com execute_luau." : `Não sei executar arquivos ${ext}.`;
    return await new Promise((ok) => {
      const p = execFile(interprete, [alvo], { cwd: path.dirname(alvo), timeout: 30000, maxBuffer: 1 << 20, windowsHide: true }, (erro, saida, erros) => {
        const texto = `${saida}${erros ? `\n[erros]\n${erros}` : ""}`.trim() || "(sem saída)";
        ok((erro?.killed ? "[tempo esgotado após 30 s]\n" : erro && !erros ? `[código de saída ${erro.code}]\n` : "") + texto.slice(-4000));
      });
      if (args.entrada) p.stdin.end(String(args.entrada)); else p.stdin.end();
    });
  }
  throw new Error(`Ferramenta desconhecida: ${nome}`);
}

// ---------- o agente ----------

const SISTEMA = `Você é o agente programador do J.A.R.V.I.S., um engenheiro de software sênior trabalhando sozinho no PC do usuário (Windows).
Regras:
- Resolva a tarefa de ponta a ponta usando as ferramentas. Não pergunte nada ao usuário: tome decisões sensatas.
- Código completo, limpo e funcional, com comentários curtos em português. Nada de reticências ou "complete aqui".
- Arquivos (Python, JavaScript, Lua...) vão na pasta de projetos com criar_arquivo. Sempre que possível execute com executar_codigo, leia os erros e corrija até funcionar.
- Roblox: use as ferramentas do Roblox Studio. Primeiro get_studio_state e search_game_tree para entender o jogo; depois crie ou edite com execute_luau (ex.: Instance.new("Script") com .Source, peças, UI) ou multi_edit em scripts existentes. Luau moderno: game:GetService, task.wait, task.spawn, tipos quando útil. Scripts de servidor em ServerScriptService, locais em StarterPlayerScripts/StarterGui, módulos em ReplicatedStorage. Confira o resultado com get_console_output ou inspect_instance.
- Blender: para qualquer modelo 3D use a ferramenta blender e monte o modelo com as funções prontas do kit (cubo, cilindro, esfera, cone, toro, plano, material, repetir, espelhar, subdividir, girar_copias), que já funcionam no Blender 5.2. Exemplo de mesa: madeira = material("Madeira", (0.45, 0.27, 0.12)); cubo("Tampo", (1.6, 0.9, 0.05), (0, 0, 0.75), cor=madeira, chanfro=0.01); depois as pernas com cilindro. Proporções reais em metros, chanfro nas quinas, cores bonitas, e capriche nos detalhes (várias peças). Só use bpy direto para algo que o kit não faz. Se der erro, leia a mensagem, corrija e rode de novo.
  Regras de posição (pos é o CENTRO da peça): peça apoiada no chão com altura h fica em z = h/2; peça em cima de outra fica em z = topo_da_de_baixo + h/2; pernas ficam DEBAIXO do tampo/assento, nos cantos, recuadas da borda. Antes do código, escreva num comentário as medidas principais e calcule cada z. Monte UM objeto completo (ex.: uma cadeira inteira, com assento, encosto e 4 pernas encostando no assento) e só depois copie com girar_copias ou repetir.
  Exemplo completo de mesa com 4 cadeiras:
  madeira = material("Madeira", (0.45, 0.27, 0.12)); tecido = material("Tecido", (0.15, 0.25, 0.55))
  # mesa: pernas 0.72 m (z=0.36), tampo 0.05 m em cima (z=0.72+0.025)
  cubo("Tampo", (1.6, 0.9, 0.05), (0, 0, 0.745), cor=madeira, chanfro=0.01)
  for x in (-0.72, 0.72):
      for y in (-0.38, 0.38): cilindro("Perna", 0.03, 0.72, (x, y, 0.36), cor=madeira)
  # cadeira em y=-0.75: pernas 0.43 (z=0.215), assento em z=0.455, encosto 0.5 acima do assento (z=0.48+0.25)
  partes = [cubo("Assento", (0.45, 0.45, 0.05), (0, -0.75, 0.455), cor=tecido, chanfro=0.01), cubo("Encosto", (0.45, 0.05, 0.5), (0, -0.95, 0.73), cor=madeira, chanfro=0.01)]
  partes += [cilindro("PernaCadeira", 0.02, 0.43, (px, py, 0.215), cor=madeira) for px in (-0.19, 0.19) for py in (-0.56, -0.94)]
  girar_copias(partes, quantidade=4)
- Se o Roblox Studio não estiver conectado, salve o código Luau como arquivo .luau na pasta de projetos e explique como colar no Studio.
- Ao terminar, responda só com um resumo de uma a três frases em português do Brasil, sem markdown, sem código e sem listas, porque será falado em voz alta.`;

let emAndamento = null;

export function agenteOcupado() {
  return Boolean(emAndamento);
}

export function cancelarTarefa() {
  if (!emAndamento) return false;
  emAndamento.cancelado = true;
  emAndamento.controle.abort();
  return true;
}

/** Frase curta para o painel do HUD. */
function descrever(nome, args) {
  if (nome === "criar_arquivo") return `Escrevendo ${args.caminho}`;
  if (nome === "ler_arquivo") return `Lendo ${args.caminho}`;
  if (nome === "listar_arquivos") return "Conferindo os arquivos";
  if (nome === "executar_codigo") return `Executando ${args.caminho}`;
  if (nome === "blender") return `Blender: modelando ${args.nome}`;
  if (nome === "execute_luau") return "Roblox Studio: executando Luau";
  return `Roblox Studio: ${nome.replace(/_/g, " ")}`;
}

/**
 * Inicia uma tarefa em segundo plano. `emitir(evento, dados)` manda ao HUD:
 *  agente {etapa}, codigo {arquivo, linguagem, conteudo}, agente-fim {ok, resumo}.
 */
export function iniciarTarefa({ tarefa, roblox, modelo, ollama, emitir }) {
  if (emAndamento) return { ok: false, motivo: "ocupado" };
  fs.mkdirSync(PASTA_PROJETOS, { recursive: true });
  const estado = { controle: new AbortController(), cancelado: false };
  emAndamento = estado;
  const inicio = Date.now();

  (async () => {
    let ferramentasStudio = [];
    if (roblox) {
      emitir("agente", { etapa: "Conectando ao Roblox Studio…", tarefa, inicio: true });
      try {
        const s = await conectarStudio();
        ferramentasStudio = s.ferramentas;
        const r = await s.cliente.callTool({ name: "get_studio_state", arguments: {} });
        if (r.isError) emitir("agente", { etapa: "Roblox Studio fechado ou sem lugar aberto: vou salvar o código em arquivo." });
      } catch (erro) {
        emitir("agente", { etapa: `Sem Roblox Studio (${erro.message}). Vou salvar o código em arquivo.` });
      }
    } else {
      emitir("agente", { etapa: "Planejando o código…", tarefa, inicio: true });
    }

    const ferramentas = [
      ...FERRAMENTAS_LOCAIS,
      ...ferramentasStudio.map((t) => ({ type: "function", function: { name: t.name, description: (t.description ?? "").slice(0, 600), parameters: t.inputSchema ?? { type: "object", properties: {} } } })),
    ];
    const mensagens = [
      { role: "system", content: SISTEMA },
      { role: "user", content: `Pasta de projetos: ${PASTA_PROJETOS}\nRoblox Studio ${ferramentasStudio.length ? "conectado" : "não conectado"}.\n\nTarefa: ${tarefa}` },
    ];

    let resumo = "";
    for (let passo = 0; passo < PASSOS_MAX && !estado.cancelado; passo++) {
      const r = await fetch(`${ollama}/api/chat`, {
        method: "POST",
        signal: estado.controle.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: modelo, messages: mensagens, tools: ferramentas, stream: false, think: false, keep_alive: "60m", options: { num_ctx: 8192, temperature: 0.25 } }),
      });
      if (!r.ok) throw new Error(`Ollama ${r.status}: ${(await r.text()).slice(0, 200)}`);
      const { message } = await r.json();
      delete message.thinking; // o raciocínio não precisa voltar no histórico
      mensagens.push(message);
      const chamadas = message.tool_calls ?? [];
      if (!chamadas.length) { resumo = (message.content ?? "").trim(); break; }

      for (const c of chamadas) {
        const nome = c.function?.name;
        let args = c.function?.arguments ?? {};
        if (typeof args === "string") { try { args = JSON.parse(args); } catch { args = {}; } }
        emitir("agente", { etapa: descrever(nome, args) });
        // mostra o código no HUD enquanto é escrito
        const codigo = nome === "criar_arquivo" ? args.conteudo : nome === "execute_luau" ? args.code ?? args.source ?? args.luau : null;
        if (codigo) emitir("codigo", { arquivo: nome === "criar_arquivo" ? args.caminho : "Roblox Studio · execute_luau", linguagem: nome === "execute_luau" ? "luau" : path.extname(String(args.caminho)).slice(1), conteudo: String(codigo).slice(0, 8000) });
        let resultado;
        try {
          if (FERRAMENTAS_LOCAIS.some((f) => f.function.name === nome)) resultado = await executarLocal(nome, args);
          if (resultado && typeof resultado === "object") {
            if (resultado.ok) emitir("modelo", { nome: resultado.nome, previa: `/projetos/blender/${resultado.nome}.png?t=${Date.now()}` });
            emitir("agente", { etapa: resultado.ok ? `Modelo 3D pronto: ${resultado.nome}` : "Blender acusou erro, corrigindo…" });
            resultado = resultado.texto;
          }
          else if (studio && ferramentasStudio.some((t) => t.name === nome)) {
            const r2 = await studio.cliente.callTool({ name: nome, arguments: args });
            resultado = (r2.content ?? []).map((b) => (b.type === "text" ? b.text : `[${b.type}]`)).join("\n");
            if (r2.isError) resultado = `ERRO: ${resultado}`;
          } else resultado = `ERRO: ferramenta ${nome} indisponível.`;
        } catch (erro) {
          resultado = `ERRO: ${erro.message ?? erro}`;
        }
        if (nome === "executar_codigo" || nome === "get_console_output") emitir("agente", { etapa: `Saída: ${String(resultado).split("\n").find((l) => l.trim())?.slice(0, 100) ?? "(vazia)"}` });
        mensagens.push({ role: "tool", tool_name: nome, content: String(resultado).slice(0, 6000) });
      }
    }
    return resumo;
  })()
    .then((resumo) => {
      const segundos = Math.round((Date.now() - inicio) / 1000);
      if (estado.cancelado) return emitir("agente-fim", { ok: false, resumo: "Tarefa de programação cancelada, senhor.", segundos });
      const limpo = resumo.replace(/<think>[\s\S]*?<\/think>/g, "").replace(/```[\s\S]*?```/g, "").replace(/[`*#_>]/g, "").replace(/\s+/g, " ").trim();
      emitir("agente-fim", { ok: true, resumo: limpo || "Tarefa de programação concluída.", segundos, pasta: PASTA_PROJETOS });
    })
    .catch((erro) => {
      if (estado.cancelado) return emitir("agente-fim", { ok: false, resumo: "Tarefa de programação cancelada, senhor." });
      console.error("Agente programador falhou:", erro.message ?? erro);
      emitir("agente-fim", { ok: false, resumo: "O agente programador encontrou um problema e parou. Os detalhes estão na janela do servidor." });
    })
    .finally(() => { emAndamento = null; });

  return { ok: true };
}
