// JARVIS — fluxos rápidos do agente programador: o modelo escreve o código de uma vez (aparece ao vivo no HUD),
// o sistema executa na hora e só volta ao modelo se der erro. Bem mais rápido que o agente com várias idas e voltas.
import fs from "node:fs";
import path from "node:path";
import { execFile, execFileSync } from "node:child_process";
import { PASTA_PROJETOS, rodarBlender, acharPython, conectarStudio } from "./agente.mjs";

const TENTATIVAS = 3;

const KIT_BLENDER = `Funções prontas do kit (já disponíveis; não importe nada, não limpe a cena, não crie câmera, luz nem salve):
material(nome, cor=(r,g,b), metal=0, rugosidade=0.5, emissao=0)
cubo(nome, tamanho=(larg,prof,alt), pos=(x,y,z), rot=(rx,ry,rz), cor, chanfro=0)
cilindro(nome, raio, altura, pos, rot, cor, chanfro=0, lados=32)
esfera(nome, raio, pos, cor, escala=(1,1,1))
cone(nome, raio, raio_topo=0, altura, pos, rot, cor)
toro(nome, raio, espessura, pos, rot, cor)
plano(nome, tamanho, pos, cor)
repetir(obj, quantidade, deslocamento=(dx,dy,dz)) | espelhar(obj, eixo='X') | subdividir(obj, nivel=2)
girar_copias([objs], quantidade, centro=(0,0,0))   # copia em volta do eixo Z
Metros, Z para cima, chão em z=0. pos de primitiva é o CENTRO da peça: apoiada no chão com altura h fica em z=h/2. Rotações de primitivas em radianos (math.radians). 'cor' aceita (r,g,b) de 0 a 1 ou um material.
MATERIAIS REALISTAS: material(nome, cor, tipo=...) com tipo madeira, metal, vidro, tecido, pintura (carro), concreto, tijolo, grama, borracha ou telha; o tipo também é deduzido do nome ("Madeira", "Vidro", "Pneu"...). Pense na textura certa de cada peça.
ENCAIXE (use sempre que uma peça fica em cima de outra, nada flutua): sobre(base, obj, dx=0, dy=0) apoia obj em cima de base | no_chao(obj, ...) apoia no chão | topo(obj) dá o z mais alto.

PEÇAS PRONTAS (já montadas e bonitas; prefira SEMPRE estas quando servirem). pos=(x,y) no chão, rot em GRAUS, cor=(r,g,b) opcional; cada uma devolve um objeto pai:
mesa(pos, rot, largura=1.6, profundidade=0.9, altura=0.75, cor) | cadeira(pos, rot, cor, cor_assento)  # cadeira olha para +Y; rot gira
sofa(pos, rot, largura=2.0, cor) | cama(pos, rot, largura=1.6, comprimento=2.0, cor, cor_lencol) | estante(pos, rot, largura=1.0, altura=1.8, prateleiras=5, cor)
luminaria(pos, rot, altura=0.55, cor, cor_cupula) | casa(pos, rot, largura=8, profundidade=6, altura=3, cor, cor_telhado) | predio(pos, rot, andares=10, largura=10, profundidade=10, cor)
arvore(pos, altura=4, cor_folhas) | carro(pos, rot, cor, tipo='sedan'|'suv'|'esportivo'|'picape')  # carro realista com lataria curva, rodas, faróis | poste(pos, rot, altura=5) | pessoa(pos, rot, altura=1.75, cor) | garagem(pos, rot, vagas=2, cor)  # garagem aberta em +X; vaga k no y = -vagas*1.5 + 1.5 + k*3
OBJETOS REAIS (fotorrealistas, preferidos para coisas que existem na vida real): modelo_real(busca, pos, rot, altura=None, comprimento=None)  # baixa um modelo 3D real gratuito (moto, avião, cavalo, personagem, móvel, comida...); busca em INGLÊS, ex.: modelo_real("motorcycle", (0,0), 0, comprimento=2.1) | objeto_real(busca, pos, rot, altura=None)  # objeto escaneado (sofá, poltrona, planta, mesa, barril, pedra...)
CENÁRIO: ambiente(nome) com nome estacionamento, rua, cidade, garagem, estudio, campo, floresta, por_do_sol, noite ou interior  # fundo de foto real 360° e chão real; chame uma vez no começo (não crie chão com plano() quando usar ambiente)

Exemplo (sala de jantar):
plano("Chao", 8)
m = mesa((0, 0))
for k in range(4):
    a = math.radians(90 * k)
    cadeira((-math.sin(a) * 0.75, -math.cos(a) * 0.75), rot=-90 * k)   # cadeiras em volta, viradas para a mesa
sobre(m, luminaria((0, 0)))   # luminária EM CIMA da mesa
Exemplo (objeto novo feito de primitivas):
corpo = cilindro("Corpo", 0.4, 1.2, (0, 0, 0.6), cor=(0.8, 0.1, 0.1))
sobre(corpo, cone("Topo", 0.4, 0, 0.5, cor=(0.9, 0.9, 0.9)))`;

const SISTEMA_BLENDER = `Você modela objetos 3D no Blender escrevendo um script Python curto que usa o kit abaixo.
${KIT_BLENDER}
Responda SOMENTE com o código Python, sem markdown e sem explicações, em no máximo 45 linhas. Use as PEÇAS PRONTAS sempre que o pedido tiver algo parecido (combine várias para montar cenas) e primitivas com sobre() para o resto. Comece com UMA linha de comentário com o plano. Capriche: proporções reais, cores bonitas, nada flutuando.
REGRAS DE CENA: use só as peças que o pedido menciona (não use predio, casa ou arvore se não foram pedidos); carros, pessoas e móveis ficam SEMPRE no chão, lado a lado, com 1 a 2 m de espaço entre eles (calcule x e y para não se sobreporem); sobre() é só para coisas pequenas em cima de móveis (luminária na mesa, objeto na estante). Uma garagem é um piso de concreto com paredes finas de cubo e um teto, aberta na frente, com os carros dentro.`;

const SISTEMA_CODIGO = `Você é um programador sênior. Escreva um programa completo, limpo e funcional para o pedido, com comentários curtos em português.
A PRIMEIRA linha deve ser um comentário com o nome do arquivo: "# arquivo: nome.py" (Python, o padrão), "// arquivo: nome.js" (JavaScript) ou "-- arquivo: nome.lua" (Lua).
Se o programa precisar de dados, use exemplos embutidos em vez de pedir ao usuário. Responda SOMENTE com o código, sem markdown e sem explicações.`;

const SISTEMA_ROBLOX = `Você é especialista em Roblox Studio e Luau. Escreva UM trecho de Luau que será executado AGORA no Studio (modo Edit, contexto de plugin) e que faz o pedido diretamente:
- crie ou altere instâncias com Instance.new, propriedades e Parent (Workspace, ServerScriptService, StarterGui, ReplicatedStorage, StarterPlayer.StarterPlayerScripts...);
- se o pedido envolver comportamento no jogo, crie Script/LocalScript/ModuleScript e coloque o código do jogo na propriedade Source (string longa [==[ ... ]==]);
- use game:GetService, Luau moderno (task.wait, task.spawn) e nomes claros em português;
- comece com local CHS = game:GetService("ChangeHistoryService"); local gravacao = CHS:TryBeginRecording("JARVIS") e termine com CHS:FinishRecording(gravacao, Enum.FinishRecordingOperation.Commit), para o usuário poder desfazer;
- a ÚLTIMA linha deve ser: return "<resumo curto em português do que foi criado>".
Responda SOMENTE com o código Luau, sem markdown e sem explicações.`;

// ---------- caminho rápido: modelo pronto do Sketchfab, sem escrever código ----------
const AMBIENTES = ["estacionamento", "rua", "cidade", "garagem", "estudio", "campo", "floresta", "por_do_sol", "noite", "interior"];
const SISTEMA_PEDIDO = `Converta o pedido de modelo 3D em JSON.
"itens": as coisas concretas pedidas (no máximo 5), cada uma com:
  "busca": nome curto EM INGLÊS para achar o modelo 3D pronto (ex.: "dragon", "f-16 fighter jet", "wooden chair", "iron man suit", "horse"); mantenha marcas e modelos citados (ex.: "lamborghini aventador");
  "altura": altura real típica em metros (ex.: cadeira 0.9, carro 1.5, cavalo 1.7, avião 5, prédio 30, celular 0.15);
  "quantidade": de 1 a 4.
"ambiente": onde a coisa costuma estar: ${AMBIENTES.join(", ")} (estudio para objetos pequenos, personagens e coisas sem lugar).
"procedural": true SOMENTE se o pedido mandar modelar do zero, com código ou primitivas, ou for algo abstrato/geométrico (ex.: "um cubo", "uma espiral", "formas geométricas"). Senão false.`;
const ESQUEMA_PEDIDO = {
  type: "object",
  properties: {
    itens: { type: "array", items: { type: "object", properties: { busca: { type: "string" }, altura: { type: "number" }, quantidade: { type: "integer" } }, required: ["busca", "altura", "quantidade"] } },
    ambiente: { type: "string", enum: AMBIENTES },
    procedural: { type: "boolean" },
  },
  required: ["itens", "ambiente", "procedural"],
};

function temTokenSketchfab() {
  if (process.env.SKETCHFAB_TOKEN) return true;
  try {
    const saida = execFileSync("reg", ["query", "HKCU\\Environment", "/v", "SKETCHFAB_TOKEN"], { encoding: "utf8", windowsHide: true });
    return /SKETCHFAB_TOKEN\s+REG_\w+\s+\S{10,}/.test(saida);
  } catch { return false; }
}

async function interpretarPedido({ ollama, modelo, tarefa, sinal }) {
  const r = await fetch(`${ollama}/api/chat`, {
    method: "POST",
    signal: sinal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: modelo, stream: false, think: false, keep_alive: "60m", format: ESQUEMA_PEDIDO,
      messages: [{ role: "system", content: SISTEMA_PEDIDO }, { role: "user", content: tarefa }], options: { temperature: 0, num_ctx: 4096, num_predict: 300 } }),
  });
  const dados = await r.json();
  const pedido = JSON.parse(dados.message?.content ?? "{}");
  pedido.itens = (pedido.itens ?? []).filter((i) => i?.busca).slice(0, 5);
  return pedido;
}

/** Script Python que monta a cena só com modelos reais (Sketchfab), lado a lado, no cenário certo. */
function scriptReal(pedido) {
  const linhas = [`# modelos reais do Sketchfab: ${pedido.itens.map((i) => i.busca).join(", ")}`, `ambiente(${JSON.stringify(pedido.ambiente || "estudio")})`, "pecas = []"];
  for (const item of pedido.itens) {
    const n = Math.max(1, Math.min(4, Number(item.quantidade) || 1));
    const altura = Math.max(0.02, Math.min(200, Number(item.altura) || 1));
    for (let k = 0; k < n; k++) linhas.push(`pecas.append(modelo_real(${JSON.stringify(item.busca)}, (0, 0), 0, altura=${altura}))`);
  }
  linhas.push("lado_a_lado(*pecas)");
  return linhas.join("\n");
}

/** Tira cercas de markdown e texto solto em volta do código. */
function limparCodigo(texto) {
  const cerca = texto.match(/```[\w-]*\n([\s\S]*?)```/);
  return (cerca ? cerca[1] : texto.replace(/```[\w-]*/g, "")).replace(/<think>[\s\S]*?<\/think>/g, "").trim();
}

/** Pede o código ao Ollama em fluxo, mostrando no HUD enquanto é escrito. */
async function gerar({ ollama, modelo, mensagens, sinal, aoParcial, pensar = false }) {
  const r = await fetch(`${ollama}/api/chat`, {
    method: "POST",
    signal: sinal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: modelo, messages: mensagens, stream: true, think: pensar, keep_alive: "60m", options: { num_ctx: 8192, temperature: 0.25, num_predict: pensar ? 6000 : 2200 } }),
  });
  if (!r.ok) throw new Error(`Ollama ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const leitor = r.body.getReader();
  const dec = new TextDecoder();
  let sobra = "", texto = "", ultimoEnvio = 0;
  for (;;) {
    const { value, done } = await leitor.read();
    if (done) break;
    sobra += dec.decode(value, { stream: true });
    let n;
    while ((n = sobra.indexOf("\n")) >= 0) {
      const linha = sobra.slice(0, n).trim();
      sobra = sobra.slice(n + 1);
      if (!linha) continue;
      const pedaco = JSON.parse(linha);
      if (pedaco.error) throw new Error(`Ollama: ${pedaco.error}`);
      texto += pedaco.message?.content ?? "";
      if (Date.now() - ultimoEnvio > 250) { ultimoEnvio = Date.now(); aoParcial(limparCodigo(texto)); }
    }
  }
  const codigo = limparCodigo(texto);
  aoParcial(codigo);
  return codigo;
}

function nomeDoPedido(tarefa) {
  const ignorar = /^(jarvis|crie|cria|criar|faça|faca|fazer|um|uma|no|na|de|do|da|em|para|modelo|3d|blender|me|por|favor|script|programa)$/i;
  const palavras = tarefa.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().split(/[^a-z0-9]+/).filter((p) => p && !ignorar.test(p));
  return palavras.slice(0, 3).join("_") || "modelo";
}

function executar(arquivo) {
  const ext = path.extname(arquivo);
  const interprete = ext === ".py" ? acharPython() : ext === ".js" ? process.execPath : null;
  if (!interprete) return Promise.resolve(null);
  return new Promise((ok) => {
    const p = execFile(interprete, [arquivo], { cwd: path.dirname(arquivo), timeout: 20000, maxBuffer: 1 << 20, windowsHide: true }, (erro, saida, erros) => {
      ok({ ok: !erro, saida: `${saida}${erros ? `\n${erros}` : ""}`.trim().slice(-3000), tempo: erro?.killed });
    });
    p.stdin.end();
  });
}

// programas interativos ou que não terminam sozinhos não são executados no teste
const INTERATIVO = /\binput\s*\(|tkinter|pygame|turtle|while\s+True|readline|process\.stdin|\.listen\(|flask|app\.run|setInterval/;

let tarefaRapida = null;
export function rapidoOcupado() { return Boolean(tarefaRapida); }
export function cancelarRapido() { if (!tarefaRapida) return false; tarefaRapida.abort(); return true; }

/** tipo: "blender" | "roblox" | "codigo". Avisa o HUD com agente/codigo/modelo/agente-fim. */
export function iniciarRapido({ tipo, tarefa, modelo, ollama, emitir }) {
  if (tarefaRapida) return { ok: false };
  const controle = new AbortController();
  tarefaRapida = controle;
  const inicio = Date.now();
  const etapa = (t) => emitir("agente", { etapa: t });
  const fim = (ok, resumo) => emitir("agente-fim", { ok, resumo, segundos: Math.round((Date.now() - inicio) / 1000), pasta: PASTA_PROJETOS });

  (async () => {
    fs.mkdirSync(PASTA_PROJETOS, { recursive: true });
    emitir("agente", { etapa: "Escrevendo o código…", tarefa, inicio: true });

    if (tipo === "blender") {
      const nome = nomeDoPedido(tarefa);
      // 1º: modelo pronto e real do Sketchfab (rápido, sem o modelo de IA escrever código)
      if (temTokenSketchfab()) {
        try {
          etapa("Entendendo o pedido…");
          const pedido = await interpretarPedido({ ollama, modelo, tarefa, sinal: controle.signal });
          if (!pedido.procedural && pedido.itens.length) {
            const script = scriptReal(pedido);
            emitir("codigo", { arquivo: `${nome}.py`, linguagem: "py", conteudo: script });
            etapa(`Sketchfab: buscando ${pedido.itens.map((i) => i.busca).join(", ")}…`);
            const r = await rodarBlender(nome, script);
            if (r.ok) {
              emitir("modelo", { nome: r.nome, previa: `/projetos/blender/${r.nome}.png?t=${Date.now()}` });
              etapa(`Modelo pronto: ${r.nome}`);
              return fim(true, `O modelo ${nome.replace(/_/g, " ")} está pronto em ${Math.round((Date.now() - inicio) / 1000)} segundos, senhor. Usei um modelo real e gratuito do Sketchfab; os créditos do autor ficam na pasta JARVIS-Projetos.`);
            }
            etapa("Não achei pronto no Sketchfab, vou modelar do zero…");
          }
        } catch (erro) {
          if (controle.signal.aborted) throw erro;
          etapa(`Sketchfab indisponível (${erro.message.slice(0, 80)}), modelando do zero…`);
        }
      }
      const mensagens = [{ role: "system", content: SISTEMA_BLENDER }, { role: "user", content: tarefa }];
      for (let t = 1; t <= TENTATIVAS; t++) {
        if (t === 1) etapa("Planejando formatos e texturas…");
        const codigo = await gerar({ ollama, modelo, mensagens, pensar: false, sinal: controle.signal, aoParcial: (c) => emitir("codigo", { arquivo: `${nome}.py`, linguagem: "py", conteudo: c }) });
        etapa(`Blender: modelando (${Math.round((Date.now() - inicio) / 1000)} s)`);
        const r = await rodarBlender(nome, codigo);
        if (r.ok) {
          emitir("modelo", { nome: r.nome, previa: `/projetos/blender/${r.nome}.png?t=${Date.now()}` });
          etapa(`Modelo pronto: ${r.nome}`);
          return fim(true, `O modelo ${nome.replace(/_/g, " ")} está pronto em ${Math.round((Date.now() - inicio) / 1000)} segundos. Salvei o arquivo blend e o glb na pasta JARVIS-Projetos.`);
        }
        etapa(`Blender acusou erro, corrigindo (tentativa ${t + 1})…`);
        mensagens.push({ role: "assistant", content: codigo }, { role: "user", content: `O Blender deu este erro:\n${r.texto}\nCorrija e mande o código completo de novo.` });
      }
      return fim(false, "Não consegui fazer o modelo funcionar no Blender depois de três tentativas, senhor.");
    }

    if (tipo === "roblox") {
      let studio = null, studioId = null;
      try {
        studio = await conectarStudio();
        const lista = await studio.cliente.callTool({ name: "list_roblox_studios", arguments: {} });
        const dados = JSON.parse((lista.content ?? []).find((b) => b.type === "text")?.text ?? "{}");
        const primeiro = (dados.studios ?? [])[0];
        studioId = primeiro && (primeiro.studio_id ?? primeiro.id ?? primeiro.studioId ?? (typeof primeiro === "string" ? primeiro : null));
      } catch (erro) {
        etapa(`Sem conexão com o Roblox Studio (${erro.message}).`);
      }
      const rodar = async (code) => {
        const r = await studio.cliente.callTool({ name: "execute_luau", arguments: { code, datamodel_type: "Edit", studio_id: String(studioId) } });
        const texto = (r.content ?? []).map((b) => (b.type === "text" ? b.text : "")).join("\n");
        return { ok: !r.isError && !/error|erro:/i.test(texto.slice(0, 200)), texto };
      };
      let contexto = "Studio não conectado.";
      if (studioId) {
        etapa("Lendo o jogo aberto no Studio…");
        const visao = await rodar(`local out = {}
for _, nome in {"Workspace", "ServerScriptService", "StarterGui", "ReplicatedStorage"} do
  local itens = {}
  for i, c in game:GetService(nome):GetChildren() do if i > 25 then break end table.insert(itens, c.Name .. " (" .. c.ClassName .. ")") end
  table.insert(out, nome .. ": " .. table.concat(itens, ", "))
end
return table.concat(out, "\\n")`).catch((e) => ({ texto: e.message }));
        contexto = visao.texto.slice(0, 2000);
      }
      const mensagens = [{ role: "system", content: SISTEMA_ROBLOX }, { role: "user", content: `O que existe no jogo agora:\n${contexto}\n\nPedido: ${tarefa}` }];
      const nome = nomeDoPedido(tarefa);
      for (let t = 1; t <= TENTATIVAS; t++) {
        const codigo = await gerar({ ollama, modelo, mensagens, sinal: controle.signal, aoParcial: (c) => emitir("codigo", { arquivo: `Roblox · ${nome}.luau`, linguagem: "luau", conteudo: c }) });
        const pasta = path.join(PASTA_PROJETOS, "roblox");
        fs.mkdirSync(pasta, { recursive: true });
        fs.writeFileSync(path.join(pasta, `${nome}.luau`), codigo);
        if (!studioId) return fim(true, `O Roblox Studio não está aberto com o MCP ligado, senhor, então salvei o código em ${nome}.luau na pasta JARVIS-Projetos, roblox. Abra o Studio e peça de novo para eu aplicar direto.`);
        etapa("Roblox Studio: executando o Luau…");
        const r = await rodar(codigo).catch((e) => ({ ok: false, texto: e.message }));
        if (r.ok) {
          const resumo = r.texto.replace(/^[\s\S]*?(?:return|Result|Resultado)[:\s]*/i, "").trim().slice(0, 200);
          return fim(true, `Pronto no Roblox Studio, senhor. ${resumo || "O que você pediu já está no jogo."} Se quiser desfazer, é só usar Control Z no Studio.`);
        }
        etapa(`O Studio acusou erro, corrigindo (tentativa ${t + 1})…`);
        mensagens.push({ role: "assistant", content: codigo }, { role: "user", content: `O Studio respondeu com erro:\n${r.texto.slice(0, 1500)}\nCorrija e mande o código Luau completo de novo.` });
      }
      return fim(false, "O Roblox Studio continuou acusando erro depois de três tentativas, senhor. Salvei a última versão na pasta JARVIS-Projetos.");
    }

    // código comum (Python por padrão, JavaScript ou Lua quando pedido)
    const mensagens = [{ role: "system", content: SISTEMA_CODIGO }, { role: "user", content: tarefa }];
    for (let t = 1; t <= TENTATIVAS; t++) {
      let arquivo = "programa.py";
      const codigo = await gerar({ ollama, modelo, mensagens, sinal: controle.signal, aoParcial: (c) => {
        arquivo = c.match(/^\s*(?:#|\/\/|--)\s*arquivo:\s*([\w.-]+\.(?:py|js|lua))/i)?.[1] ?? arquivo;
        emitir("codigo", { arquivo, linguagem: path.extname(arquivo).slice(1), conteudo: c });
      } });
      const destino = path.join(PASTA_PROJETOS, arquivo);
      fs.writeFileSync(destino, codigo);
      if (INTERATIVO.test(codigo) || arquivo.endsWith(".lua")) {
        etapa(`Salvo: ${arquivo}`);
        return fim(true, `Pronto, senhor. Escrevi ${arquivo} na pasta JARVIS-Projetos. Não executei porque ele ${arquivo.endsWith(".lua") ? "é Lua e não há interpretador Lua neste PC" : "espera interação ou fica rodando"}.`);
      }
      etapa(`Executando ${arquivo}…`);
      const r = await executar(destino);
      if (!r || r.ok) {
        const linha = r?.saida.split("\n").find((l) => l.trim());
        if (linha) etapa(`Saída: ${linha.slice(0, 100)}`);
        return fim(true, `Pronto, senhor. Escrevi ${arquivo} na pasta JARVIS-Projetos${r ? " e testei: funcionou" : ""}.`);
      }
      etapa(`Deu erro ao executar, corrigindo (tentativa ${t + 1})…`);
      mensagens.push({ role: "assistant", content: codigo }, { role: "user", content: `Ao executar deu este erro:\n${r.saida}\nCorrija e mande o código completo de novo.` });
    }
    return fim(false, "O código continuou com erro depois de três tentativas, senhor. Deixei a última versão na pasta JARVIS-Projetos.");
  })()
    .catch((erro) => {
      if (controle.signal.aborted) return fim(false, "Tarefa de programação cancelada, senhor.");
      console.error("Fluxo rápido falhou:", erro.message ?? erro);
      fim(false, "O agente programador encontrou um problema e parou. Os detalhes estão na janela do servidor.");
    })
    .finally(() => { tarefaRapida = null; });
  return { ok: true };
}
