// JARVIS — gera um "trailer de cinema" em HyperFrames para respostas de história e notícias.
// Fluxo: narração dividida em cenas → voz (Fish Audio) por cena → fotos → trilha de trailer (ffmpeg)
//        → composição HTML/GSAP → render MP4 com o CLI do HyperFrames.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFile, spawn } from "node:child_process";
import { promisify } from "node:util";

const exec = promisify(execFile);

const RAIZ_PLUGIN = path.join(os.homedir(), ".claude", "plugins", "cache", "hyperframes", "hyperframes");
const INTRO = 3.0; // segundos de abertura antes da narração
const OUTRO = 3.2;
const BARRA = 132; // altura das faixas pretas do letterbox (2.39:1 dentro de 1920x1080)

/** Encontra o CLI do HyperFrames (plugin instalado) ou cai no npx. */
function comandoHyperframes() {
  try {
    const versoes = fs.readdirSync(RAIZ_PLUGIN).sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
    for (const v of versoes) {
      const cli = path.join(RAIZ_PLUGIN, v, "skills", "hyperframes", "scripts", "plugin-cli.mjs");
      if (fs.existsSync(cli)) return { cmd: process.execPath, args: [cli] };
    }
  } catch {}
  return { cmd: "npx", args: ["--yes", "hyperframes"] };
}

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const ROMANOS = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"];

async function duracao(arquivo) {
  const { stdout } = await exec("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", arquivo]);
  return parseFloat(stdout.trim());
}

/** Divide a narração em n blocos equilibrados, sem quebrar frases. */
function dividirNarracao(fala, n) {
  const frases = fala.replace(/\s+/g, " ").trim().split(/(?<=[.!?…])\s+/).filter(Boolean);
  n = Math.max(1, Math.min(n, frases.length));
  const total = frases.reduce((a, f) => a + f.length, 0);
  const blocos = [];
  let atual = [];
  let soma = 0;
  for (let i = 0; i < frases.length; i++) {
    atual.push(frases[i]);
    soma += frases[i].length;
    const restantesFrases = frases.length - i - 1;
    const restantesBlocos = n - blocos.length - 1;
    if (restantesBlocos > 0 && (soma >= (total * (blocos.length + 1)) / n || restantesFrases === restantesBlocos)) {
      blocos.push(atual.join(" "));
      atual = [];
    }
  }
  if (atual.length) blocos.push(atual.join(" "));
  return blocos;
}

async function baixar(url, destino) {
  const r = await fetch(url, { headers: { "User-Agent": "JARVIS-HUD/1.0 (uso pessoal)" } });
  if (!r.ok) throw new Error(`imagem ${r.status}`);
  fs.writeFileSync(destino, Buffer.from(await r.arrayBuffer()));
  return destino;
}

/** Trilha de trailer feita no ffmpeg: drone grave contínuo + "impactos" no início de cada cena. */
async function criarTrilha(destino, total, impactos) {
  const drone = `aevalsrc='0.10*sin(2*PI*55*t)*(0.6+0.4*sin(2*PI*0.11*t))+0.07*sin(2*PI*82.4*t)+0.04*sin(2*PI*110*t+sin(2*PI*0.3*t))':s=44100:d=${total.toFixed(2)}`;
  const impacto = "aevalsrc='(0.9*sin(2*PI*(38+30*exp(-6*t))*t)+0.25*(random(0)*2-1)*exp(-18*t))*exp(-2.2*t)':s=44100:d=3";
  const entradas = ["-f", "lavfi", "-i", drone];
  const filtros = [];
  impactos.forEach((t, i) => {
    entradas.push("-f", "lavfi", "-i", impacto);
    const ms = Math.round(t * 1000);
    filtros.push(`[${i + 1}:a]adelay=${ms}|${ms},volume=0.55[h${i}]`);
  });
  const mix = `[0:a]afade=t=in:d=2,afade=t=out:st=${(total - 2.5).toFixed(2)}:d=2.5[d];[d]${impactos.map((_, i) => `[h${i}]`).join("")}amix=inputs=${impactos.length + 1}:normalize=0,alimiter=limit=0.8[m]`;
  await exec("ffmpeg", ["-y", ...entradas, "-filter_complex", [...filtros, mix].join(";"), "-map", "[m]", "-ac", "2", "-c:a", "libmp3lame", "-q:a", "4", destino]);
}

/** Legendas: grupos de 3 a 4 palavras com tempo proporcional ao tamanho das palavras. */
function gruposDeLegenda(texto, inicio, dur) {
  const palavras = texto.split(/\s+/).filter(Boolean);
  const pesos = palavras.map((p) => p.length + 2 + (/[.!?…]$/.test(p) ? 6 : /[,;:]$/.test(p) ? 3 : 0));
  const total = pesos.reduce((a, b) => a + b, 0);
  const grupos = [];
  let t = inicio;
  let atual = [];
  let tInicio = inicio;
  palavras.forEach((p, i) => {
    const d = (pesos[i] / total) * dur;
    atual.push({ texto: p, inicio: t, fim: t + d });
    t += d;
    if (atual.length >= 4 || /[.!?…,;:]$/.test(p) || i === palavras.length - 1) {
      grupos.push({ inicio: tInicio, fim: t, palavras: atual });
      atual = [];
      tInicio = t;
    }
  });
  return grupos;
}

function composicao({ titulo, cenas, grupos, total, narracaoInicio, temTrilha }) {
  const n = (x) => +x.toFixed(3);
  const htmlCenas = cenas.map((c, i) => {
    const palavras = c.titulo.toUpperCase().split(/\s+/);
    const numero = c.titulo.match(/\b(\d{3,4})\b/)?.[1];
    const mosaico = c.mosaico;
    return `
      <div id="s${i}" class="clip cena v${i % 3}" data-start="${n(c.inicio)}" data-duration="${n(c.fim - c.inicio + (i < cenas.length - 1 ? 0.6 : 0))}" data-track-index="1" style="z-index:${10 + i}" data-layout-allow-overflow data-layout-allow-overlap>
        <div id="s${i}-in" class="revela">
          ${mosaico
            ? `<div class="mosaico">${mosaico.map((src, k) => `<div id="s${i}-m${k}" class="tile"><img src="${src}" alt=""></div>`).join("")}</div>`
            : `<div id="s${i}-cam" class="cam">${c.foto ? `<img class="foto" src="${c.foto}" alt="">` : `<div class="sem-foto"></div>`}</div>`}
          <div class="tinta"></div>
          ${c.foto2 && !mosaico ? `<div id="s${i}-pip" class="pip"><img src="${c.foto2}" alt=""></div>` : ""}
          ${numero ? `<div id="s${i}-ano" class="ano">${numero}</div>` : ""}
          <div id="s${i}-cap" class="capitulo">CAPÍTULO ${ROMANOS[i] ?? i + 1}<span id="s${i}-traco" class="traco"></span></div>
          <h2 class="titulo">${palavras.map((p, k) => `<span class="w${k === palavras.length - 1 || /\d/.test(p) ? " ouro" : ""}" id="s${i}-w${k}">${esc(p)}</span>`).join(" ")}</h2>
          <div id="s${i}-sub" class="sub">${esc(c.legenda)}</div>
        </div>
        <div id="s${i}-flash" class="flash"></div>
      </div>`;
  }).join("");

  const htmlLegendas = grupos.map((g, k) => `
      <div id="g${k}" class="clip grupo" data-start="${n(g.inicio)}" data-duration="${n(Math.max(0.2, g.fim - g.inicio))}" data-track-index="3" style="z-index:60">${g.palavras.map((p, j) => `<span id="g${k}-p${j}">${esc(p.texto)}</span>`).join(" ")}</div>`).join("");

  // ---- animações (todas em uma linha do tempo pausada, função apenas do tempo) ----
  const js = [];
  js.push(`tl.fromTo("#intro-top", {opacity:0, letterSpacing:"1.2em"}, {opacity:1, letterSpacing:"0.55em", duration:1.4, ease:"power2.out"}, 0.3);`);
  js.push(`tl.fromTo("#intro-titulo", {opacity:0, scale:1.18, letterSpacing:"0.4em"}, {opacity:1, scale:1, letterSpacing:"0.06em", duration:2.1, ease:"expo.out"}, 0.7);`);
  js.push(`tl.fromTo("#intro-luz", {xPercent:-120}, {xPercent:120, duration:1.6, ease:"power2.inOut"}, 1.0);`);
  js.push(`tl.to("#intro-titulo", {opacity:0, scale:1.08, duration:0.35, ease:"power3.in"}, ${INTRO - 0.4});`);
  js.push(`tl.to("#intro-top", {opacity:0, duration:0.3}, ${INTRO - 0.4});`);
  cenas.forEach((c, i) => {
    const t0 = c.inicio;
    const d = c.fim - c.inicio;
    const dir = i % 2 ? -1 : 1;
    js.push(`tl.fromTo("#s${i}-in", {clipPath:"inset(0% 0% 0% 100%)"}, {clipPath:"inset(0% 0% 0% 0%)", duration:0.55, ease:"power4.inOut"}, ${n(t0)});`);
    js.push(`tl.fromTo("#s${i}-flash", {opacity:0.85}, {opacity:0, duration:0.45, ease:"power2.out"}, ${n(t0 + 0.35)});`);
    if (c.mosaico) {
      c.mosaico.forEach((_, k) => js.push(`tl.fromTo("#s${i}-m${k}", {opacity:0, scale:1.25}, {opacity:1, scale:1, duration:0.7, ease:"expo.out"}, ${n(t0 + 0.2 + k * 0.12)});`));
    } else {
      js.push(`tl.fromTo("#s${i}-cam", {scale:${i % 2 ? 1.02 : 1.16}, xPercent:${-2 * dir}, yPercent:-1}, {scale:${i % 2 ? 1.16 : 1.02}, xPercent:${2 * dir}, yPercent:1, duration:${n(d + 0.6)}, ease:"none"}, ${n(t0)});`);
    }
    js.push(`tl.fromTo("#s${i}-cap", {opacity:0, x:-40}, {opacity:1, x:0, duration:0.8, ease:"expo.out"}, ${n(t0 + 0.5)});`);
    js.push(`tl.fromTo("#s${i}-traco", {scaleX:0}, {scaleX:1, duration:0.9, ease:"expo.out"}, ${n(t0 + 0.7)});`);
    js.push(`tl.fromTo("#s${i} .titulo .w", {opacity:0, filter:"blur(14px)", y:30}, {opacity:1, filter:"blur(0px)", y:0, duration:0.7, stagger:0.09, ease:"expo.out"}, ${n(t0 + 0.75)});`);
    js.push(`tl.fromTo("#s${i}-sub", {opacity:0, y:16}, {opacity:1, y:0, duration:0.9, ease:"power3.out"}, ${n(t0 + 1.3)});`);
    js.push(`tl.to("#s${i} .titulo, #s${i}-sub, #s${i}-cap", {opacity:0, filter:"blur(8px)", duration:0.25, ease:"power2.in"}, ${n(c.fim - 0.25)});`);
    if (c.foto2 && !c.mosaico) js.push(`tl.fromTo("#s${i}-pip", {opacity:0, y:50, clipPath:"inset(100% 0% 0% 0%)"}, {opacity:1, y:0, clipPath:"inset(0% 0% 0% 0%)", duration:0.9, ease:"expo.out"}, ${n(t0 + 1.6)});`);
    const ano = c.titulo.match(/\b(\d{3,4})\b/)?.[1];
    if (ano) js.push(`(function(){const el=document.querySelector("#s${i}-ano");const o={v:${Math.max(0, +ano - 120)}};tl.fromTo(el,{opacity:0},{opacity:1,duration:0.5},${n(t0 + 0.4)});tl.to(o,{v:${+ano},duration:1.6,ease:"expo.out",onUpdate:()=>{el.textContent=Math.round(o.v);}},${n(t0 + 0.4)});})();`);
  });
  grupos.forEach((g, k) => {
    js.push(`tl.fromTo("#g${k} span", {opacity:0.25}, {opacity:1, duration:0.12, stagger:{each:${n(Math.max(0.05, (g.fim - g.inicio) / Math.max(1, g.palavras.length)))}}, ease:"none"}, ${n(g.inicio)});`);
  });
  js.push(`tl.fromTo("#outro-nome", {opacity:0, scale:1.2, letterSpacing:"0.6em"}, {opacity:1, scale:1, letterSpacing:"0.18em", duration:1.6, ease:"expo.out"}, ${n(total - OUTRO + 0.3)});`);
  js.push(`tl.fromTo("#outro-frase", {opacity:0}, {opacity:1, duration:1, ease:"power2.out"}, ${n(total - OUTRO + 1.1)});`);
  js.push(`tl.fromTo("#barra-progresso i", {scaleX:0}, {scaleX:1, duration:${n(total)}, ease:"none"}, 0);`);

  return `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1920, height=1080" />
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
<style>
  :root { --ouro: #e8c37a; --ciano: #7fdcff; --tinta: #05060c; }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body { width: 1920px; height: 1080px; overflow: hidden; background: #000; }
  #root { position: relative; width: 100%; height: 100%; background: #000; font-family: "Inter", sans-serif; color: #fff; }
  .fundo { position: absolute; inset: 0; background: #000; }
  .cena { position: absolute; inset: 0; overflow: hidden; }
  .revela { position: absolute; inset: 0; overflow: hidden; }
  .cam { position: absolute; inset: -4%; }
  .foto { width: 100%; height: 100%; object-fit: cover; }
  .sem-foto { position: absolute; inset: 0; background: radial-gradient(circle at 60% 40%, #24314f, #07080f 70%); }
  .tinta { position: absolute; inset: 0; background:
      linear-gradient(180deg, rgba(0,0,0,.55) 0%, rgba(0,0,0,.05) 30%, rgba(0,0,0,.15) 55%, rgba(0,0,0,.85) 100%),
      linear-gradient(90deg, rgba(0,0,0,.65) 0%, rgba(0,0,0,0) 55%),
      linear-gradient(0deg, rgba(20,30,60,.35), rgba(80,50,20,.18)); }
  .mosaico { position: absolute; inset: ${BARRA}px 0; display: grid; grid-template-columns: repeat(3, 1fr); grid-template-rows: repeat(2, 1fr); gap: 10px; padding: 10px; }
  .tile { overflow: hidden; border-radius: 6px; }
  .tile img { width: 100%; height: 100%; object-fit: cover; }
  .pip { position: absolute; right: 150px; top: ${BARRA + 70}px; width: 520px; height: 330px; overflow: hidden; border-radius: 6px; box-shadow: 0 30px 80px rgba(0,0,0,.7); outline: 1px solid rgba(255,255,255,.25); outline-offset: 8px; }
  .pip img { width: 100%; height: 100%; object-fit: cover; }
  .ano { position: absolute; right: 120px; bottom: ${BARRA + 40}px; font-family: "League Gothic", sans-serif; font-size: 360px; line-height: .8; color: rgba(255,255,255,.12); letter-spacing: .02em; }
  .capitulo { position: absolute; left: 150px; top: ${BARRA + 70}px; font-family: "Inter", sans-serif; font-weight: 700; font-size: 22px; letter-spacing: .5em; color: var(--ouro); display: flex; align-items: center; gap: 24px; }
  .traco { display: inline-block; width: 160px; height: 2px; background: var(--ouro); transform-origin: left center; }
  .titulo { position: absolute; left: 150px; right: 640px; bottom: ${BARRA + 130}px; font-family: "League Gothic", sans-serif; font-weight: 400; font-size: 168px; line-height: .9; letter-spacing: .02em; text-shadow: 0 10px 40px rgba(0,0,0,.6); }
  .v1 .titulo { right: 150px; }
  .v2 .titulo { left: 150px; right: 150px; text-align: center; }
  .v2 .capitulo { left: 0; right: 0; justify-content: center; }
  .v2 .sub { left: 0; right: 0; text-align: center; }
  .w { display: inline-block; }
  .ouro { color: var(--ouro); }
  .sub { position: absolute; left: 150px; bottom: ${BARRA + 70}px; font-family: "Playfair Display", serif; font-style: italic; font-size: 40px; color: rgba(255,255,255,.88); text-transform: lowercase; }
  .flash { position: absolute; inset: 0; background: #fff; opacity: 0; mix-blend-mode: screen; }
  .barra { position: absolute; left: 0; right: 0; height: ${BARRA}px; background: #000; z-index: 50; }
  .barra.cima { top: 0; } .barra.baixo { bottom: 0; }
  .grupo { position: absolute; left: 0; right: 0; bottom: 34px; text-align: center; font-family: "Inter", sans-serif; font-weight: 700; font-size: 46px; letter-spacing: .02em; color: #fff; }
  .marca { position: absolute; top: 46px; left: 150px; z-index: 55; font-family: "Inter", sans-serif; font-weight: 700; font-size: 18px; letter-spacing: .55em; color: rgba(255,255,255,.75); }
  .marca b { color: var(--ciano); }
  #barra-progresso { position: absolute; left: 150px; right: 150px; top: 92px; height: 2px; background: rgba(255,255,255,.15); z-index: 55; }
  #barra-progresso i { display: block; height: 100%; background: linear-gradient(90deg, var(--ouro), #fff); transform-origin: left center; }
  #intro { position: absolute; inset: 0; z-index: 40; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 30px; background: radial-gradient(circle at 50% 50%, #10131f, #000 70%); overflow: hidden; }
  #intro-top { font-family: "Inter", sans-serif; font-weight: 700; font-size: 24px; letter-spacing: .55em; color: var(--ouro); }
  #intro-titulo { font-family: "League Gothic", sans-serif; font-size: 190px; line-height: .9; text-align: center; max-width: 1600px; }
  #intro-luz { position: absolute; top: 0; bottom: 0; width: 40%; background: linear-gradient(90deg, transparent, rgba(255,240,210,.25), transparent); }
  #outro { position: absolute; inset: 0; z-index: 45; background: #000; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 26px; }
  #outro-nome { font-family: "League Gothic", sans-serif; font-size: 220px; letter-spacing: .18em; padding-left: .18em; }
  #outro-frase { font-family: "Playfair Display", serif; font-style: italic; font-size: 40px; color: var(--ouro); }
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="${n(total)}" data-width="1920" data-height="1080">
  <div id="fundo" class="clip fundo" data-start="0" data-duration="${n(total)}" data-track-index="0" style="z-index:1"></div>
  <div id="intro" class="clip" data-start="0" data-duration="${INTRO}" data-track-index="2" data-layout-allow-overflow>
    <div id="intro-luz"></div>
    <div id="intro-top">J.A.R.V.I.S. APRESENTA</div>
    <div id="intro-titulo">${esc(titulo.toUpperCase())}</div>
  </div>
  ${htmlCenas}
  <div id="barra-cima" class="clip barra cima" data-start="0" data-duration="${n(total)}" data-track-index="4"></div>
  <div id="barra-baixo" class="clip barra baixo" data-start="0" data-duration="${n(total)}" data-track-index="4"></div>
  <div id="marca" class="clip marca" data-start="${INTRO}" data-duration="${n(total - INTRO - OUTRO)}" data-track-index="5">J.A.R.V.I.S. <b>·</b> DOSSIÊ</div>
  <div id="barra-progresso" class="clip" data-start="${INTRO}" data-duration="${n(total - INTRO - OUTRO)}" data-track-index="5"><i></i></div>
  ${htmlLegendas}
  <div id="outro" class="clip" data-start="${n(total - OUTRO)}" data-duration="${OUTRO}" data-track-index="2">
    <div id="outro-nome">J.A.R.V.I.S.</div>
    <div id="outro-frase">o conhecimento é a armadura mais poderosa</div>
  </div>
  <audio id="narracao" class="clip" data-start="${n(narracaoInicio)}" data-track-index="6" data-volume="1" src="assets/narracao.mp3"></audio>
  ${temTrilha ? `<audio id="trilha" class="clip" data-start="0" data-track-index="7" data-volume="0.55" src="assets/trilha.mp3"></audio>` : ""}
</div>
<script>
  const tl = gsap.timeline({ paused: true });
  ${js.join("\n  ")}
  window.__timelines["main"] = tl;
  tl.seek(0);
</script>
</body>
</html>`;
}

/**
 * Gera o trailer. `sintetizar(texto)` devolve o MP3 da voz (Buffer) ou null.
 * `cenas`: [{ titulo, legenda, src, extra }] (as fotos do Wikimedia já escolhidas).
 * `progresso(etapa, pct)` é chamado ao longo do processo.
 */
export async function gerarTrailer({ pasta, titulo, fala, cenas, sintetizar, progresso = () => {} }) {
  fs.mkdirSync(path.join(pasta, "assets"), { recursive: true });
  const ativos = (f) => path.join(pasta, "assets", f);

  // 1. narração por cena: cada bloco vira uma cena com duração exata
  progresso("narração", 5);
  const blocos = dividirNarracao(fala, cenas.length);
  const partes = [];
  for (let i = 0; i < blocos.length; i++) {
    const audio = await sintetizar(blocos[i]);
    if (!audio) throw new Error("voz do Fish Audio não configurada");
    const arq = ativos(`voz-${i}.mp3`);
    fs.writeFileSync(arq, audio);
    partes.push({ arq, texto: blocos[i], dur: await duracao(arq) });
    progresso("narração", 5 + Math.round((25 * (i + 1)) / blocos.length));
  }
  const PAUSA = 0.45;
  const listaConcat = partes.flatMap((p, i) => (i < partes.length - 1 ? [p.arq, "pausa"] : [p.arq]));
  await exec("ffmpeg", ["-y", "-f", "lavfi", "-i", `anullsrc=r=44100:cl=stereo`, "-t", String(PAUSA), ativos("pausa.mp3")]);
  const entradas = listaConcat.flatMap((a) => ["-i", a === "pausa" ? ativos("pausa.mp3") : a]);
  await exec("ffmpeg", ["-y", ...entradas, "-filter_complex", `concat=n=${listaConcat.length}:v=0:a=1`, "-ac", "2", "-c:a", "libmp3lame", "-q:a", "3", ativos("narracao.mp3")]);

  // 2. fotos
  progresso("imagens", 32);
  const usadas = cenas.slice(0, partes.length);
  await Promise.all(usadas.map(async (c, i) => {
    c.foto = c.src ? await baixar(c.src, ativos(`c${i}a.jpg`)).then(() => `assets/c${i}a.jpg`).catch(() => null) : null;
    c.foto2 = c.extra ? await baixar(c.extra, ativos(`c${i}b.jpg`)).then(() => `assets/c${i}b.jpg`).catch(() => null) : null;
  }));
  // a segunda cena vira um mural de imagens (como uma parede de monitores)
  const todas = usadas.flatMap((c) => [c.foto, c.foto2]).filter(Boolean);
  if (usadas.length >= 3 && todas.length >= 6) usadas[1].mosaico = todas.slice(0, 6);

  // 3. tempos
  let t = INTRO;
  const grupos = [];
  usadas.forEach((c, i) => {
    const p = partes[i];
    c.inicio = t;
    c.fim = t + p.dur + (i < partes.length - 1 ? PAUSA : 0);
    grupos.push(...gruposDeLegenda(p.texto, t, p.dur));
    t = c.fim;
  });
  const total = t + 0.6 + OUTRO;

  // 4. trilha
  progresso("trilha", 38);
  let temTrilha = true;
  try {
    await criarTrilha(ativos("trilha.mp3"), total, [0.6, ...usadas.map((c) => c.inicio), total - OUTRO + 0.2]);
  } catch (erro) {
    temTrilha = false;
    console.error("Trilha falhou:", erro.message);
  }

  // 5. composição + render
  fs.writeFileSync(path.join(pasta, "index.html"), composicao({ titulo, cenas: usadas, grupos, total, narracaoInicio: INTRO, temTrilha }));
  fs.writeFileSync(path.join(pasta, "hyperframes.json"), JSON.stringify({ name: path.basename(pasta) }, null, 2));
  progresso("renderização", 42);
  const saida = path.join(pasta, "trailer.mp4");
  const { cmd, args } = comandoHyperframes();
  await new Promise((ok, falha) => {
    const p = spawn(cmd, [...args, "render", ".", "-o", saida, "-q", "draft", "--quiet"], { cwd: pasta, windowsHide: true });
    let log = "";
    const ler = (d) => {
      log += d;
      const pct = [...String(d).matchAll(/(\d{1,3})%/g)].pop()?.[1];
      if (pct) progresso("renderização", 42 + Math.round(+pct * 0.57));
    };
    p.stdout.on("data", ler);
    p.stderr.on("data", ler);
    p.on("error", falha);
    p.on("close", (codigo) => (codigo === 0 && fs.existsSync(saida) ? ok() : falha(new Error(`render saiu com ${codigo}: ${log.slice(-400)}`))));
  });
  progresso("pronto", 100);
  return { arquivo: saida, duracao: total };
}
