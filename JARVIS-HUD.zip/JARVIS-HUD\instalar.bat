@echo off
chcp 65001 >nul
title Instalando o J.A.R.V.I.S.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
if errorlevel 1 (
  echo.
  echo  A instalacao parou com um erro. Leia a mensagem acima, corrija e rode o instalar.bat de novo.
)
echo.
pause
