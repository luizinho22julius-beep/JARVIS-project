@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem Se o JARVIS ja estiver ligado, so abre o HUD
netstat -ano | findstr ":7777 " | findstr "LISTENING" >nul
if %errorlevel%==0 goto abrir

rem Senao, liga o servidor minimizado (ele mesmo abre o HUD)
if not exist node_modules call npm install --no-audit --no-fund
start "J.A.R.V.I.S." /min cmd /c "node server.mjs || pause"
exit /b

:abrir
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%EDGE%" (
  start "" "%EDGE%" --app=http://localhost:7777 --start-maximized
) else (
  start "" http://localhost:7777
)
