# JARVIS — base para modelagem rápida no Blender (roda com: blender --background --python blender_base.py -- <script> <saida>)
# Limpa a cena, executa o script do modelo, enquadra uma câmera, ilumina, salva .blend, exporta .glb e gera a prévia.
import math
import re
import os
import sys

import bpy
from mathutils import Vector

argumentos = sys.argv[sys.argv.index("--") + 1:]
script_modelo, base_saida = argumentos[0], argumentos[1]

bpy.ops.wm.read_factory_settings(use_empty=True)
cena = bpy.context.scene


# ---------- kit de modelagem (funções prontas que o script do agente usa) ----------
# tipos de material realista, reconhecidos pelo parâmetro tipo= ou pelo nome do material
TIPOS = {
    "madeira": r"madeira|wood|tampo|perna|estante|porta|tronco|mesa|cadeira|encosto|prateleira|estrado|cabeceira",
    "metal": r"metal|a[cç]o|ferro|aro|haste|poste|braco|alum[ií]nio|cromo|steel",
    "vidro": r"vidro|janela|glass|cabine|lente",
    "tecido": r"tecido|sof[aá]|almofada|assento|len[cç]ol|travesseiro|colch[aã]o|roupa|cortina|tapete",
    "pintura": r"pintura|carroceria|lataria",
    "concreto": r"concreto|cimento|parede|paredes|corpo|predio|cal[cç]ada|asfalto|rua",
    "tijolo": r"tijolo|brick",
    "grama": r"grama|gramado|folha|copa|grass",
    "borracha": r"borracha|pneu",
    "telha": r"telha|telhado",
}


def _no(arvore, tipo, x=0, y=0, **valores):
    n = arvore.nodes.new(tipo)
    n.location = (x, y)
    for chave, valor in valores.items():
        if chave in n.inputs:
            n.inputs[chave].default_value = valor
        else:
            setattr(n, chave, valor)
    return n


def _entrada(bsdf, nomes, valor):
    for nome in nomes:
        if nome in bsdf.inputs:
            bsdf.inputs[nome].default_value = valor
            return


def material(nome="Material", cor=(0.8, 0.8, 0.8), metal=0.0, rugosidade=0.5, emissao=0.0, tipo=None):
    """Material realista: cor RGB (0 a 1) + tipo (madeira, metal, vidro, tecido, pintura, concreto, tijolo, grama, borracha, telha).
    Sem tipo, ele é deduzido do nome (ex.: "Madeira", "Vidro", "Pneu")."""
    import re
    m = bpy.data.materials.new(nome)
    m.diffuse_color = (*cor, 1)
    try:
        m.use_nodes = True
    except Exception:
        pass
    arvore = m.node_tree
    bsdf = arvore.nodes.get("Principled BSDF")
    if not tipo:
        tipo = next((t for t, padrao in TIPOS.items() if re.search(padrao, nome, re.I)), None)
    base = (*cor, 1)
    bsdf.inputs["Base Color"].default_value = base
    bsdf.inputs["Metallic"].default_value = metal
    bsdf.inputs["Roughness"].default_value = rugosidade
    coord = _no(arvore, "ShaderNodeTexCoord", -900, 0)
    escuro = tuple(c * 0.55 for c in cor) + (1,)
    claro = tuple(min(1, c * 1.15) for c in cor) + (1,)

    def rampa(entrada_fator, c1, c2, x=-300, y=200):
        r = _no(arvore, "ShaderNodeValToRGB", x, y)
        r.color_ramp.elements[0].color = c1
        r.color_ramp.elements[1].color = c2
        arvore.links.new(entrada_fator, r.inputs["Fac"])
        return r

    def relevo(saida, forca=0.3, distancia=0.02):
        b = _no(arvore, "ShaderNodeBump", -200, -300, Strength=forca, Distance=distancia)
        arvore.links.new(saida, b.inputs["Height"])
        arvore.links.new(b.outputs["Normal"], bsdf.inputs["Normal"])

    if tipo == "madeira":
        # veios: ondas distorcidas por ruído, ao longo do objeto
        onda = _no(arvore, "ShaderNodeTexWave", -600, 200, Scale=9.0, Distortion=4.0, Detail=4.0)
        arvore.links.new(coord.outputs["Object"], onda.inputs["Vector"])
        r = rampa(onda.outputs["Fac"], escuro, claro)
        arvore.links.new(r.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.45
        relevo(onda.outputs["Fac"], 0.15, 0.005)
    elif tipo == "metal":
        bsdf.inputs["Metallic"].default_value = 1.0
        ruido = _no(arvore, "ShaderNodeTexNoise", -600, -100, Scale=80.0, Detail=4.0)
        arvore.links.new(coord.outputs["Object"], ruido.inputs["Vector"])
        mapa = _no(arvore, "ShaderNodeMapRange", -350, -100)
        arvore.links.new(ruido.outputs["Fac"], mapa.inputs["Value"])
        mapa.inputs["To Min"].default_value = 0.22
        mapa.inputs["To Max"].default_value = 0.38
        arvore.links.new(mapa.outputs["Result"], bsdf.inputs["Roughness"])
    elif tipo == "vidro":
        _entrada(bsdf, ["Transmission Weight", "Transmission"], 1.0)
        bsdf.inputs["Roughness"].default_value = 0.02
        _entrada(bsdf, ["IOR"], 1.45)
        bsdf.inputs["Base Color"].default_value = tuple(min(1, c * 0.5 + 0.5) for c in cor) + (1,)
        try:
            m.surface_render_method = "BLENDED"
        except Exception:
            pass
    elif tipo == "tecido":
        trama = _no(arvore, "ShaderNodeTexNoise", -600, 200, Scale=400.0, Detail=2.0)
        arvore.links.new(coord.outputs["Object"], trama.inputs["Vector"])
        r = rampa(trama.outputs["Fac"], escuro, base)
        arvore.links.new(r.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.9
        _entrada(bsdf, ["Sheen Weight", "Sheen"], 0.5)
        relevo(trama.outputs["Fac"], 0.2, 0.002)
    elif tipo == "pintura":
        bsdf.inputs["Metallic"].default_value = 0.6
        bsdf.inputs["Roughness"].default_value = 0.3
        _entrada(bsdf, ["Coat Weight", "Clearcoat"], 1.0)
        _entrada(bsdf, ["Coat Roughness", "Clearcoat Roughness"], 0.02)
        # flocos metálicos sob o verniz (relevo minúsculo só na camada de base)
        flocos = _no(arvore, "ShaderNodeTexNoise", -600, -300, Scale=2500.0, Detail=1.0)
        arvore.links.new(coord.outputs["Object"], flocos.inputs["Vector"])
        relevo(flocos.outputs["Fac"], 0.06, 0.001)
    elif tipo == "colmeia":
        celulas = _no(arvore, "ShaderNodeTexVoronoi", -600, 200, Scale=70.0)
        try:
            celulas.feature = "DISTANCE_TO_EDGE"
        except Exception:
            pass
        arvore.links.new(coord.outputs["Object"], celulas.inputs["Vector"])
        r = rampa(celulas.outputs["Distance"], (0.0, 0.0, 0.0, 1), (0.05, 0.05, 0.055, 1))
        r.color_ramp.elements[1].position = 0.08
        arvore.links.new(r.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.35
        relevo(celulas.outputs["Distance"], 0.8, 0.01)
    elif tipo in ("concreto", "telha"):
        ruido = _no(arvore, "ShaderNodeTexNoise", -600, 200, Scale=12.0, Detail=8.0, Roughness=0.7)
        arvore.links.new(coord.outputs["Object"], ruido.inputs["Vector"])
        r = rampa(ruido.outputs["Fac"], escuro, claro)
        arvore.links.new(r.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.85
        relevo(ruido.outputs["Fac"], 0.25, 0.01)
    elif tipo == "tijolo":
        tij = _no(arvore, "ShaderNodeTexBrick", -600, 200, Scale=4.0)
        arvore.links.new(coord.outputs["Object"], tij.inputs["Vector"])
        tij.inputs["Color1"].default_value = base
        tij.inputs["Color2"].default_value = escuro
        tij.inputs["Mortar"].default_value = (0.75, 0.73, 0.7, 1)
        arvore.links.new(tij.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.9
        relevo(tij.outputs["Fac"], 0.4, 0.02)
    elif tipo == "grama":
        ruido = _no(arvore, "ShaderNodeTexNoise", -600, 200, Scale=30.0, Detail=6.0)
        arvore.links.new(coord.outputs["Object"], ruido.inputs["Vector"])
        r = rampa(ruido.outputs["Fac"], escuro, claro)
        arvore.links.new(r.outputs["Color"], bsdf.inputs["Base Color"])
        bsdf.inputs["Roughness"].default_value = 0.8
        relevo(ruido.outputs["Fac"], 0.5, 0.02)
    elif tipo == "borracha":
        bsdf.inputs["Roughness"].default_value = 0.8
        grao = _no(arvore, "ShaderNodeTexNoise", -600, 200, Scale=300.0, Detail=3.0)
        arvore.links.new(coord.outputs["Object"], grao.inputs["Vector"])
        relevo(grao.outputs["Fac"], 0.25, 0.002)
    if emissao:
        _entrada(bsdf, ["Emission Color", "Emission"], base)
        _entrada(bsdf, ["Emission Strength"], emissao)
    return m


def _pronto(obj, nome, cor, chanfro=0.0, suave=False):
    obj.name = nome
    if cor is not None:
        obj.data.materials.append(cor if isinstance(cor, bpy.types.Material) else material(nome + "_mat", cor))
    if chanfro > 0:
        mod = obj.modifiers.new("Chanfro", "BEVEL")
        mod.width = chanfro
        mod.segments = 3
        mod.limit_method = "ANGLE"
    if suave:
        for p in obj.data.polygons:
            p.use_smooth = True
    return obj


def _aplicar_escala(obj):
    for o in bpy.context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)


def _v3(v, padrao_z=0.0, escalar_igual=False):
    """Aceita número, (x,y) ou (x,y,z) e devolve sempre (x,y,z): o modelo nem sempre passa o formato exato."""
    if isinstance(v, (int, float)):
        return (float(v),) * 3 if escalar_igual else (0.0, 0.0, float(v))
    v = tuple(float(x) for x in v)
    return v + (padrao_z,) if len(v) == 2 else v[:3]


def cubo(nome="Cubo", tamanho=(1, 1, 1), pos=(0, 0, 0), rot=(0, 0, 0), cor=None, chanfro=None):
    """Caixa com largura, profundidade e altura em metros (tamanho), centro em pos.
    Sem chanfro informado, ganha um arredondamento leve nas quinas (objetos reais não têm arestas perfeitas)."""
    tamanho = _v3(tamanho, escalar_igual=True)
    if chanfro is None:
        chanfro = min(0.02, min(tamanho) * 0.06)
    pos = _v3(pos, padrao_z=tamanho[2] / 2)
    bpy.ops.mesh.primitive_cube_add(size=1, location=pos, rotation=_v3(rot))
    obj = bpy.context.active_object
    obj.scale = tamanho
    _aplicar_escala(obj)
    return _pronto(obj, nome, cor, chanfro)


def cilindro(nome="Cilindro", raio=0.5, altura=1.0, pos=(0, 0, 0), rot=(0, 0, 0), cor=None, chanfro=0.0, lados=32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=lados, radius=raio, depth=altura, location=_v3(pos, altura / 2), rotation=_v3(rot))
    return _pronto(bpy.context.active_object, nome, cor, chanfro, suave=True)


def esfera(nome="Esfera", raio=0.5, pos=(0, 0, 0), cor=None, escala=(1, 1, 1)):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=raio, location=_v3(pos, raio))
    obj = bpy.context.active_object
    obj.scale = _v3(escala, escalar_igual=True)
    _aplicar_escala(obj)
    return _pronto(obj, nome, cor, suave=True)


def cone(nome="Cone", raio=0.5, raio_topo=0.0, altura=1.0, pos=(0, 0, 0), rot=(0, 0, 0), cor=None, lados=32):
    bpy.ops.mesh.primitive_cone_add(vertices=lados, radius1=raio, radius2=raio_topo, depth=altura, location=_v3(pos, altura / 2), rotation=_v3(rot))
    return _pronto(bpy.context.active_object, nome, cor, suave=True)


def toro(nome="Toro", raio=0.5, espessura=0.1, pos=(0, 0, 0), rot=(0, 0, 0), cor=None):
    bpy.ops.mesh.primitive_torus_add(major_radius=raio, minor_radius=espessura, location=_v3(pos, espessura), rotation=_v3(rot))
    return _pronto(bpy.context.active_object, nome, cor, suave=True)


def plano(nome="Chao", tamanho=10.0, pos=(0, 0, 0), cor=(0.42, 0.42, 0.4)):
    bpy.ops.mesh.primitive_plane_add(size=tamanho if isinstance(tamanho, (int, float)) else max(tamanho), location=_v3(pos))
    if cor is not None and not isinstance(cor, bpy.types.Material):
        cor = material(nome + "_mat", cor, tipo="concreto")
    return _pronto(bpy.context.active_object, nome, cor)


def repetir(obj, quantidade=3, deslocamento=(1.0, 0, 0)):
    """Repete o objeto em fila (deslocamento em metros entre cópias)."""
    mod = obj.modifiers.new("Repetir", "ARRAY")
    mod.count = quantidade
    mod.use_relative_offset = False
    mod.use_constant_offset = True
    mod.constant_offset_displace = deslocamento
    return obj


def espelhar(obj, eixo="X"):
    mod = obj.modifiers.new("Espelho", "MIRROR")
    mod.use_axis = (eixo == "X", eixo == "Y", eixo == "Z")
    return obj


def subdividir(obj, nivel=2):
    mod = obj.modifiers.new("Suavizar", "SUBSURF")
    mod.levels = nivel
    mod.render_levels = nivel
    for p in obj.data.polygons:
        p.use_smooth = True
    return obj


def girar_copias(objetos, quantidade=4, centro=(0, 0, 0)):
    """Copia um ou mais objetos em volta do eixo Z do centro (ex.: cadeiras em volta da mesa)."""
    import math as _m
    if not isinstance(objetos, (list, tuple)):
        objetos = [objetos]
    copias = []
    for k in range(1, quantidade):
        ang = 2 * _m.pi * k / quantidade
        for o in objetos:
            c = o.copy()
            c.data = o.data.copy()
            dx, dy = o.location.x - centro[0], o.location.y - centro[1]
            c.location.x = centro[0] + dx * _m.cos(ang) - dy * _m.sin(ang)
            c.location.y = centro[1] + dx * _m.sin(ang) + dy * _m.cos(ang)
            c.rotation_euler.z = o.rotation_euler.z + ang
            bpy.context.collection.objects.link(c)
            copias.append(c)
    return copias


# ---------- encaixe: nada flutua ----------
def _caixa_z(obj):
    """(menor z, maior z) do objeto e de todos os filhos com geometria."""
    bpy.context.view_layer.update()
    pecas = [o for o in [obj, *obj.children_recursive] if o.type in {"MESH", "CURVE", "FONT"}] or [obj]
    zs = [(o.matrix_world @ Vector(c)).z for o in pecas for c in o.bound_box]
    return min(zs), max(zs)


def topo(obj):
    """Altura (z) do ponto mais alto do objeto (ou grupo)."""
    return _caixa_z(obj)[1]


def sobre(base, obj, dx=0.0, dy=0.0):
    """Coloca obj apoiado em cima de base (centralizado, com deslocamento opcional)."""
    obj.location.z += topo(base) - _caixa_z(obj)[0]
    obj.location.x = base.location.x + dx
    obj.location.y = base.location.y + dy
    return obj


def no_chao(*objs):
    """Apoia os objetos no chão (z=0) sem mudar x e y."""
    for obj in objs:
        obj.location.z -= _caixa_z(obj)[0]
    return objs


# ---------- peças prontas (cada uma devolve um objeto vazio "pai"; mova/gire pelo pai) ----------
def _grupo(nome, partes, pos=(0, 0), rot=0.0, escala=1.0):
    pai = bpy.data.objects.new(nome, None)
    bpy.context.collection.objects.link(pai)
    for p in partes:
        p.parent = pai
    pai.location = (pos[0], pos[1], 0)
    pai.rotation_euler.z = math.radians(rot)
    pai.scale = (escala, escala, escala)
    return pai


def _cor(c, padrao, nome):
    return c if isinstance(c, bpy.types.Material) else material(nome, c or padrao)


def mesa(pos=(0, 0), rot=0, largura=1.6, profundidade=0.9, altura=0.75, cor=None, nome="Mesa"):
    m = _cor(cor, (0.45, 0.27, 0.12), nome + "_mat")
    t = 0.05
    partes = [cubo(nome + "_Tampo", (largura, profundidade, t), (0, 0, altura - t / 2), cor=m, chanfro=0.01)]
    for x in (-largura / 2 + 0.08, largura / 2 - 0.08):
        for y in (-profundidade / 2 + 0.08, profundidade / 2 - 0.08):
            partes.append(cilindro(nome + "_Perna", 0.03, altura - t, (x, y, (altura - t) / 2), cor=m))
    return _grupo(nome, partes, pos, rot)


def cadeira(pos=(0, 0), rot=0, cor=None, cor_assento=None, nome="Cadeira"):
    """Cadeira virada para +Y (o encosto fica atrás, em -Y). Use rot em graus para virar."""
    m = _cor(cor, (0.45, 0.27, 0.12), nome + "_mat")
    a = _cor(cor_assento, (0.15, 0.25, 0.55), nome + "_assento")
    h = 0.45
    partes = [cubo(nome + "_Assento", (0.45, 0.45, 0.05), (0, 0, h - 0.025), cor=a, chanfro=0.01),
              cubo(nome + "_Encosto", (0.45, 0.05, 0.5), (0, -0.2, h + 0.25), cor=m, chanfro=0.01)]
    for x in (-0.19, 0.19):
        for y in (-0.19, 0.19):
            partes.append(cilindro(nome + "_Perna", 0.02, h - 0.05, (x, y, (h - 0.05) / 2), cor=m))
    return _grupo(nome, partes, pos, rot)


def sofa(pos=(0, 0), rot=0, largura=2.0, cor=None, nome="Sofa"):
    m = _cor(cor, (0.35, 0.36, 0.4), nome + "_mat")
    partes = [cubo(nome + "_Base", (largura, 0.9, 0.42), (0, 0, 0.21), cor=m, chanfro=0.04),
              cubo(nome + "_Encosto", (largura, 0.22, 0.45), (0, -0.34, 0.645), cor=m, chanfro=0.05)]
    for x in (-largura / 2 + 0.1, largura / 2 - 0.1):
        partes.append(cubo(nome + "_Braco", (0.2, 0.9, 0.62), (x, 0, 0.31), cor=m, chanfro=0.05))
    n = max(2, round(largura / 0.8))
    for k in range(n):
        x = -largura / 2 + 0.2 + (largura - 0.4) * (k + 0.5) / n
        partes.append(cubo(nome + "_Almofada", ((largura - 0.4) / n - 0.03, 0.6, 0.14), (x, 0.08, 0.49), cor=m, chanfro=0.05))
    return _grupo(nome, partes, pos, rot)


def cama(pos=(0, 0), rot=0, largura=1.6, comprimento=2.0, cor=None, cor_lencol=None, nome="Cama"):
    m = _cor(cor, (0.4, 0.26, 0.15), nome + "_mat")
    l = _cor(cor_lencol, (0.9, 0.9, 0.92), nome + "_lencol")
    partes = [cubo(nome + "_Estrado", (largura, comprimento, 0.3), (0, 0, 0.15), cor=m, chanfro=0.02),
              cubo(nome + "_Colchao", (largura - 0.06, comprimento - 0.06, 0.22), (0, 0, 0.41), cor=l, chanfro=0.04),
              cubo(nome + "_Cabeceira", (largura, 0.08, 1.0), (0, -comprimento / 2 + 0.04, 0.5), cor=m, chanfro=0.02)]
    for x in (-largura / 4, largura / 4):
        partes.append(cubo(nome + "_Travesseiro", (largura / 2 - 0.15, 0.4, 0.12), (x, -comprimento / 2 + 0.35, 0.58), cor=l, chanfro=0.05))
    return _grupo(nome, partes, pos, rot)


def estante(pos=(0, 0), rot=0, largura=1.0, altura=1.8, prateleiras=5, cor=None, nome="Estante"):
    m = _cor(cor, (0.55, 0.4, 0.25), nome + "_mat")
    p = 0.35
    partes = [cubo(nome + "_Lado", (0.03, p, altura), (x, 0, altura / 2), cor=m) for x in (-largura / 2, largura / 2)]
    partes.append(cubo(nome + "_Fundo", (largura, 0.02, altura), (0, -p / 2, altura / 2), cor=m))
    for k in range(prateleiras + 1):
        partes.append(cubo(nome + "_Prateleira", (largura, p, 0.03), (0, 0, 0.015 + k * (altura - 0.03) / prateleiras), cor=m))
    return _grupo(nome, partes, pos, rot)


def luminaria(pos=(0, 0), rot=0, altura=0.55, cor=None, cor_cupula=None, nome="Luminaria"):
    m = _cor(cor, (0.15, 0.15, 0.17), nome + "_mat")
    c = _cor(cor_cupula, (0.95, 0.85, 0.6), nome + "_cupula")
    partes = [cilindro(nome + "_Base", 0.09, 0.03, (0, 0, 0.015), cor=m),
              cilindro(nome + "_Haste", 0.012, altura - 0.15, (0, 0, (altura - 0.15) / 2 + 0.03), cor=m),
              cone(nome + "_Cupula", 0.14, 0.08, 0.16, (0, 0, altura - 0.04), cor=c),
              esfera(nome + "_Lampada", 0.035, (0, 0, altura - 0.08), cor=material(nome + "_luz", (1, 0.9, 0.6), emissao=5))]
    return _grupo(nome, partes, pos, rot)


def casa(pos=(0, 0), rot=0, largura=8.0, profundidade=6.0, altura=3.0, cor=None, cor_telhado=None, nome="Casa"):
    pa = _cor(cor, (0.9, 0.86, 0.78), nome + "_parede")
    te = _cor(cor_telhado, (0.6, 0.18, 0.12), nome + "_telhado")
    vidro = material(nome + "_vidro", (0.5, 0.7, 0.9), metal=0.2, rugosidade=0.1)
    porta_m = material(nome + "_porta", (0.35, 0.2, 0.1))
    partes = [cubo(nome + "_Paredes", (largura, profundidade, altura), (0, 0, altura / 2), cor=pa)]
    bpy.ops.mesh.primitive_cone_add(vertices=4, radius1=max(largura, profundidade) * 0.78, depth=altura * 0.7, location=(0, 0, altura + altura * 0.35), rotation=(0, 0, math.radians(45)))
    tel = bpy.context.active_object
    tel.scale = (largura / max(largura, profundidade), profundidade / max(largura, profundidade), 1)
    partes.append(_pronto(tel, nome + "_Telhado", te))
    partes.append(cubo(nome + "_Porta", (1.0, 0.06, 2.1), (0, profundidade / 2 + 0.02, 1.05), cor=porta_m))
    for x in (-largura / 3, largura / 3):
        partes.append(cubo(nome + "_Janela", (1.2, 0.06, 1.0), (x, profundidade / 2 + 0.02, altura * 0.55), cor=vidro))
    return _grupo(nome, partes, pos, rot)


def predio(pos=(0, 0), rot=0, andares=10, largura=10.0, profundidade=10.0, cor=None, nome="Predio"):
    c = _cor(cor, (0.55, 0.58, 0.62), nome + "_mat")
    vidro = material(nome + "_vidro", (0.25, 0.4, 0.6), metal=0.4, rugosidade=0.1)
    h = andares * 3.2
    partes = [cubo(nome + "_Corpo", (largura, profundidade, h), (0, 0, h / 2), cor=c)]
    for k in range(andares):
        z = 1.6 + k * 3.2
        partes.append(cubo(nome + "_Vidro", (largura + 0.06, profundidade + 0.06, 1.4), (0, 0, z), cor=vidro))
    partes.append(cubo(nome + "_Topo", (largura * 0.4, profundidade * 0.4, 2.5), (0, 0, h + 1.25), cor=c))
    return _grupo(nome, partes, pos, rot)


def arvore(pos=(0, 0), altura=4.0, cor_folhas=None, nome="Arvore"):
    tronco = material(nome + "_tronco", (0.35, 0.22, 0.12))
    folhas = _cor(cor_folhas, (0.18, 0.5, 0.2), nome + "_folhas")
    t = altura * 0.45
    partes = [cilindro(nome + "_Tronco", altura * 0.04, t, (0, 0, t / 2), cor=tronco)]
    for k, (dx, dy, r) in enumerate([(0, 0, 0.32), (0.15, 0.1, 0.25), (-0.15, -0.08, 0.24), (0.05, -0.15, 0.22)]):
        partes.append(esfera(nome + "_Copa", altura * r, (altura * dx, altura * dy, t + altura * (0.18 + 0.1 * k)), cor=folhas))
    return _grupo(nome, partes, pos)


# Perfis de carro (genéricos, sem marca). t vai de 0 (traseira) a 1 (frente).
# corpo: altura do topo da lataria (capô, cintura, tampa do porta-malas); teto: linha da cabine de vidro;
# planta: largura relativa vista de cima (frente e traseira afinam).
PERFIS_CARRO = {
    "sedan": dict(comprimento=4.75, largura=1.85, chao=0.17, roda=0.34, pneu=0.24, eixos=(0.18, 0.79), base=0.90, teto_l=0.70,
                  corpo=[(0, 0.58), (0.015, 0.80), (0.05, 0.93), (0.22, 0.97), (0.30, 0.98), (0.68, 0.96), (0.74, 0.93), (0.93, 0.84), (0.985, 0.72), (1, 0.52)],
                  teto=[(0.26, 0.97), (0.40, 1.40), (0.58, 1.43), (0.72, 0.94)]),
    "suv": dict(comprimento=4.75, largura=1.93, chao=0.25, roda=0.39, pneu=0.26, eixos=(0.18, 0.80), base=0.92, teto_l=0.76,
                corpo=[(0, 0.75), (0.015, 1.00), (0.04, 1.08), (0.70, 1.10), (0.76, 1.06), (0.94, 0.98), (0.985, 0.86), (1, 0.62)],
                teto=[(0.03, 1.07), (0.07, 1.72), (0.62, 1.76), (0.745, 1.06)]),
    "esportivo": dict(comprimento=4.5, largura=1.96, chao=0.11, roda=0.34, pneu=0.27, eixos=(0.17, 0.80), base=0.86, teto_l=0.64,
                      corpo=[(0, 0.62), (0.02, 0.86), (0.08, 0.92), (0.30, 0.90), (0.62, 0.84), (0.72, 0.78), (0.93, 0.68), (0.985, 0.56), (1, 0.40)],
                      teto=[(0.20, 0.90), (0.40, 1.20), (0.52, 1.22), (0.69, 0.79)]),
    "picape": dict(comprimento=5.35, largura=1.98, chao=0.32, roda=0.41, pneu=0.28, eixos=(0.17, 0.79), base=0.92, teto_l=0.78,
                   corpo=[(0, 1.02), (0.01, 1.12), (0.40, 1.14), (0.42, 1.15), (0.72, 1.15), (0.78, 1.12), (0.95, 1.08), (0.99, 0.96), (1, 0.72)],
                   teto=[(0.405, 1.14), (0.42, 1.88), (0.66, 1.90), (0.77, 1.13)], cacamba=(0.015, 0.395)),
}
PLANTA_CARRO = [(0, 0.86), (0.04, 0.97), (0.10, 1.0), (0.90, 1.0), (0.965, 0.95), (1, 0.84)]


def _curva(pontos, t):
    if t <= pontos[0][0]:
        return pontos[0][1]
    for (t0, v0), (t1, v1) in zip(pontos, pontos[1:]):
        if t <= t1:
            return v0 + (v1 - v0) * (t - t0) / max(1e-6, t1 - t0)
    return pontos[-1][1]


def _loft(nome, aneis_pts, materiais, mat_face, vincos=(), fechar=True, niveis=2, vinco_pontas=0.0, mat_pontas=0):
    """Malha a partir de anéis de seção (listas de (x,y,z)); mat_face(k, i) diz o material de cada face;
    vincos: índices de vértice do anel cujas arestas longitudinais ficam mais vivas na suavização."""
    import bmesh
    malha = bpy.data.meshes.new(nome)
    obj = bpy.data.objects.new(nome, malha)
    bpy.context.collection.objects.link(obj)
    bm = bmesh.new()
    aneis = [[bm.verts.new(p) for p in anel] for anel in aneis_pts]
    m = len(aneis[0])
    for k in range(len(aneis) - 1):
        a, b = aneis[k], aneis[k + 1]
        for i in range(m):
            j = (i + 1) % m
            f = bm.faces.new((a[i], a[j], b[j], b[i]))
            f.material_index = mat_face(k, i)
    if fechar:
        for tampa in (bm.faces.new(list(reversed(aneis[0]))), bm.faces.new(aneis[-1])):
            tampa.material_index = mat_pontas
    vinco = bm.edges.layers.float.get("crease_edge") or bm.edges.layers.float.new("crease_edge")
    for k in range(len(aneis) - 1):
        for i, forca in vincos:
            e = bm.edges.get((aneis[k][i], aneis[k + 1][i]))
            if e:
                e[vinco] = forca
    if vinco_pontas:  # bordas da frente e da traseira mais definidas
        for anel in (aneis[0], aneis[-1]):
            for i in range(m):
                e = bm.edges.get((anel[i], anel[(i + 1) % m]))
                if e:
                    e[vinco] = vinco_pontas
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(malha)
    bm.free()
    for mt in materiais:
        malha.materials.append(mt)
    for f in malha.polygons:
        f.use_smooth = True
    sub = obj.modifiers.new("Suave", "SUBSURF")
    sub.levels = sub.render_levels = niveis
    return obj


def _torneado(nome, perfil, cor, pos, lado=1, segmentos=64):
    """Gira um perfil [(raio, y)] em torno do eixo Y (pneus, aros). y positivo aponta para fora do carro."""
    import bmesh
    malha = bpy.data.meshes.new(nome)
    obj = bpy.data.objects.new(nome, malha)
    bpy.context.collection.objects.link(obj)
    bm = bmesh.new()
    aneis = []
    for k in range(segmentos):
        a = 2 * math.pi * k / segmentos
        aneis.append([bm.verts.new((max(r, 0.002) * math.cos(a), y * lado, max(r, 0.002) * math.sin(a))) for r, y in perfil])
    for k in range(segmentos):
        A, B = aneis[k], aneis[(k + 1) % segmentos]
        for i in range(len(perfil) - 1):
            bm.faces.new((A[i], A[i + 1], B[i + 1], B[i]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(malha)
    bm.free()
    malha.materials.append(cor)
    for f in malha.polygons:
        f.use_smooth = True
    obj.location = pos
    return obj


def _adesivo(nome, alvo, x, y, z, largura, altura, cor, frente=1, afastar=0.004, inclinar=0.0):
    """Peça fina (farol, grade, placa) que se molda à lataria: uma grade de vértices
    projetada na superfície do alvo pelo modificador Shrinkwrap. frente=1 olha para +X, -1 para -X."""
    import bmesh
    malha = bpy.data.meshes.new(nome)
    obj = bpy.data.objects.new(nome, malha)
    bpy.context.collection.objects.link(obj)
    bm = bmesh.new()
    nu, nv = 18, 6
    grade = [[bm.verts.new((frente * (0.25 + inclinar * (j / nv - 0.5)), (i / nu - 0.5) * largura, (j / nv - 0.5) * altura)) for j in range(nv + 1)] for i in range(nu + 1)]
    for i in range(nu):
        for j in range(nv):
            f = bm.faces.new((grade[i][j], grade[i + 1][j], grade[i + 1][j + 1], grade[i][j + 1]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(malha)
    bm.free()
    if frente * malha.polygons[0].normal.x < 0:
        malha.flip_normals()
    malha.materials.append(cor)
    for f in malha.polygons:
        f.use_smooth = True
    obj.location = (x, y, z)
    mod = obj.modifiers.new("Molde", "SHRINKWRAP")
    mod.target = alvo
    mod.wrap_method = "NEAREST_SURFACEPOINT"
    mod.offset = afastar
    return obj


def _roda(nome, x, y, R, Wt, lado, mats):
    """Roda completa: pneu com sulcos, aro de liga com borda e raios duplos, disco, pinça de freio e porcas."""
    pneu, aro, escuro, disco, pinca, cromo = mats
    h = Wt / 2
    Rr = R * 0.68  # raio do aro
    perfil_pneu = [(Rr * 0.98, -h + 0.01), (R * 0.84, -h - 0.004), (R * 0.95, -h + 0.008), (R, -h + 0.035)]
    for g in (-0.55, 0.0, 0.55):  # sulcos da banda de rodagem
        c = g * h
        perfil_pneu += [(R, c - 0.016), (R - 0.012, c - 0.011), (R - 0.012, c + 0.011), (R, c + 0.016)]
    perfil_pneu += [(R, h - 0.035), (R * 0.95, h - 0.008), (R * 0.84, h + 0.004), (Rr * 0.98, h - 0.01)]
    partes = [_torneado(nome + "_Pneu", perfil_pneu, pneu, (x, y, R), lado)]
    # aro: barril, borda polida e "prato" côncavo
    perfil_aro = [(Rr * 0.97, -h + 0.02), (Rr, -h + 0.03), (Rr, h - 0.03), (Rr * 1.03, h - 0.012), (Rr * 1.0, h - 0.002),
                  (Rr * 0.94, h - 0.012), (Rr * 0.9, h - 0.05), (Rr * 0.88, h - 0.12)]
    partes.append(_torneado(nome + "_Aro", perfil_aro, aro, (x, y, R), lado, 48))
    partes.append(cilindro(nome + "_Fundo", Rr * 0.97, 0.01, (x, y - lado * (h - 0.04), R), rot=(math.radians(90), 0, 0), cor=escuro, lados=40))
    yd = y + lado * (h - 0.12)
    partes.append(cilindro(nome + "_Disco", Rr * 0.8, 0.028, (x, yd, R), rot=(math.radians(90), 0, 0), cor=disco, lados=40))
    partes.append(cubo(nome + "_Pinca", (0.16, 0.06, 0.1), (x - Rr * 0.55, yd + lado * 0.03, R + Rr * 0.42), rot=(0, math.radians(-40), 0), cor=pinca, chanfro=0.015))
    yr = y + lado * (h - 0.035)
    for r in range(5):  # raios duplos
        for d in (-0.13, 0.13):
            ang = r * 2 * math.pi / 5 + d
            dist = Rr * 0.5
            partes.append(cubo(nome + "_Raio", (0.035, 0.03, Rr * 0.86), (x + math.sin(ang) * dist, yr, R + math.cos(ang) * dist), rot=(0, ang, 0), cor=aro, chanfro=0.008))
    partes.append(_torneado(nome + "_Cubo", [(0.002, h + 0.004), (0.05, h + 0.002), (0.085, h - 0.02), (0.09, h - 0.05)], aro, (x, y, R), lado, 32))
    for r in range(5):
        ang = r * 2 * math.pi / 5 + math.pi / 5
        partes.append(cilindro(nome + "_Porca", 0.011, 0.02, (x + math.sin(ang) * 0.062, y + lado * (h - 0.004), R + math.cos(ang) * 0.062), rot=(math.radians(90), 0, 0), cor=cromo, lados=6))
    return partes


def carro(pos=(0, 0), rot=0, cor=None, tipo="sedan", nome="Carro"):
    """Carro realista genérico virado para +X. tipo: sedan, suv, esportivo ou picape.
    Lataria com vincos (ombro e cintura), cabine de vidro escuro com teto pintado, caixas de roda,
    rodas de liga com pneus de sulcos, freios, faróis com LED, lanterna em barra, grade, maçanetas,
    retrovisores, frisos de porta, escapamento e placas."""
    p = PERFIS_CARRO.get(str(tipo).lower(), PERFIS_CARRO["sedan"])
    if sketchfab and sketchfab.token() and not isinstance(cor, bpy.types.Material):
        try:  # carro de verdade (Sketchfab, grátis) no lugar do procedural
            caminho, info = sketchfab.obter(BUSCA_CARRO.get(str(tipo).lower(), "car"), categoria="cars-vehicles", exigir=EXIGIR_CARRO.get(str(tipo).lower()))
            print(f"JARVIS_REAL: carro {tipo} -> Sketchfab {info.get("name")}")
            raiz = _importar(caminho, nome, pos, rot, comprimento=p["comprimento"], deitar_no_x=True, tirar_base=False)
            if cor:
                _pintar(raiz, cor)
            return raiz
        except Exception as erro:
            print("JARVIS_AVISO: carro real indisponível, usando o procedural:", erro)
    L, W, chao, R, Wt = p["comprimento"], p["largura"], p["chao"], p["roda"], p["pneu"]
    pintura = cor if isinstance(cor, bpy.types.Material) else material(nome + "_pintura", cor or (0.62, 0.05, 0.08), tipo="pintura")
    vidro = material(nome + "_cristal", (0.012, 0.014, 0.018), rugosidade=0.02, tipo="liso")
    preto = material(nome + "_plastico", (0.018, 0.018, 0.02), rugosidade=0.6, tipo="liso")
    preto_brilho = material(nome + "_piano", (0.01, 0.01, 0.012), rugosidade=0.08, tipo="liso")
    pneu = material(nome + "_pneu", (0.022, 0.022, 0.024), tipo="borracha")
    aro = material(nome + "_liga", (0.62, 0.63, 0.66), metal=1.0, rugosidade=0.18, tipo="liso")
    disco = material(nome + "_freio", (0.35, 0.35, 0.36), metal=1.0, rugosidade=0.45, tipo="liso")
    pinca = material(nome + "_pinca", (0.7, 0.05, 0.03), rugosidade=0.35, tipo="liso")
    cromo = material(nome + "_cromado", (0.92, 0.92, 0.94), metal=1.0, rugosidade=0.06, tipo="liso")
    led = material(nome + "_led", (1, 0.98, 0.94), emissao=12, tipo="liso")
    farol = material(nome + "_farol", (0.9, 0.55, 0.15), rugosidade=0.1, emissao=1.5, tipo="liso")
    lente = material(nome + "_lente", (0.75, 0.78, 0.82), metal=0.6, rugosidade=0.05, emissao=1.2, tipo="liso")
    lanterna = material(nome + "_lanterna", (0.75, 0.02, 0.02), emissao=6, tipo="liso")
    placa = material(nome + "_placa", (0.9, 0.9, 0.92), rugosidade=0.4, tipo="liso")

    def meia(t):
        return W / 2 * _curva(PLANTA_CARRO, t)

    def x_de(t):
        return -L / 2 + t * L

    # --- lataria inferior (14 vértices por seção, com ombro vincado) ---
    n = 44
    estacoes = [k / n for k in range(n + 1)]
    aneis = []
    for t in estacoes:
        w, zt = meia(t), _curva(p["corpo"], t)
        z0 = chao + (0.06 if t < 0.05 or t > 0.95 else 0.0)
        hh = max(zt - z0, 0.1)
        ombro = max(z0 + 0.5 * hh, zt - 0.12)
        crista = 0.015
        lado_d = [(0, z0), (0.84 * w, z0), (0.97 * w, z0 + 0.1 * hh), (w, z0 + 0.42 * hh), (0.99 * w, ombro),
                  (0.95 * w, zt - 0.02), (0.6 * w, zt + 0.7 * crista), (0, zt + crista)]
        anel = lado_d + [(-y, z) for y, z in reversed(lado_d[1:-1])]
        aneis.append([(x_de(t), y, z) for y, z in anel])

    # faces do anel: 0/13 fundo, 1-2/11-12 saia, 3/10 lateral, 4/9 ombro, 5-6/7-8 capô e tampa
    def mat_lataria(k, i):
        if i in (0, 13):
            return 1
        if k == n - 1 and i in (1, 12):
            return 1  # parte baixa do para-choque
        return 0

    lat = _loft(nome + "_Lataria", aneis, [pintura, preto, farol, lanterna], mat_lataria,
                vincos=[(4, 1.0), (10, 1.0), (1, 0.6), (13, 0.6), (2, 0.5), (12, 0.5), (5, 0.4), (9, 0.4)], vinco_pontas=0.55)

    # --- cabine: vidro escuro com teto na cor do carro ---
    t0, t1 = p["teto"][0][0], p["teto"][-1][0]
    m_cab = 30
    est_cab = [t0 + (t1 - t0) * k / m_cab for k in range(m_cab + 1)]
    aneis_cab, inclinacao = [], []
    for t in est_cab:
        w = meia(t)
        zb = _curva(p["corpo"], t) - 0.03
        zt = max(_curva(p["teto"], t), zb + 0.02)
        wb, wr = w * p["base"], w * p["teto_l"]
        hh = zt - zb
        lado_d = [(0, zb), (wb, zb), (wb * 0.55 + wr * 0.45 + 0.02, zb + 0.5 * hh), (wr, zt - min(0.05, 0.25 * hh)), (wr * 0.55, zt), (0, zt + 0.012)]
        anel = lado_d + [(-y, z) for y, z in reversed(lado_d[1:-1])]
        aneis_cab.append([(x_de(t), y, z) for y, z in anel])
    for k in range(m_cab):
        dz = abs(_curva(p["teto"], est_cab[k + 1]) - _curva(p["teto"], est_cab[k]))
        inclinacao.append(dz / ((est_cab[k + 1] - est_cab[k]) * L))

    def mat_cabine(k, i):
        if i in (1, 2, 7, 8):  # janelas laterais
            return 1
        if i in (3, 4, 5, 6):  # teto (ou para-brisa / vidro traseiro onde é inclinado)
            return 1 if inclinacao[k] > 0.35 else 0
        return 2

    cab = _loft(nome + "_Cabine", aneis_cab, [pintura, vidro, preto], mat_cabine, vincos=[(1, 1.0), (9, 1.0), (3, 0.6), (7, 0.6)], mat_pontas=2)
    partes = [lat, cab]

    # coluna B e frisos pretos das janelas
    t_b = t0 + (t1 - t0) * 0.52
    zb_b, zt_b = _curva(p["corpo"], t_b), _curva(p["teto"], t_b)
    for lado in (-1, 1):
        yb = lado * (meia(t_b) * (p["base"] + p["teto_l"]) / 2 + 0.018)
        inc = math.atan2((meia(t_b) * (p["base"] - p["teto_l"])), zt_b - zb_b)
        partes.append(cubo(nome + "_ColunaB", (0.09, 0.02, (zt_b - zb_b) * 0.82), (x_de(t_b), yb, zb_b + (zt_b - zb_b) * 0.45), rot=(lado * inc, 0, 0), cor=preto_brilho, chanfro=0.006))

    # --- caixas de roda (recortadas na lataria, interior preto) e rodas ---
    for i_eixo, t in enumerate(p["eixos"]):
        x = x_de(t)
        corte = cilindro(nome + "_CaixaRoda", R * 1.13, W * 1.4, (x, 0, R + 0.02), rot=(math.radians(90), 0, 0), cor=preto, lados=48)
        corte.hide_render = True
        corte.display_type = "WIRE"
        bo = lat.modifiers.new("CaixaRoda", "BOOLEAN")
        bo.operation = "DIFFERENCE"
        bo.object = corte
        try:
            bo.material_mode = "TRANSFER"
        except Exception:
            pass
        partes.append(corte)
        for lado in (-1, 1):
            y = lado * (W / 2 - Wt / 2 - 0.035)
            partes += _roda(nome + "_Roda", x, y, R, Wt, lado, (pneu, aro, preto, disco, pinca, cromo))
    if p.get("cacamba"):  # caçamba aberta da picape
        a, b = p["cacamba"]
        zc = _curva(p["corpo"], (a + b) / 2)
        corte = cubo(nome + "_Cacamba", ((b - a) * L, W * 0.84, 0.55), (x_de((a + b) / 2), 0, zc + 0.04 - 0.275 + 0.3), cor=preto, chanfro=0)
        corte.hide_render = True
        corte.display_type = "WIRE"
        bo = lat.modifiers.new("Cacamba", "BOOLEAN")
        bo.operation = "DIFFERENCE"
        bo.object = corte
        try:
            bo.material_mode = "TRANSFER"
        except Exception:
            pass
        partes.append(corte)

    # --- detalhes: retrovisores, portas, frente e traseira ---
    frente, tras = L / 2, -L / 2
    z_capo = _curva(p["corpo"], 0.975)
    z_nariz = chao + 0.06
    t_ra = p["eixos"][0] + R * 1.25 / L  # portas ficam entre as caixas de roda
    t_fa = p["eixos"][1] - R * 1.25 / L
    esportivo = str(tipo).lower() == "esportivo"
    portas = [max(t_ra, t0 + (t1 - t0) * 0.35), min(t_fa, t1 + 0.02)] if esportivo else [max(t_ra, t0 + (t1 - t0) * 0.08), t_b, min(t_fa, t1 + 0.02)]
    for lado in (-1, 1):
        # retrovisor ao lado do pé do para-brisa, para fora da lataria
        t_esp = t1 - 0.035
        ze = _curva(p["corpo"], t_esp) + 0.11
        partes.append(esfera(nome + "_Retrovisor", 0.1, (x_de(t_esp), lado * (meia(t_esp) + 0.06), ze), cor=pintura, escala=(0.75, 1.0, 0.62)))
        for tp in portas:  # frisos (vãos) das portas
            zc = _curva(p["corpo"], tp) - 0.05
            partes.append(cubo(nome + "_FrisoPorta", (0.007, 0.012, zc - chao - 0.1), (x_de(tp), lado * meia(tp) * 0.995, (zc + chao + 0.1) / 2), cor=preto, chanfro=0))
        for tp in portas[:-1]:
            xm = x_de(tp) + (0.35 if not esportivo else 0.5)
            zm = _curva(p["corpo"], tp) - 0.1
            partes.append(cubo(nome + "_Macaneta", (0.15, 0.025, 0.025), (xm, lado * (meia(tp) + 0.004), zm), cor=cromo, chanfro=0.008))
        partes.append(cilindro(nome + "_Escape", 0.04, 0.16, (tras + 0.1, lado * W * 0.28, chao + 0.07), rot=(0, math.radians(90), 0), cor=cromo, lados=24))
    # grade, entrada de ar, faróis, lanternas e placas moldados à lataria (rentes à superfície)
    altura_frente = z_capo - z_nariz
    colmeia = material(nome + "_colmeia", (0.02, 0.02, 0.022), tipo="colmeia")
    xf, xt = frente - 0.1, tras + 0.1
    zf = lambda f: z_nariz + altura_frente * f
    partes.append(_adesivo(nome + "_Grade", lat, xf, 0, zf(0.62), W * 0.34, altura_frente * 0.26, colmeia, 1))
    partes.append(_adesivo(nome + "_EntradaAr", lat, xf, 0, zf(0.13), W * 0.62, altura_frente * 0.14, colmeia, 1))
    partes.append(_adesivo(nome + "_PlacaD", lat, xf, 0, zf(0.34), 0.42, 0.12, placa, 1, 0.007))
    z_tr0 = chao + 0.06
    z_tr1 = _curva(p["corpo"], 0.0)
    z_lant = (z_tr0 + z_tr1) / 2 + 0.12
    for lado in (-1, 1):
        partes.append(_adesivo(nome + "_Farol", lat, xf, lado * W * 0.31, zf(0.8), W * 0.24, 0.085, lente, 1))
        partes.append(_adesivo(nome + "_LED", lat, xf, lado * W * 0.31, zf(0.8) + 0.05, W * 0.24, 0.014, led, 1, 0.006))
        partes.append(_adesivo(nome + "_Lanterna", lat, xt, lado * W * 0.32, z_lant, W * 0.26, 0.075, lanterna, -1))
    partes.append(_adesivo(nome + "_BarraLuz", lat, xt, 0, z_lant + 0.02, W * 0.4, 0.022, lanterna, -1))
    partes.append(_adesivo(nome + "_PlacaT", lat, xt, 0, z_tr0 + (z_tr1 - z_tr0) * 0.42, 0.42, 0.12, placa, -1, 0.007))
    partes.append(cubo(nome + "_Difusor", (0.1, W * 0.72, 0.09), (tras + 0.07, 0, chao + 0.07), cor=preto, chanfro=0.02))
    return _grupo(nome, partes, pos, rot)


def poste(pos=(0, 0), rot=0, altura=5.0, nome="Poste"):
    m = material(nome + "_mat", (0.2, 0.2, 0.22), metal=0.6)
    partes = [cilindro(nome + "_Haste", 0.07, altura, (0, 0, altura / 2), cor=m),
              cubo(nome + "_Braco", (0.9, 0.08, 0.08), (0.45, 0, altura), cor=m),
              esfera(nome + "_Luz", 0.15, (0.85, 0, altura - 0.12), cor=material(nome + "_luz", (1, 0.9, 0.7), emissao=6))]
    return _grupo(nome, partes, pos, rot)


def pessoa(pos=(0, 0), rot=0, altura=1.75, cor=None, nome="Pessoa"):
    """Boneco genérico (manequim) para dar escala à cena."""
    roupa = _cor(cor, (0.2, 0.3, 0.5), nome + "_roupa")
    pele = material(nome + "_pele", (0.85, 0.68, 0.55))
    k = altura / 1.75
    partes = [cilindro(nome + "_Perna", 0.08 * k, 0.85 * k, (x * k, 0, 0.425 * k), cor=roupa) for x in (-0.1, 0.1)]
    partes.append(cubo(nome + "_Tronco", (0.42 * k, 0.24 * k, 0.6 * k), (0, 0, 1.15 * k), cor=roupa, chanfro=0.05 * k))
    partes += [cilindro(nome + "_Braco", 0.055 * k, 0.6 * k, (x * k, 0, 1.15 * k), cor=roupa) for x in (-0.28, 0.28)]
    partes.append(esfera(nome + "_Cabeca", 0.12 * k, (0, 0, 1.6 * k), cor=pele))
    return _grupo(nome, partes, pos, rot)


def garagem(pos=(0, 0), rot=0, vagas=2, cor=None, nome="Garagem"):
    """Garagem aberta na frente (+X), com piso, paredes, teto e uma luz; cabe um carro por vaga (3 m cada)."""
    largura, fundo, altura = vagas * 3.0, 6.0, 2.8
    pa = _cor(cor, (0.82, 0.8, 0.76), nome + "_parede")
    piso = material(nome + "_piso", (0.5, 0.5, 0.5), tipo="concreto")
    partes = [cubo(nome + "_Piso", (fundo, largura, 0.1), (0, 0, 0.05), cor=piso, chanfro=0.01),
              cubo(nome + "_Fundo", (0.2, largura, altura), (-fundo / 2, 0, altura / 2), cor=pa),
              cubo(nome + "_Teto", (fundo + 0.3, largura + 0.4, 0.15), (0.15, 0, altura + 0.075), cor=pa)]
    for lado in (-1, 1):
        partes.append(cubo(nome + "_Lateral", (fundo, 0.2, altura), (0, lado * largura / 2, altura / 2), cor=pa))
    for k in range(1, vagas):
        partes.append(cubo(nome + "_Faixa", (fundo * 0.8, 0.08, 0.005), (0.3, -largura / 2 + k * 3.0, 0.103), cor=material(nome + "_faixa", (0.95, 0.85, 0.1))))
    partes.append(cubo(nome + "_Luz", (1.2, 0.15, 0.05), (0, 0, altura - 0.03), cor=material(nome + "_luzm", (1, 0.97, 0.9), emissao=8)))
    return _grupo(nome, partes, pos, rot)


# ---------- recursos reais (Poly Haven, CC0): cenário de foto real e objetos escaneados ----------
try:
    _pasta_base = os.path.dirname(os.path.abspath(__file__))
except NameError:
    _pasta_base = os.path.dirname(os.path.abspath(sys.argv[sys.argv.index("--python") + 1]))
sys.path.insert(0, _pasta_base)
try:
    import polyhaven
except Exception as _erro_ph:
    polyhaven = None
    print("JARVIS_AVISO: módulo polyhaven indisponível:", _erro_ph)
AMBIENTE = {"nome": None}


def ambiente(nome="estacionamento"):
    """Cenário de foto real: estacionamento, rua, cidade, garagem, estudio, campo, floresta, por_do_sol, noite ou interior."""
    chave = str(nome).lower().strip()
    if polyhaven:
        chave = polyhaven.SINONIMOS_AMBIENTE.get(chave, chave)
        if chave not in polyhaven.AMBIENTES:
            chave = "estacionamento"
    AMBIENTE["nome"] = chave
    return chave


try:
    import sketchfab
except Exception as _erro_sf:
    sketchfab = None
    print("JARVIS_AVISO: módulo sketchfab indisponível:", _erro_sf)


def _importar(caminho, nome, pos=(0, 0), rot=0, altura=None, comprimento=None, deitar_no_x=False, tirar_base=True):
    """Importa um .glb/.gltf, junta tudo sob um objeto pai, apoia no chão em pos e ajusta o tamanho."""
    antes = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=caminho)
    novos = [o for o in bpy.data.objects if o not in antes]
    malhas = [o for o in novos if o.type == "MESH"]
    if not malhas:
        raise RuntimeError("o arquivo importado veio vazio")
    # descarta lixo do arquivo: guias/linhas de animação com poucas faces e tamanho fora de proporção
    bpy.context.view_layer.update()
    total_faces = sum(len(o.data.polygons) for o in malhas) or 1
    principal = max(malhas, key=lambda o: len(o.data.polygons))
    diag_principal = max(principal.dimensions.length, 1e-6)
    for o in list(malhas):
        if o is principal or len(o.data.polygons) > 0.01 * total_faces:
            continue
        diag = o.dimensions.length
        if diag > 3 * diag_principal or diag < 0.005 * diag_principal or len(o.data.polygons) == 0:
            print("JARVIS_AVISO: peça descartada:", o.name)
            malhas.remove(o)
            novos.remove(o)
            bpy.data.objects.remove(o, do_unlink=True)
    # tira câmeras/luzes do arquivo e a "base de exposição" (chão/pedestal achatado embaixo de tudo)
    bpy.context.view_layer.update()
    for o in [o for o in novos if o.type in {"CAMERA", "LIGHT"}]:
        novos.remove(o)
        bpy.data.objects.remove(o, do_unlink=True)
    if tirar_base:  # base grudada na mesma malha: separa as peças soltas das malhas largas para achá-la
        bpy.context.view_layer.update()
        cs = [o.matrix_world @ Vector(c) for o in malhas for c in o.bound_box]
        area_tudo = (max(c.x for c in cs) - min(c.x for c in cs)) * (max(c.y for c in cs) - min(c.y for c in cs))
        for o in list(malhas):
            oc = [o.matrix_world @ Vector(c) for c in o.bound_box]
            area_o = (max(c.x for c in oc) - min(c.x for c in oc)) * (max(c.y for c in oc) - min(c.y for c in oc))
            if area_o < 0.35 * area_tudo or len(o.data.polygons) > 30000:
                continue
            try:
                bpy.ops.object.select_all(action="DESELECT")
                o.select_set(True)
                bpy.context.view_layer.objects.active = o
                bpy.ops.object.mode_set(mode="EDIT")
                bpy.ops.mesh.select_all(action="SELECT")
                bpy.ops.mesh.separate(type="LOOSE")
                bpy.ops.object.mode_set(mode="OBJECT")
                for p in bpy.context.selected_objects:
                    if p not in malhas:
                        malhas.append(p)
                        novos.append(p)
            except Exception as erro:
                print("JARVIS_AVISO: não separei as peças:", erro)
                try:
                    bpy.ops.object.mode_set(mode="OBJECT")
                except Exception:
                    pass
    if tirar_base and len(malhas) > 1:
        def caixa_de(o):
            cs = [o.matrix_world @ Vector(c) for c in o.bound_box]
            return (min(c.x for c in cs), max(c.x for c in cs), min(c.y for c in cs), max(c.y for c in cs), min(c.z for c in cs), max(c.z for c in cs))
        caixas = {o: caixa_de(o) for o in malhas}
        z0, z1 = min(c[4] for c in caixas.values()), max(c[5] for c in caixas.values())
        area_total = (max(c[1] for c in caixas.values()) - min(c[0] for c in caixas.values())) * (max(c[3] for c in caixas.values()) - min(c[2] for c in caixas.values()))
        for o, c in caixas.items():
            achatado = (c[5] - c[4]) < 0.06 * (z1 - z0)
            embaixo = c[5] < z0 + 0.12 * (z1 - z0)
            largo = (c[1] - c[0]) * (c[3] - c[2]) > 0.35 * area_total
            nome_base = re.search(r"base|ground|floor|plane|pedestal|platform|stand|plinth|backdrop|chao|shadow", o.name, re.I)
            if (achatado and embaixo and largo) or (nome_base and embaixo):
                print("JARVIS_AVISO: base removida:", o.name)
                malhas.remove(o)
                novos.remove(o)
                bpy.data.objects.remove(o, do_unlink=True)
        if not malhas:
            raise RuntimeError("o arquivo só tinha a base")
    if tirar_base and malhas:  # base fundida na mesma malha: corta a faixa achatada de baixo quando ela é larga
        import bmesh
        bpy.context.view_layer.update()
        pts = [(o.matrix_world @ v.co) for o in malhas for v in o.data.vertices]
        z0, z1 = min(p.z for p in pts), max(p.z for p in pts)
        faixa = z0 + 0.05 * (z1 - z0)
        baixo = [p for p in pts if p.z <= faixa]
        area_total = (max(p.x for p in pts) - min(p.x for p in pts)) * (max(p.y for p in pts) - min(p.y for p in pts))
        if len(baixo) > 3:
            area_baixo = (max(p.x for p in baixo) - min(p.x for p in baixo)) * (max(p.y for p in baixo) - min(p.y for p in baixo))
            # chapa larga embaixo e quase nada do modelo apoiado fora dela = pedestal
            if area_baixo > 0.5 * area_total and len(baixo) < 0.25 * len(pts):
                malhas_bm, area_plana = [], 0.0
                for o in malhas:
                    bm = bmesh.new()
                    bm.from_mesh(o.data)
                    mw = o.matrix_world
                    escala2 = abs(mw.to_scale().x * mw.to_scale().y)
                    fora = [f for f in bm.faces if all((mw @ v.co).z <= faixa for v in f.verts)]
                    area_plana += sum(f.calc_area() * escala2 for f in fora if abs((mw.to_3x3() @ f.normal).normalized().z) > 0.9)
                    malhas_bm.append((o, bm, fora))
                # só é pedestal se houver uma superfície plana grande embaixo (cascos e pés são pequenos)
                if area_plana > 0.3 * area_total:
                    for o, bm, fora in malhas_bm:
                        bmesh.ops.delete(bm, geom=fora, context="FACES")
                        bm.to_mesh(o.data)
                    print("JARVIS_AVISO: pedestal cortado,", sum(len(f) for _, _, f in malhas_bm), "faces")
                for _, bm, _ in malhas_bm:
                    bm.free()
    pai = bpy.data.objects.new(nome, None)
    bpy.context.collection.objects.link(pai)
    for o in novos:
        if o.parent is None:
            o.parent = pai
    bpy.context.view_layer.update()

    def caixa():
        bpy.context.view_layer.update()
        cantos = [o.matrix_world @ Vector(c) for o in malhas for c in o.bound_box]
        return (Vector((min(c.x for c in cantos), min(c.y for c in cantos), min(c.z for c in cantos))),
                Vector((max(c.x for c in cantos), max(c.y for c in cantos), max(c.z for c in cantos))))

    mn, mx = caixa()
    if deitar_no_x and (mx.y - mn.y) > (mx.x - mn.x):  # comprimento ao longo de X, como os carros do kit
        pai.rotation_euler.z = math.radians(90)
        mn, mx = caixa()
    escala = 1.0
    if comprimento:
        escala = float(comprimento) / max(mx.x - mn.x, mx.y - mn.y, 1e-4)
    elif altura:
        escala = float(altura) / max(mx.z - mn.z, 1e-4)
    pai.scale = (escala, escala, escala)
    mn, mx = caixa()
    pos = _v3(pos)
    pai.location += Vector((pos[0] - (mn.x + mx.x) / 2, pos[1] - (mn.y + mx.y) / 2, pos[2] - mn.z))
    # gira em torno do próprio centro: um pai extra no ponto de apoio
    giro = bpy.data.objects.new(nome + "_Giro", None)
    bpy.context.collection.objects.link(giro)
    giro.location = (pos[0], pos[1], pos[2])
    bpy.context.view_layer.update()
    pai.parent = giro
    pai.matrix_parent_inverse = giro.matrix_world.inverted()
    giro.rotation_euler.z = math.radians(rot)
    return giro


def objeto_real(busca, pos=(0, 0), rot=0, altura=None, nome=None):
    """Objeto 3D ESCANEADO de verdade do Poly Haven (móveis, plantas, pedras, utensílios, ferramentas...).
    busca em português ou inglês; altura em metros (opcional). Devolve o pai, apoiado no chão."""
    if not polyhaven:
        raise RuntimeError("objetos reais indisponíveis (sem módulo polyhaven)")
    id_m = polyhaven.buscar_modelo(busca)
    if not id_m:
        raise RuntimeError(f"nenhum objeto escaneado parecido com '{busca}'")
    print(f"JARVIS_REAL: '{busca}' -> Poly Haven {id_m}")
    return _importar(polyhaven.modelo(id_m), nome or ("Real_" + id_m), pos, rot, altura=altura)


def _em_ingles(busca):
    termos = [busca]
    if polyhaven:
        for pt, en in polyhaven.TRADUCAO.items():
            if re.search(r"\b" + re.escape(pt) + r"s?\b", busca.lower()):
                termos.append(en.split()[0])
    return " ".join(dict.fromkeys(termos))


def modelo_real(busca, pos=(0, 0), rot=0, altura=None, comprimento=None, nome=None):
    """QUALQUER coisa real da internet (Sketchfab, grátis): carros, motos, aviões, animais, personagens, prédios...
    busca em inglês funciona melhor (ex.: "motorcycle", "fighter jet", "horse"). altura ou comprimento em metros.
    Sem token do Sketchfab, tenta um objeto escaneado do Poly Haven."""
    if sketchfab and sketchfab.token():
        caminho, info = sketchfab.obter(_em_ingles(str(busca)))
        print(f"JARVIS_REAL: '{busca}' -> Sketchfab {info.get('name')} ({(info.get('license') or {}).get('label')})")
        return _importar(caminho, nome or ("Real_" + re.sub(r"\W+", "_", str(busca))[:30]), pos, rot, altura=altura, comprimento=comprimento)
    return objeto_real(busca, pos, rot, altura=altura, nome=nome)


def _caixa_mundo(obj):
    bpy.context.view_layer.update()
    pecas = [o for o in [obj, *obj.children_recursive] if o.type == "MESH"] or [obj]
    cantos = [o.matrix_world @ Vector(c) for o in pecas for c in o.bound_box]
    return (Vector((min(c.x for c in cantos), min(c.y for c in cantos), min(c.z for c in cantos))),
            Vector((max(c.x for c in cantos), max(c.y for c in cantos), max(c.z for c in cantos))))


def lado_a_lado(*objs, espaco=0.8):
    """Enfileira os objetos ao longo de Y, medindo o tamanho real de cada um, sem sobrepor."""
    objs = [o for o in objs if o is not None]
    y = 0.0
    for o in objs:
        mn, mx = _caixa_mundo(o)
        o.location.y += y - mn.y
        o.location.x -= (mn.x + mx.x) / 2
        y += (mx.y - mn.y) + espaco
    for o in objs:  # centraliza a fila na origem
        o.location.y -= (y - espaco) / 2
    return objs


BUSCA_CARRO = {"sedan": "sedan car", "suv": "suv car", "esportivo": "sports car", "picape": "pickup truck"}
EXIGIR_CARRO = {"sedan": "sedan|saloon", "suv": "suv|crossover|4x4|jeep|land cruiser|range rover", "esportivo": "sport|supercar|coupe|gt|racing|911|ferrari|lamborghini|mclaren", "picape": "pickup|pick-up|truck|f100|f-150|hilux|ranger"}


def _pintar(raiz, cor):
    """Troca a cor da pintura de um carro baixado (materiais com nome de lataria/pintura)."""
    padrao = re.compile(r"paint|body|carpaint|car_paint|exterior|lacquer|coat|chassis|carroceria", re.I)
    for o in raiz.children_recursive:
        for slot in getattr(o, "material_slots", []):
            m = slot.material
            if not m or not padrao.search(m.name) or not m.node_tree:
                continue
            for no in m.node_tree.nodes:
                if no.type == "BSDF_PRINCIPLED":
                    entrada = no.inputs["Base Color"]
                    for ligacao in list(entrada.links):
                        m.node_tree.links.remove(ligacao)
                    entrada.default_value = (*cor[:3], 1)


def _tolerante(f):
    """O modelo às vezes erra a ordem ou repete argumentos: reorganiza em vez de travar."""
    import functools
    import inspect
    assinatura = inspect.signature(f)
    nomes = [n for n, p in assinatura.parameters.items() if p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY)]

    @functools.wraps(f)
    def envolta(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except TypeError as erro:
            if "argument" not in str(erro):
                raise
            novos = {n: v for n, v in zip(nomes, args) if n not in kwargs}
            novos.update({k: v for k, v in kwargs.items() if k in nomes})
            print("JARVIS_AVISO: argumentos reorganizados em", f.__name__, "-", erro)
            return f(**novos)
    return envolta


KIT = {n: _tolerante(f) if callable(f) and n not in {"material"} else f for n, f in globals().items() if n in {"garagem", "ambiente", "objeto_real", "modelo_real", "lado_a_lado", 
    "material", "cubo", "cilindro", "esfera", "cone", "toro", "plano", "repetir", "espelhar", "subdividir", "girar_copias",
    "topo", "sobre", "no_chao", "mesa", "cadeira", "sofa", "cama", "estante", "luminaria", "casa", "predio", "arvore", "carro", "poste", "pessoa"}}

with open(script_modelo, encoding="utf-8") as arquivo:
    exec(compile(arquivo.read(), script_modelo, "exec"), {"__name__": "__main__", "bpy": bpy, "math": math, **KIT})

# caixa que envolve tudo o que foi modelado
objetos = [o for o in cena.objects if o.type in {"MESH", "CURVE", "SURFACE", "META", "FONT"}]
if not objetos:
    raise SystemExit("JARVIS_ERRO: o script não criou nenhum objeto.")
# o enquadramento ignora chãos planos (eles deixariam o modelo pequeno na imagem)
enquadrar = [o for o in objetos if o.dimensions.z > 0.02 or len(objetos) == 1] or objetos
cantos = [o.matrix_world @ Vector(c) for o in enquadrar for c in o.bound_box]
minimo = Vector((min(c.x for c in cantos), min(c.y for c in cantos), min(c.z for c in cantos)))
maximo = Vector((max(c.x for c in cantos), max(c.y for c in cantos), max(c.z for c in cantos)))
centro = (minimo + maximo) / 2
tamanho = max((maximo - minimo).length, 0.1)

# cenário real: o script escolhe com ambiente(...); senão é deduzido do que foi modelado
import re as _re
nomes_cena = " ".join(o.name for o in cena.objects).lower()
if AMBIENTE["nome"] is None:
    if _re.search(r"carro|casa|predio|poste|arvore|garagem|pessoa", nomes_cena):
        AMBIENTE["nome"] = "estacionamento"
    elif _re.search(r"mesa|cadeira|sofa|cama|estante|luminaria|real_", nomes_cena):
        AMBIENTE["nome"] = "interior"
    else:
        AMBIENTE["nome"] = "estudio"
cenario = None
if polyhaven:
    try:
        id_hdri, id_piso, metros_piso = polyhaven.AMBIENTES[AMBIENTE["nome"]]
        cenario = {"hdri": polyhaven.hdri(id_hdri), "piso": polyhaven.material_real(bpy, id_piso, "Piso_real", metros_piso) if id_piso else None}
        print("JARVIS_CENARIO:", AMBIENTE["nome"], id_hdri, id_piso)
    except Exception as erro:
        print("JARVIS_AVISO: cenário real indisponível, usando o simples:", erro)

# chão sem borda: planos finos do script viram um piso amplo; sem piso, cria um (dá sombra de contato e reflexo)
planos = [o for o in objetos if o.type == "MESH" and o.dimensions.z < 0.02 and min(o.dimensions.x, o.dimensions.y) > 2]
for pl in planos:
    fator = max(1.0, 300.0 / max(pl.dimensions.x, pl.dimensions.y))
    for v in pl.data.vertices:  # escala a malha (não o objeto) para a textura não esticar
        v.co.x *= fator
        v.co.y *= fator
    if cenario and cenario["piso"]:
        pl.data.materials.clear()
        pl.data.materials.append(cenario["piso"])
if not planos:
    bpy.ops.mesh.primitive_plane_add(size=600, location=(centro.x, centro.y, minimo.z - 0.001))
    piso = bpy.context.active_object
    piso.name = "Piso"
    if cenario and cenario["piso"]:
        piso.data.materials.append(cenario["piso"])
    elif cenario:  # estúdio/interior: o chão da própria foto recebe as sombras
        piso.is_shadow_catcher = True
    else:
        piso.data.materials.append(material("Piso_asfalto", (0.16, 0.16, 0.165), rugosidade=0.7, tipo="concreto"))

# câmera fotográfica de 3/4, baixa, com lente 50 mm e leve profundidade de campo (só se o script não criou uma)
if not any(o.type == "CAMERA" for o in cena.objects):
    camera = bpy.data.objects.new("Camera", bpy.data.cameras.new("Camera"))
    cena.collection.objects.link(camera)
    alvo = centro - Vector((0, 0, (maximo.z - minimo.z) * 0.08))
    # com cenário real a câmera fica na altura dos olhos, mostrando o fundo; sem ele, um pouco mais alta
    direcao = Vector((1.0, -1.3, 0.24 if cenario else 0.42)).normalized()
    distancia = tamanho * (1.38 if cenario else 1.55)
    camera.location = alvo + direcao * distancia
    camera.rotation_euler = (alvo - camera.location).to_track_quat("-Z", "Y").to_euler()
    camera.data.lens = 50
    camera.data.dof.use_dof = True
    camera.data.dof.focus_distance = distancia
    camera.data.dof.aperture_fstop = 5.6
    camera.data.clip_end = 2000
    cena.camera = camera
elif not cena.camera:
    cena.camera = next(o for o in cena.objects if o.type == "CAMERA")

if not cenario and not any(o.type == "LIGHT" for o in cena.objects):
    # sol de fim de tarde com sombras suaves (complementa a luz do HDRI)
    sol = bpy.data.objects.new("Sol", bpy.data.lights.new("Sol", "SUN"))
    sol.data.energy = 3.5
    sol.data.angle = math.radians(2.5)
    sol.data.color = (1.0, 0.93, 0.84)
    sol.rotation_euler = (math.radians(55), 0, math.radians(40))
    cena.collection.objects.link(sol)

# mundo: HDRI real (vem com o Blender) para luz e reflexos; a câmera vê um céu em gradiente limpo
if cena.world is None:
    cena.world = bpy.data.worlds.new("Mundo")
mundo = cena.world
try:
    mundo.use_nodes = True
except Exception:
    pass
arv = mundo.node_tree
nos = arv.nodes
fundo = nos.get("Background") or nos.new("ShaderNodeBackground")
saida_mundo = nos.get("World Output") or nos.new("ShaderNodeOutputWorld")
coord_mundo = nos.new("ShaderNodeTexCoord")
separa = nos.new("ShaderNodeSeparateXYZ")
rampa_ceu = nos.new("ShaderNodeValToRGB")
rampa_ceu.color_ramp.elements[0].color = (0.62, 0.68, 0.76, 1)
rampa_ceu.color_ramp.elements[1].position = 0.75
rampa_ceu.color_ramp.elements[1].color = (0.16, 0.32, 0.62, 1)
arv.links.new(coord_mundo.outputs["Generated"], separa.inputs["Vector"])
arv.links.new(separa.outputs["Z"], rampa_ceu.inputs["Fac"])
ceu = nos.new("ShaderNodeBackground")
ceu.inputs["Strength"].default_value = 0.9
arv.links.new(rampa_ceu.outputs["Color"], ceu.inputs["Color"])
saida_fundo = ceu
pasta_hdri = os.path.join(os.path.dirname(bpy.app.binary_path), f"{bpy.app.version[0]}.{bpy.app.version[1]}", "datafiles", "studiolights", "world")
arquivo_hdri = next((os.path.join(pasta_hdri, n) for n in ("courtyard.exr", "city.exr", "sunset.exr") if os.path.exists(os.path.join(pasta_hdri, n))), None)
if arquivo_hdri:
    hdri = nos.new("ShaderNodeTexEnvironment")
    hdri.image = bpy.data.images.load(arquivo_hdri)
    fundo.inputs["Strength"].default_value = 1.1
    arv.links.new(hdri.outputs["Color"], fundo.inputs["Color"])
    caminho_luz = nos.new("ShaderNodeLightPath")
    mistura = nos.new("ShaderNodeMixShader")
    arv.links.new(caminho_luz.outputs["Is Camera Ray"], mistura.inputs[0])
    arv.links.new(fundo.outputs["Background"], mistura.inputs[1])
    arv.links.new(ceu.outputs["Background"], mistura.inputs[2])
    saida_fundo = mistura
if cenario:  # foto 360° real: ilumina, reflete e aparece ao fundo
    foto = nos.new("ShaderNodeTexEnvironment")
    foto.image = bpy.data.images.load(cenario["hdri"])
    arv.links.new(foto.outputs["Color"], fundo.inputs["Color"])
    fundo.inputs["Strength"].default_value = 1.0
    saida_fundo = fundo
arv.links.new(saida_fundo.outputs[0], saida_mundo.inputs["Surface"])

# render: Cycles na GPU (fotorrealista, com redução de ruído); EEVEE e Workbench como reserva
cena.render.resolution_x, cena.render.resolution_y = 1280, 960
cena.render.film_transparent = False
cena.render.filepath = base_saida + ".png"
try:
    cena.view_settings.view_transform = "AgX"
    cena.view_settings.look = "AgX - Medium High Contrast"
except Exception:
    pass


def usar_cycles():
    cena.render.engine = "CYCLES"
    prefs = bpy.context.preferences.addons["cycles"].preferences
    gpu = False
    for tipo_gpu in ("OPTIX", "CUDA", "HIP", "ONEAPI", "METAL"):
        try:
            prefs.compute_device_type = tipo_gpu
            prefs.get_devices()
        except Exception:
            continue
        dedicadas = [d for d in prefs.devices if d.type == tipo_gpu and "(TM) Graphics" not in d.name]
        if dedicadas:
            for d in prefs.devices:
                d.use = d in dedicadas
            gpu = True
            break
    c = cena.cycles
    c.device = "GPU" if gpu else "CPU"
    c.samples = 64 if gpu else 32
    c.adaptive_threshold = 0.03
    c.use_denoising = True
    c.time_limit = 15 if gpu else 30
    c.max_bounces, c.glossy_bounces, c.diffuse_bounces, c.transmission_bounces = 8, 4, 3, 8
    c.caustics_reflective = c.caustics_refractive = False
    c.blur_glossy = 1.0
    print("JARVIS_RENDER: Cycles", c.device)


def usar_eevee():
    for motor in ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"):
        try:
            cena.render.engine = motor
            break
        except Exception:
            continue
    ee = cena.eevee
    for atributo, valor in (("taa_render_samples", 64), ("use_shadows", True), ("use_gtao", True), ("use_raytracing", True), ("shadow_ray_count", 2)):
        try:
            setattr(ee, atributo, valor)
        except Exception:
            pass


renderizado = False
for preparar in (usar_cycles, usar_eevee):
    try:
        preparar()
        bpy.ops.render.render(write_still=True)
        renderizado = True
        break
    except Exception as erro:
        print("JARVIS_AVISO: render falhou com", preparar.__name__, erro)
if not renderizado:  # último recurso: prévia simples
    cena.render.engine = "BLENDER_WORKBENCH"
    cena.display.shading.light = "STUDIO"
    cena.display.shading.color_type = "MATERIAL"
    cena.display.shading.show_shadows = True
    bpy.ops.render.render(write_still=True)

os.makedirs(os.path.dirname(base_saida), exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=base_saida + ".blend")
try:
    bpy.ops.export_scene.gltf(filepath=base_saida + ".glb", export_format="GLB")
except Exception as erro:  # exportação é um bônus; o .blend já está salvo
    print("JARVIS_AVISO: glb não exportado:", erro)
print(f"JARVIS_OK objetos={len(objetos)} tamanho={tamanho:.2f}")
