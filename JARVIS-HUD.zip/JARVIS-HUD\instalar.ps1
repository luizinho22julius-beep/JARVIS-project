﻿# J.A.R.V.I.S. — instalador para Windows 10/11
# Instala o que faltar (Node.js e Ollama), baixa o modelo de IA certo para a sua placa de vídeo,
# pergunta seu nome e cidade, guarda as chaves opcionais e cria o atalho na área de trabalho.
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
$Host.UI.RawUI.WindowTitle = "Instalando o J.A.R.V.I.S."

function Titulo($t) { Write-Host ""; Write-Host "  == $t ==" -ForegroundColor Cyan }
function Ok($t) { Write-Host "  [ok] $t" -ForegroundColor Green }
function Aviso($t) { Write-Host "  [!] $t" -ForegroundColor Yellow }
function Tem($cmd) { [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function AtualizarPath {
  $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
  foreach ($p in @("$env:ProgramFiles\nodejs", "$env:LOCALAPPDATA\Programs\Ollama")) { if ((Test-Path $p) -and ($env:Path -notlike "*$p*")) { $env:Path += ";$p" } }
}
function InstalarWinget($id, $nome) {
  if (-not (Tem "winget")) { throw "O winget não está disponível. Instale $nome manualmente e rode este instalador de novo." }
  Write-Host "  Instalando $nome (pode pedir permissão do Windows)..."
  winget install --id $id -e --silent --accept-package-agreements --accept-source-agreements | Out-Host
  AtualizarPath
}

Write-Host ""
Write-Host "     J . A . R . V . I . S ." -ForegroundColor Cyan
Write-Host "     Just A Rather Very Intelligent System — instalador" -ForegroundColor DarkCyan

# ---------- 1. Node.js ----------
Titulo "1/6  Node.js"
AtualizarPath
$precisaNode = $true
if (Tem "node") {
  $versao = [int]((node -v).TrimStart("v").Split(".")[0])
  if ($versao -ge 20) { $precisaNode = $false; Ok "Node.js $(node -v) já instalado" }
}
if ($precisaNode) { InstalarWinget "OpenJS.NodeJS.LTS" "o Node.js"; if (-not (Tem "node")) { throw "O Node.js não ficou disponível. Feche esta janela e rode o instalar.bat de novo." }; Ok "Node.js instalado" }

# ---------- 2. Componentes do JARVIS ----------
Titulo "2/6  Componentes do JARVIS"
npm install --omit=dev --no-audit --no-fund | Out-Host
Ok "componentes instalados"

# ---------- 3. Ollama (o cérebro, grátis e local) ----------
Titulo "3/6  Ollama (IA local e gratuita)"
if (-not (Tem "ollama")) { InstalarWinget "Ollama.Ollama" "o Ollama" }
if (-not (Tem "ollama")) { throw "O Ollama não ficou disponível. Instale em https://ollama.com/download e rode este instalador de novo." }
Ok "Ollama pronto"
try { Invoke-RestMethod "http://127.0.0.1:11434/api/version" -TimeoutSec 2 | Out-Null } catch { Start-Process "ollama" "serve" -WindowStyle Hidden; Start-Sleep 4 }

# ---------- 4. Modelo de IA de acordo com a placa de vídeo ----------
Titulo "4/6  Modelo de IA"
$vram = 0
try {
  Get-ChildItem "HKLM:\SYSTEM\ControlSet001\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}" -ErrorAction SilentlyContinue | ForEach-Object {
    $v = (Get-ItemProperty $_.PSPath -Name "HardwareInformation.qwMemorySize" -ErrorAction SilentlyContinue)."HardwareInformation.qwMemorySize"
    if ($v -and [int64]$v -gt $vram) { $vram = [int64]$v }
  }
} catch {}
$vramGB = [math]::Round($vram / 1GB, 1)
$ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
if ($vramGB -ge 10) { $modelo = "qwen3.5:9b"; $motivo = "placa com $vramGB GB: modelo mais inteligente" }
elseif ($vramGB -ge 4 -or $ramGB -ge 16) { $modelo = "qwen3.5:4b"; $motivo = "placa com $vramGB GB / RAM $ramGB GB: modelo equilibrado" }
else { $modelo = "qwen3.5:2b"; $motivo = "PC mais modesto: modelo leve e rápido" }
Write-Host "  Escolhido: $modelo ($motivo)"
$rapido = $(if ($modelo -eq "qwen3.5:9b") { "qwen3.5:4b" } else { $modelo })
foreach ($m in @($modelo, $rapido) | Select-Object -Unique) {
  Write-Host "  Baixando $m (só na primeira vez; pode levar alguns minutos)..."
  ollama pull $m | Out-Host
}
Ok "modelo pronto"

# ---------- 5. Personalização e chaves opcionais ----------
Titulo "5/6  Personalização"
$cfgArquivo = Join-Path $PSScriptRoot "config.json"
$cfg = @{}
if (Test-Path $cfgArquivo) { (Get-Content $cfgArquivo -Raw -Encoding UTF8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $cfg[$_.Name] = $_.Value } }
$nome = Read-Host "  Como o JARVIS deve te chamar pelo nome? (Enter para pular)"
$trat = Read-Host "  Tratamento: senhor ou senhora? (Enter = senhor)"
$cidade = Read-Host "  Sua cidade, para o clima (ex.: São Paulo)"
$cfg["provedorIA"] = "ollama"; $cfg["modeloOllama"] = $modelo; $cfg["modeloRapido"] = $rapido
if ($nome) { $cfg["nomeUsuario"] = $nome }
$cfg["tratamento"] = $(if ($trat -match "senhora") { "senhora" } else { "senhor" })
if ($cidade) { $cfg["cidade"] = $cidade }
if (-not $cfg.ContainsKey("vozFishId")) { $cfg["vozFishId"] = "82d13948027e4be69892dd3d0104e681" }
[IO.File]::WriteAllText($cfgArquivo, ($cfg | ConvertTo-Json), (New-Object System.Text.UTF8Encoding $false))
Ok "configuração salva"

function GuardarChave($nomeVar, $explicacao) {
  if ([Environment]::GetEnvironmentVariable($nomeVar, "User")) { Ok "$nomeVar já configurada"; return }
  Write-Host ""
  Write-Host "  $explicacao"
  $seguro = Read-Host "  Cole a chave (ela não aparece) ou Enter para pular" -AsSecureString
  $texto = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($seguro))
  if ($texto) { [Environment]::SetEnvironmentVariable($nomeVar, $texto.Trim(), "User"); Ok "$nomeVar guardada só neste PC" } else { Aviso "pulado (dá para configurar depois rodando o instalar.bat de novo)" }
}
GuardarChave "FISH_API_KEY" "VOZ DO JARVIS (opcional): crie uma chave grátis em https://fish.audio/app/api-keys . Sem ela, ele fala com a voz do Windows."
GuardarChave "SKETCHFAB_TOKEN" "MODELOS 3D REAIS no Blender (opcional): crie uma conta grátis em sketchfab.com e copie o token em Settings > Password & API."

# ---------- 6. Atalho ----------
Titulo "6/6  Atalho na área de trabalho"
$atalho = Join-Path ([Environment]::GetFolderPath("Desktop")) "JARVIS.lnk"
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut($atalho)
$lnk.TargetPath = Join-Path $PSScriptRoot "abrir-hud.bat"
$lnk.WorkingDirectory = $PSScriptRoot
$lnk.IconLocation = (Join-Path $PSScriptRoot "jarvis.ico")
$lnk.WindowStyle = 7
$lnk.Description = "J.A.R.V.I.S."
$lnk.Save()
Ok "atalho JARVIS criado na área de trabalho"

Write-Host ""
Write-Host "  Tudo pronto! Use o atalho JARVIS na área de trabalho." -ForegroundColor Green
Write-Host "  Dica: o reconhecimento de voz funciona no Edge ou no Chrome. Diga 'Jarvis' para chamá-lo."
Write-Host "  Opcionais: Blender (modelos 3D) e Roblox Studio (MCP) são detectados sozinhos se estiverem instalados."
Write-Host ""
$abrir = Read-Host "  Abrir o JARVIS agora? (S/n)"
if ($abrir -notmatch "^[nN]") { Start-Process (Join-Path $PSScriptRoot "abrir-hud.bat") -WindowStyle Minimized }
