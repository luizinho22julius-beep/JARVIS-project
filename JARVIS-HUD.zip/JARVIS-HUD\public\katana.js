/* JARVIS — respostas em tipografia cinética (inspirado em edições "kinetic typography"):
   palavras gigantes que batem na tela no ritmo exato da voz, fundo alternando vermelho / preto / gelo,
   palavra-chave em vermelho, ponto final como bolinha vermelha, raios de luz, partículas e a pergunta
   aparecendo digitada numa caixa de prompt. Funciona por cima da legenda sincronizada que já existe;
   fica fora do caminho quando o mural de imagens está aberto.

   Fluidez: tudo anima só transform e opacity (a GPU compõe sem redesenhar); o "motion blur" vem de
   cópias fantasmas já borradas que correm atrás do texto; curvas de mola (expo-out); a batida nova
   entra enquanto a anterior ainda sai; e uma câmera virtual flutua o tempo todo. */
(() => {
  const PEQUENAS = new Set(("o a os as um uma uns umas de do da dos das e em no na nos nas que se por para pra com ao aos à às é ou mas " +
    "como sem sob sobre entre até pelo pela pelos pelas seu sua seus suas meu minha nosso nossa lhe me te já não foi era são ser está isso este esta esse essa " +
    "the of and to in is it").split(" "));
  const FUNDOS = ["preto", "vermelho", "preto", "gelo"];
  // curvas: entrada de mola (rápida e assenta macio), saída que acelera, deriva linear
  const MOLA = "cubic-bezier(.16, 1, .3, 1)";
  const MOLA_FORTE = "cubic-bezier(.22, 1.25, .36, 1)"; // passa um tiquinho e volta
  const SAIDA = "cubic-bezier(.55, 0, .9, .35)";
  let raiz = null, canvas = null, c2d = null, camera = null, atual = null, timerFim = null, nFrase = 0, fundo = "preto", raios = 0, chute = 0;
  let largura = 0, altura = 0;

  const limpar = (p) => p.replace(/[“”"()«»]/g, "");
  const semPont = (p) => limpar(p).replace(/[.,;:…]+$/g, "");
  const fimDeFrase = (p) => /[.!?…]["”)]?$/.test(p);
  const muralAberto = () => { const p = document.getElementById("palco"); return p && !p.hidden; };
  const animar = (el, quadros, opcoes) => el.animate(quadros, { fill: "both", ...opcoes });

  function criarRaiz() {
    if (raiz) return raiz;
    raiz = document.createElement("div");
    raiz.id = "katana";
    raiz.dataset.fundo = "preto";
    // três fundos empilhados: a troca de cor é um crossfade suave, não um corte seco
    for (const cor of ["preto", "vermelho", "gelo"]) {
      const f = document.createElement("div"); f.className = "k-fundo"; f.dataset.cor = cor;
      if (cor === "preto") f.classList.add("visivel");
      raiz.append(f);
    }
    canvas = document.createElement("canvas");
    camera = document.createElement("div"); camera.className = "k-camera";
    raiz.append(canvas, camera);
    document.body.append(raiz);
    c2d = canvas.getContext("2d");
    medirTela();
    addEventListener("resize", medirTela);
    animarParticulas();
    // câmera virtual: flutua devagar o tempo todo (nunca fica parado, como no vídeo)
    animar(camera, [
      { transform: "translate3d(0,0,0) rotate(0deg) scale(1)" },
      { transform: "translate3d(-0.6vw,0.4vh,0) rotate(-0.4deg) scale(1.015)" },
      { transform: "translate3d(0.5vw,-0.3vh,0) rotate(0.3deg) scale(1.01)" },
      { transform: "translate3d(0,0,0) rotate(0deg) scale(1)" },
    ], { duration: 9000, iterations: Infinity, easing: "ease-in-out" });
    return raiz;
  }

  function medirTela() {
    if (!canvas) return;
    largura = canvas.width = Math.max(1, canvas.clientWidth * devicePixelRatio);
    altura = canvas.height = Math.max(1, canvas.clientHeight * devicePixelRatio);
  }

  /* ---------- partículas e raios de velocidade (canvas só é limpo, nunca recriado) ---------- */
  const pontos = Array.from({ length: 60 }, () => ({ x: Math.random(), y: Math.random(), z: Math.random(), a: Math.random() * 6 }));
  function animarParticulas() {
    let antes = performance.now();
    const quadro = (agora) => {
      if (!raiz) return;
      requestAnimationFrame(quadro);
      if (!raiz.classList.contains("ativo")) return;
      if (!largura || canvas.clientWidth * devicePixelRatio !== largura) medirTela();
      const dt = Math.min(50, agora - antes) / 16.7; antes = agora;
      const w = largura, h = altura;
      c2d.clearRect(0, 0, w, h);
      const cor = fundo === "preto" ? "90,200,255" : fundo === "vermelho" ? "200,235,255" : "21,89,214";
      chute *= Math.pow(0.88, dt);
      if (raios > 0.01) {
        c2d.lineCap = "round";
        c2d.lineWidth = 1.4 * devicePixelRatio;
        const m = Math.max(w, h);
        for (let k = 0; k < 48; k++) {
          const ang = (k / 48) * Math.PI * 2 + k * 1.7;
          const r0 = (0.16 + (k % 7) * 0.045) * m * (1.25 - raios);
          const r1 = r0 + 0.06 * m * raios;
          c2d.strokeStyle = `rgba(${cor},${0.32 * raios})`;
          c2d.beginPath(); c2d.moveTo(w / 2 + Math.cos(ang) * r0, h / 2 + Math.sin(ang) * r0); c2d.lineTo(w / 2 + Math.cos(ang) * r1, h / 2 + Math.sin(ang) * r1); c2d.stroke();
        }
        raios *= Math.pow(0.92, dt);
      }
      // partículas sobem; a cada batida levam um "empurrão" para fora do centro
      for (const p of pontos) {
        const v = (0.0004 + p.z * 0.0009) * dt;
        p.y -= v; p.a += 0.02 * dt;
        p.x += (p.x - 0.5) * chute * 0.02 * dt; p.y += (p.y - 0.5) * chute * 0.02 * dt;
        if (p.y < -0.03 || p.x < -0.03 || p.x > 1.03 || p.y > 1.03) { p.y = 1.02; p.x = Math.random(); }
        const r = (0.6 + p.z * 2.2) * devicePixelRatio * (fundo === "preto" ? 1.3 : 1);
        c2d.fillStyle = `rgba(${cor},${0.12 + 0.16 * (0.5 + 0.5 * Math.sin(p.a))})`;
        c2d.beginPath(); c2d.arc(p.x * w, p.y * h, r, 0, Math.PI * 2); c2d.fill();
      }
    };
    requestAnimationFrame(quadro);
  }

  /* ---------- divide o trecho em "batidas" (1 a 3 palavras que entram juntas) ---------- */
  function batidas(palavras) {
    const lista = [];
    let atualB = null;
    palavras.forEach((p, i) => {
      if (!atualB) atualB = { inicio: i, palavras: [], fortes: 0 };
      atualB.palavras.push(p);
      const forte = !PEQUENAS.has(semPont(p).toLowerCase());
      if (forte) atualB.fortes++;
      const texto = atualB.palavras.map(semPont).join(" ");
      const fecha = fimDeFrase(p) || /[,;:]$/.test(p) || (forte && (atualB.fortes >= 2 || semPont(p).length >= 6 || texto.length >= 14));
      if (fecha || i === palavras.length - 1) { atualB.depois = palavras.slice(i + 1, i + 3); lista.push(atualB); atualB = null; }
    });
    return lista;
  }

  /* ---------- uma linha = texto + fantasma borrado (motion blur barato) ---------- */
  function linha(texto, classes) {
    const l = document.createElement("span"); l.className = "k-linha " + classes;
    const t = document.createElement("span"); t.className = "k-txt"; t.textContent = texto;
    const g = document.createElement("span"); g.className = "k-fantasma"; g.textContent = texto; g.setAttribute("aria-hidden", "true");
    l.append(t, g);
    return l;
  }

  // entradas: cada uma anima o texto e o fantasma (que vem "rastejando" atrás e some)
  const ENTRADAS = {
    batida(l, atraso) { // chega de perto da câmera: grande e borrado -> nítido
      animar(l.querySelector(".k-txt"), [{ transform: "scale(1.55)", opacity: 0 }, { transform: "scale(1)", opacity: 1, offset: .62 }, { transform: "scale(1)", opacity: 1 }], { duration: 520, delay: atraso, easing: MOLA });
      animar(l.querySelector(".k-fantasma"), [{ transform: "scale(2.1)", opacity: .75 }, { transform: "scale(1.08)", opacity: 0 }], { duration: 430, delay: atraso, easing: MOLA });
    },
    lado(l, atraso) { // desliza da direita com rastro horizontal
      animar(l.querySelector(".k-txt"), [{ transform: "translate3d(38vw,0,0) skewX(-14deg)", opacity: 0 }, { transform: "translate3d(0,0,0) skewX(0)", opacity: 1 }], { duration: 560, delay: atraso, easing: MOLA_FORTE });
      animar(l.querySelector(".k-fantasma"), [{ transform: "translate3d(46vw,0,0) scaleX(1.9)", opacity: .7 }, { transform: "translate3d(2vw,0,0) scaleX(1.15)", opacity: 0 }], { duration: 470, delay: atraso, easing: MOLA });
    },
    baixo(l, atraso) { // sobe de trás de uma "máscara"
      l.classList.add("k-mascara");
      animar(l.querySelector(".k-txt"), [{ transform: "translate3d(0,105%,0)" }, { transform: "translate3d(0,0,0)" }], { duration: 560, delay: atraso, easing: MOLA });
      animar(l.querySelector(".k-fantasma"), [{ transform: "translate3d(0,60%,0) scaleY(1.6)", opacity: .6 }, { transform: "translate3d(0,0,0) scaleY(1)", opacity: 0 }], { duration: 420, delay: atraso, easing: MOLA });
    },
    letras(l, atraso) { // letra por letra, em cascata
      const t = l.querySelector(".k-txt");
      const texto = t.textContent; t.textContent = "";
      [...texto].forEach((ch, k) => {
        const s = document.createElement("span"); s.className = "k-letra"; s.textContent = ch === " " ? " " : ch; t.append(s);
        animar(s, [{ transform: "translate3d(.9em,0,0) scale(1.25)", opacity: 0 }, { transform: "translate3d(0,0,0) scale(1)", opacity: 1 }], { duration: 480, delay: atraso + k * 32, easing: MOLA });
      });
      animar(l.querySelector(".k-fantasma"), [{ transform: "translate3d(14vw,0,0) scaleX(1.6)", opacity: .55 }, { transform: "translate3d(0,0,0) scaleX(1.1)", opacity: 0 }], { duration: 520, delay: atraso, easing: MOLA });
    },
  };

  /* ======================= gráficos e imagens ======================= */
  const norm = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
  let visuais = new Map(), grafico = null, timerGrafico = null, anosDoTrecho = [], batidasSemGrafico = 0;

  // pede as fotos assim que cada frase chega (antes de ela ser falada): quando a palavra soar, a foto já está pronta
  const novaFalaOriginal = window.novaFala;
  if (typeof novaFalaOriginal === "function") {
    window.novaFala = function () {
      const locutor = novaFalaOriginal.apply(this, arguments);
      visuais = new Map();
      let acumulado = "";
      const pedir = pedirVisuais;
      const adicionar = locutor.adicionar;
      locutor.adicionar = function (frase) {
        adicionar.call(locutor, frase);
        acumulado += " " + (frase || "");
        if (acumulado.length > 120) { pedir(acumulado); acumulado = ""; }
      };
      const terminar = locutor.terminar;
      locutor.terminar = function () { pedir(acumulado); acumulado = ""; terminar.call(locutor); };
      return locutor;
    };
  }
  function pedirVisuais(texto) {
    {
        if (!texto.trim() || muralAberto()) return;
        fetch("/api/visuais", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ texto }) })
          .then((r) => r.json()).then((d) => {
            for (const v of d.itens ?? []) {
              const chave = norm(v.palavra);
              if (!chave || visuais.has(chave)) continue;
              const img = new Image(); img.src = v.imagem; // pré-carrega
              visuais.set(chave, { ...v, chave, primeira: chave.split(" ")[0], usada: false, img });
            }
          }).catch(() => {});
    }
  }

  function contar(el, de, ate, ms, formatar) {
    const t0 = performance.now();
    const passo = (t) => {
      const f = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - f, 4);
      el.textContent = formatar(de + (ate - de) * e);
      if (f < 1 && el.isConnected) requestAnimationFrame(passo);
    };
    requestAnimationFrame(passo);
  }
  const formatoBR = (n) => Math.round(n).toLocaleString("pt-BR");

  function tirarGrafico() {
    if (!grafico) return;
    const velho = grafico; grafico = null;
    animar(velho, [{ transform: "translate3d(0,-50%,0)", opacity: 1 }, { transform: "translate3d(8vw,-50%,0) scale(.96)", opacity: 0 }], { duration: 260, easing: SAIDA });
    setTimeout(() => velho.remove(), 300);
    raiz.classList.remove("com-grafico");
  }

  function colocarGrafico(conteudo, duracao = 3600) {
    const el = document.createElement("div"); el.append(conteudo); // moldura própria: o estilo do gráfico não mexe na posição
    if (grafico) { const velho = grafico; grafico = null; animar(velho, [{ opacity: 1 }, { opacity: 0, transform: "translate3d(-4vw,-50%,0) scale(.94)" }], { duration: 220, easing: SAIDA }); setTimeout(() => velho.remove(), 260); }
    el.classList.add("k-grafico");
    camera.append(el);
    grafico = el;
    raiz.classList.add("com-grafico");
    animar(el, [{ transform: "translate3d(14vw,-50%,0) rotate(3deg) scale(.92)", opacity: 0 }, { transform: "translate3d(0,-50%,0) rotate(0) scale(1)", opacity: 1 }], { duration: 700, easing: MOLA_FORTE });
    clearTimeout(timerGrafico);
    timerGrafico = setTimeout(tirarGrafico, duracao);
    batidasSemGrafico = 0;
  }

  function cartaoFoto(v) {
    const el = document.createElement("div"); el.className = "k-cartao";
    el.innerHTML = `<div class="k-barra"><i></i><i></i><i></i><span></span></div><div class="k-foto"><img alt=""><div class="k-etiqueta"></div><div class="k-credito">● REC</div></div>`;
    el.querySelector(".k-barra span").textContent = v.busca;
    el.querySelector(".k-etiqueta").textContent = v.palavra;
    const img = el.querySelector("img"); img.src = v.imagem;
    colocarGrafico(el, 4200);
    animar(img, [{ transform: "scale(1.18) translate3d(2%,1%,0)" }, { transform: "scale(1.02) translate3d(0,0,0)" }], { duration: 5000, easing: "cubic-bezier(.2,.6,.3,1)" });
    animar(el.querySelector(".k-etiqueta"), [{ transform: "translate3d(-120%,0,0)", opacity: 0 }, { transform: "translate3d(0,0,0)", opacity: 1 }], { duration: 520, delay: 280, easing: MOLA_FORTE });
  }

  function linhaDoTempo(ano) {
    const anos = [...new Set([...anosDoTrecho, ano])].sort((a, b) => a - b);
    let ini = anos[0], fim = anos[anos.length - 1];
    if (fim - ini < 40) { ini = Math.floor((ano - 50) / 10) * 10; fim = ini + 100; }
    const pos = (a) => `${((a - ini) / (fim - ini)) * 100}%`;
    const el = document.createElement("div"); el.className = "k-tempo";
    el.innerHTML = `<div class="k-trilho"></div><div class="k-ponto-tempo"></div><div class="k-ano"></div><div class="k-ponta" style="left:0">${ini}</div><div class="k-ponta" style="right:0">${fim}</div>`;
    for (let k = 1; k < 10; k++) { const m = document.createElement("div"); m.className = "k-marca"; m.style.left = `${k * 10}%`; el.append(m); }
    for (const a of anos) if (a !== ano) { const m = document.createElement("div"); m.className = "k-marca"; m.style.cssText = `left:${pos(a)};height:26px;opacity:.8;background:var(--k-vermelho)`; el.append(m); }
    colocarGrafico(el);
    animar(el.querySelector(".k-trilho"), [{ transform: "scaleX(0)" }, { transform: "scaleX(1)" }], { duration: 700, easing: MOLA });
    const anoEl = el.querySelector(".k-ano"), ponto = el.querySelector(".k-ponto-tempo");
    const de = Math.max(ini, ano - 60);
    animar(ponto, [{ left: pos(de) }, { left: pos(ano) }], { duration: 1100, easing: MOLA });
    animar(anoEl, [{ left: pos(de), opacity: 0 }, { left: pos(ano), opacity: 1 }], { duration: 1100, easing: MOLA });
    contar(anoEl, de, ano, 1100, (n) => String(Math.round(n)));
  }

  function anel(pct) {
    const el = document.createElement("div"); el.className = "k-anel";
    const r = 44, volta = 2 * Math.PI * r;
    el.innerHTML = `<svg viewBox="0 0 100 100"><circle class="k-fundo-anel" cx="50" cy="50" r="${r}" stroke-width="7"/><circle class="k-arco" cx="50" cy="50" r="${r}" stroke-width="7" stroke-dasharray="${volta}" stroke-dashoffset="${volta}"/></svg><div class="k-valor"></div>`;
    colocarGrafico(el);
    animar(el.querySelector(".k-arco"), [{ strokeDashoffset: volta }, { strokeDashoffset: volta * (1 - Math.min(100, pct) / 100) }], { duration: 1300, easing: MOLA });
    contar(el.querySelector(".k-valor"), 0, pct, 1300, (n) => `${Math.round(n)}%`);
  }

  function contador(valor, rotulo) {
    const el = document.createElement("div"); el.className = "k-contador";
    el.innerHTML = `<div class="k-numero"></div><div class="k-rotulo-num"></div><div class="k-barra-num"><b></b></div>`;
    el.querySelector(".k-rotulo-num").textContent = rotulo || "";
    colocarGrafico(el);
    contar(el.querySelector(".k-numero"), 0, valor, 1200, formatoBR);
    animar(el.querySelector(".k-barra-num b"), [{ transform: "scaleX(0)" }, { transform: `scaleX(${0.35 + 0.65 * Math.min(1, Math.log10(Math.max(10, valor)) / 9)})` }], { duration: 1200, easing: MOLA });
  }

  function nos(a, b, legenda) {
    const el = document.createElement("div"); el.className = "k-nos";
    el.innerHTML = `<svg viewBox="0 0 400 200" preserveAspectRatio="none"><path d="M 110 52 C 220 52, 180 148, 290 148"/><circle r="4"><animateMotion dur="1.4s" repeatCount="indefinite" path="M 110 52 C 220 52, 180 148, 290 148"/></circle></svg>
      <div class="k-no a"><div class="k-icone"></div><small>conceito</small><b></b></div><div class="k-no b destaque"><div class="k-icone"></div><small>resultado</small><b></b></div><div class="k-chip"></div>`;
    el.querySelector(".k-no.a .k-icone").textContent = a[0]; el.querySelector(".k-no.a b").textContent = a;
    el.querySelector(".k-no.b .k-icone").textContent = b[0]; el.querySelector(".k-no.b b").textContent = b;
    el.querySelector(".k-chip").textContent = legenda;
    colocarGrafico(el, 3200);
    const caminho = el.querySelector("path"); const comp = 260;
    caminho.style.strokeDasharray = comp;
    animar(caminho, [{ strokeDashoffset: comp }, { strokeDashoffset: 0 }], { duration: 700, delay: 250, easing: MOLA });
    animar(el.querySelector(".k-no.a"), [{ transform: "translate3d(-3vw,0,0) scale(.9)", opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 520, easing: MOLA_FORTE });
    animar(el.querySelector(".k-no.b"), [{ transform: "translate3d(3vw,0,0) scale(.9)", opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 520, delay: 450, easing: MOLA_FORTE });
    animar(el.querySelector(".k-chip"), [{ opacity: 0, transform: "translate(-50%,-30%)" }, { opacity: 1, transform: "translate(-50%,-50%)" }], { duration: 400, delay: 650, easing: MOLA });
  }

  /* ======================= desenhos de motion graphics para números ======================= */
  const NS = "http://www.w3.org/2000/svg";
  // desenha um traço SVG como se fosse à mão (pathLength=1 + dashoffset)
  function desenhar(caminho, atraso = 0, ms = 900) {
    caminho.setAttribute("pathLength", "1");
    caminho.style.strokeDasharray = "1"; caminho.style.strokeDashoffset = "1";
    animar(caminho, [{ strokeDashoffset: 1 }, { strokeDashoffset: 0 }], { duration: ms, delay: atraso, easing: MOLA });
  }
  function base(classe, numeroTexto, sufixo, rotulo) {
    const el = document.createElement("div"); el.className = "k-desenho " + classe;
    el.innerHTML = `<div class="k-numero"><span></span><small></small></div><div class="k-rotulo-num"></div><div class="k-arte"></div><div class="k-legenda"></div>`;
    el.querySelector("small").textContent = sufixo || "";
    el.querySelector(".k-rotulo-num").textContent = rotulo || "";
    return el;
  }
  const pop = (el, atraso) => animar(el, [{ transform: "translate3d(0,40%,0) scale(.3)", opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 480, delay: atraso, easing: MOLA_FORTE });

  const ICONE_PESSOA = `<svg viewBox="0 0 20 30"><circle class="k-cheio" cx="10" cy="6" r="4.6"/><path class="k-cheio" d="M3 29 V18 Q3 12 10 12 Q17 12 17 18 V29 Z"/></svg>`;
  function pessoas(n, mostrado, sufixo, rotulo) {
    const el = base("k-pessoas", mostrado, sufixo, rotulo);
    const grade = document.createElement("div"); grade.className = "k-gente";
    const total = 40;
    grade.innerHTML = ICONE_PESSOA.repeat(total);
    el.querySelector(".k-arte").append(grade);
    const porIcone = n / total;
    el.querySelector(".k-legenda").textContent = `cada figura ≈ ${porIcone >= 1e6 ? formatoBR(porIcone / 1e6) + " milhões" : porIcone >= 1e3 ? formatoBR(porIcone / 1e3) + " mil" : formatoBR(Math.max(1, porIcone))}`;
    colocarGrafico(el, 4200);
    contar(el.querySelector(".k-numero span"), 0, mostrado, 1300, formatoBR);
    [...grade.children].forEach((ic, k) => pop(ic, 150 + (k % 10) * 28 + Math.floor(k / 10) * 90));
  }

  function dinheiro(n, mostrado, sufixo, rotulo, moeda) {
    const el = base("k-dinheiro", mostrado, sufixo, rotulo);
    el.querySelector(".k-numero span").before(Object.assign(document.createElement("small"), { textContent: moeda + " ", style: "margin:0 .12em 0 0" }));
    const arte = el.querySelector(".k-arte");
    arte.innerHTML = `<div style="position:relative"><div class="k-grana"></div><svg viewBox="0 0 400 140" preserveAspectRatio="none" style="position:absolute;inset:0;height:100%"><path class="k-traco acento" d="M10 130 L90 110 L170 118 L250 70 L320 52 L390 10"/><path class="k-traco acento" d="M372 8 L390 10 L386 28"/></svg></div>`;
    const grana = arte.querySelector(".k-grana");
    const alturas = [3, 5, 4, 7, 9, 12];
    alturas.forEach((h, c) => {
      const col = document.createElement("div"); col.className = "k-coluna";
      for (let k = 0; k < h; k++) { const nota = document.createElement("div"); nota.className = "k-nota"; col.append(nota); pop(nota, 120 + c * 90 + k * 45); }
      grana.append(col);
    });
    colocarGrafico(el, 4200);
    contar(el.querySelector(".k-numero span"), 0, mostrado, 1300, formatoBR);
    arte.querySelectorAll("path").forEach((p, k) => desenhar(p, 500 + k * 700, 900));
  }

  function velocimetro(valor, rotulo) {
    const max = valor <= 120 ? 160 : valor <= 300 ? 400 : Math.pow(10, Math.ceil(Math.log10(valor * 1.2)));
    const el = base("k-velocidade", valor, "km/h", rotulo);
    const ang = (v) => Math.PI * (1 - Math.min(1, v / max));
    const ponto = (v, r) => `${200 + Math.cos(ang(v)) * r} ${200 - Math.sin(ang(v)) * r}`;
    let marcas = "";
    for (let k = 0; k <= 20; k++) { const v = (max * k) / 20, r1 = k % 5 ? 160 : 150; marcas += `<path class="k-traco ${k % 5 ? "fraco" : ""}" d="M${ponto(v, r1)} L${ponto(v, 172)}"/>`; }
    el.querySelector(".k-arte").innerHTML = `<svg viewBox="0 0 400 215"><path class="k-traco fraco" d="M28 200 A172 172 0 0 1 372 200"/>${marcas}
      <path class="k-traco acento k-arco-v" d="M${ponto(0, 186)} A186 186 0 0 1 ${ponto(valor, 186)}"/><g class="k-agulha"><path class="k-traco acento" d="M200 200 L200 52"/><circle class="k-cheio" cx="200" cy="200" r="10"/></g></svg>`;
    el.querySelector(".k-legenda").textContent = `escala até ${formatoBR(max)} km/h`;
    colocarGrafico(el, 4000);
    el.querySelectorAll(".k-traco:not(.k-arco-v)").forEach((p, k) => desenhar(p, k * 12, 500));
    desenhar(el.querySelector(".k-arco-v"), 300, 1300);
    const agulha = el.querySelector(".k-agulha"); agulha.style.transformOrigin = "200px 200px";
    animar(agulha, [{ transform: "rotate(-90deg)" }, { transform: `rotate(${-90 + 180 * Math.min(1, valor / max) + 4}deg)`, offset: .8 }, { transform: `rotate(${-90 + 180 * Math.min(1, valor / max)}deg)` }], { duration: 1400, delay: 300, easing: MOLA });
    contar(el.querySelector(".k-numero span"), 0, valor, 1500, formatoBR);
  }

  function distancia(n, mostrado, sufixo, rotulo) {
    const el = base("k-distancia", mostrado, sufixo, rotulo);
    const rota = "M40 150 C 120 40, 200 200, 280 90 S 360 40, 370 60";
    el.querySelector(".k-arte").innerHTML = `<svg viewBox="0 0 400 190"><path class="k-traco fraco" stroke-dasharray="2 8" d="${rota}"/><path class="k-traco acento k-rota" d="${rota}"/>
      <g class="k-pino a"><circle class="k-cheio" cx="40" cy="150" r="9"/><circle class="k-traco" cx="40" cy="150" r="16"/></g>
      <g class="k-pino b"><path class="k-cheio" d="M370 60 m0 -8 a14 14 0 1 0 0.1 0 Z"/><path class="k-cheio" d="M362 62 L370 82 L378 62 Z"/></g>
      <circle r="6" fill="#fff" style="filter:drop-shadow(0 0 8px #3fd0ff)"><animateMotion dur="1.6s" begin="0.4s" fill="freeze" path="${rota}"/></circle>
      <path class="k-traco fraco" d="M40 180 L370 180 M40 172 L40 188 M370 172 L370 188"/></svg>`;
    colocarGrafico(el, 4000);
    desenhar(el.querySelector(".k-rota"), 400, 1600);
    el.querySelectorAll(".k-pino").forEach((p, k) => pop(p, k ? 1700 : 100));
    contar(el.querySelector(".k-numero span"), 0, mostrado, 1700, formatoBR);
  }

  function termometro(valor, rotulo) {
    const min = Math.min(-20, valor - 10), max = Math.max(50, valor + 10);
    const y = (v) => 200 - ((v - min) / (max - min)) * 170;
    const el = base("k-termometro", valor, "°C", rotulo);
    let marcas = "";
    for (let v = Math.ceil(min / 10) * 10; v <= max; v += 10) marcas += `<path class="k-traco fraco" d="M118 ${y(v)} L134 ${y(v)}"/><text x="142" y="${y(v) + 4}" font-size="11" fill="currentColor" opacity=".55" font-family="JetBrains Mono">${v}°</text>`;
    el.querySelector(".k-arte").innerHTML = `<svg viewBox="0 0 400 250"><path class="k-traco" d="M84 20 a16 16 0 0 1 32 0 V196 a26 26 0 1 1 -32 0 Z"/>${marcas}
      <circle class="k-cheio" cx="100" cy="218" r="18"/><rect class="k-cheio k-mercurio" x="92" y="${y(valor)}" width="16" height="${210 - y(valor)}" rx="8"/></svg>`;
    colocarGrafico(el, 3800);
    el.querySelectorAll(".k-traco").forEach((p, k) => desenhar(p, k * 25, 600));
    const merc = el.querySelector(".k-mercurio"); merc.style.transformOrigin = "100px 210px"; merc.style.transformBox = "view-box";
    animar(merc, [{ transform: "scaleY(0)" }, { transform: "scaleY(1)" }], { duration: 1300, delay: 350, easing: MOLA });
    contar(el.querySelector(".k-numero span"), 0, valor, 1500, (v) => String(Math.round(v)));
  }

  function relogio(n, mostrado, sufixo, rotulo) {
    const el = base("k-relogio", mostrado, sufixo, rotulo);
    let marcas = "";
    for (let k = 0; k < 60; k++) { const a = (k / 60) * Math.PI * 2, r1 = k % 5 ? 80 : 70; marcas += `<path class="k-traco ${k % 5 ? "fraco" : ""} k-marca-r" d="M${200 + Math.sin(a) * r1} ${100 - Math.cos(a) * r1} L${200 + Math.sin(a) * 90} ${100 - Math.cos(a) * 90}"/>`; }
    el.querySelector(".k-arte").innerHTML = `<svg viewBox="0 0 400 200">${marcas}<path class="k-traco acento k-volta" d="M200 0 A100 100 0 1 1 199.9 0"/><g class="k-ponteiro"><path class="k-traco acento" d="M200 100 L200 30"/><circle class="k-cheio" cx="200" cy="100" r="6"/></g></svg>`;
    colocarGrafico(el, 3800);
    el.querySelectorAll(".k-marca-r").forEach((p, k) => animar(p, [{ opacity: 0 }, { opacity: p.classList.contains("fraco") ? .25 : 1 }], { duration: 200, delay: k * 16, easing: "linear" }));
    desenhar(el.querySelector(".k-volta"), 200, 1300);
    const pont = el.querySelector(".k-ponteiro"); pont.style.transformOrigin = "200px 100px";
    animar(pont, [{ transform: "rotate(0deg)" }, { transform: "rotate(720deg)" }], { duration: 1600, delay: 150, easing: MOLA });
    contar(el.querySelector(".k-numero span"), 0, mostrado, 1500, formatoBR);
  }

  function multiplicador(n, rotulo) {
    const el = base("k-multi", n, "×", rotulo);
    const blocos = document.createElement("div"); blocos.className = "k-blocos";
    const qtd = Math.min(32, Math.max(2, Math.round(n)));
    for (let k = 0; k < qtd; k++) blocos.append(document.createElement("i"));
    el.querySelector(".k-arte").append(blocos);
    el.querySelector(".k-legenda").textContent = `1 → ${formatoBR(n)}`;
    colocarGrafico(el, 3800);
    [...blocos.children].forEach((b, k) => pop(b, k ? 300 + k * 40 : 80));
    contar(el.querySelector(".k-numero span"), 1, n, 1200, (v) => (n % 1 ? v.toFixed(1).replace(".", ",") : formatoBR(v)));
  }

  function barras(itens) { // compara os números ditos no mesmo trecho
    const el = document.createElement("div"); el.className = "k-desenho k-barras";
    const max = Math.max(...itens.map((i) => i.valor));
    itens.slice(-4).forEach((i, k, lista) => {
      const linhaB = document.createElement("div"); linhaB.className = "k-linha-barra" + (k === lista.length - 1 ? " atual" : "");
      linhaB.innerHTML = `<div class="k-topo-barra"><span></span><b></b></div><div class="k-trilho-barra"><i></i></div>`;
      linhaB.querySelector("span").textContent = i.rotulo || "";
      el.append(linhaB);
      setTimeout(() => contar(linhaB.querySelector("b"), 0, i.mostrado, 1100, formatoBR), k * 160);
      animar(linhaB.querySelector("i"), [{ transform: "scaleX(0)" }, { transform: `scaleX(${Math.max(.04, i.valor / max)})` }], { duration: 1200, delay: k * 160, easing: MOLA });
      pop(linhaB.querySelector(".k-topo-barra"), k * 160);
    });
    colocarGrafico(el, 4200);
  }

  // escolhe o desenho pela unidade dita depois do número
  const UNIDADES = [
    [/^(pessoas?|habitantes?|soldados?|mortos?|vidas?|homens|mulheres|crian[cç]as|alunos?|estudantes?|funcion[aá]rios?|usu[aá]rios?|f[aã]s|torcedores?|trabalhadores?|cidad[aã]os?|eleitores?|refugiados?|v[ií]timas?|jogadores?|seguidores?|clientes?|brasileiros?|americanos?|europeus?|africanos?)$/i, "pessoas"],
    [/^(reais|real|d[oó]lares?|euros?|libras?|ienes?|bitcoins?)$/i, "dinheiro"],
    [/^(km\/h|kmh|mph|n[oó]s)$/i, "velocidade"],
    [/^(km|quil[oô]metros?|metros?|milhas?|anos-luz|cent[ií]metros?)$/i, "distancia"],
    [/^(graus?|°c|celsius)$/i, "temperatura"],
    [/^(anos?|dias?|horas?|minutos?|segundos?|s[eé]culos?|meses|m[eê]s|semanas?|d[eé]cadas?|mil[eê]nios?)$/i, "tempo"],
    [/^(vezes)$/i, "vezes"],
  ];
  const ESCALA = { mil: 1e3, milhao: 1e6, milhoes: 1e6, bilhao: 1e9, bilhoes: 1e9, trilhao: 1e12, trilhoes: 1e12 };
  let numerosDoTrecho = [];

  function graficoDeNumero(valorDito, seguir, k) {
    let j = k + 1, escala = 1, sufixo = "";
    const s = norm(seguir[j] || "");
    if (ESCALA[s]) { escala = ESCALA[s]; sufixo = seguir[j].toLowerCase(); j++; }
    if (norm(seguir[j] || "") === "de") j++; // "600 mil DE pessoas"
    const palavraUnidade = (seguir[j] || "").toLowerCase().replace(/[.,;:!?]+$/, "");
    let tipo = UNIDADES.find(([re]) => re.test(palavraUnidade))?.[1];
    if (tipo === "distancia" && norm(seguir[j + 1] || "") === "por" && /^hora/.test(norm(seguir[j + 2] || ""))) tipo = "velocidade"; // "quilômetros por hora"
    if (!tipo && valorDito < 10 && escala === 1) return null; // número pequeno e solto: fica só no texto
    const valor = valorDito * escala;
    const rotulo = seguir.slice(k + 1, j + 1).join(" ");
    const moedaAntes = (seguir[k - 1] || "");
    numerosDoTrecho.push({ valor, mostrado: valorDito, rotulo: (sufixo ? sufixo + " " : "") + (tipo ? palavraUnidade : rotulo) });
    if (/^(r\$|us\$|\$|€|£)$/i.test(moedaAntes)) return () => dinheiro(valor, valorDito, sufixo, rotulo, moedaAntes.toUpperCase());
    switch (tipo) {
      case "pessoas": return () => pessoas(valor, valorDito, sufixo, palavraUnidade);
      case "dinheiro": return () => dinheiro(valor, valorDito, sufixo, palavraUnidade, /d[oó]lar/.test(palavraUnidade) ? "US$" : /euro/.test(palavraUnidade) ? "€" : /libra/.test(palavraUnidade) ? "£" : "R$");
      case "velocidade": return () => velocimetro(valor, rotulo);
      case "distancia": return () => distancia(valor, valorDito, (sufixo ? sufixo + " " : "") + (/^km|quil/.test(palavraUnidade) ? "km" : palavraUnidade), rotulo);
      case "temperatura": return () => termometro(valorDito, rotulo);
      case "tempo": return () => relogio(valor, valorDito, sufixo, palavraUnidade);
      case "vezes": return () => multiplicador(valorDito, rotulo);
    }
    // número sem unidade conhecida: se já houve outro número neste trecho, compara em barras
    if (numerosDoTrecho.length >= 2 && new Set(numerosDoTrecho.map((x) => x.valor)).size >= 2) return () => barras(numerosDoTrecho.slice());
    return () => contador(valorDito, rotulo);
  }

  /* escolhe o gráfico da batida: número/ano/porcentagem > foto da palavra > foto pendente > nós */
  let ultimoForte = null;
  function escolherGrafico(palavras, depois = []) {
    const limpas = palavras.map(semPont);
    const seguir = [...limpas, ...depois.map(semPont)];
    for (let k = 0; k < limpas.length; k++) {
      const p = limpas[k].replace(/[!?]$/, "");
      const seguinte = (seguir[k + 1] || "").toLowerCase();
      if (/^\d{1,3}(,\d+)?%$/.test(p) || (/^\d{1,3}(,\d+)?$/.test(p) && /^por(cento)?$/.test(seguinte))) return () => anel(parseFloat(p.replace(",", ".")));
      if (/^(1[0-9]|20)\d{2}$/.test(p) && +p >= 1000 && +p <= 2100) return () => linhaDoTempo(+p);
      const num = p.replace(/\./g, "").replace(",", ".");
      if (/^\d+(\.\d+)?$/.test(num) && +num > 0) {
        const g = graficoDeNumero(+num, seguir, k);
        if (g) return g;
      }
    }
    // foto da palavra que está sendo dita
    for (const p of limpas) {
      const n = norm(p);
      if (n.length < 3) continue;
      for (const v of visuais.values()) if (!v.usada && (v.chave === n || v.primeira === n)) { v.usada = true; return () => cartaoFoto(v); }
    }
    // foto que chegou depois que a palavra passou: entra como "b-roll" se a tela está sem gráfico há um tempo
    if (!grafico && batidasSemGrafico >= 2) {
      const pendente = [...visuais.values()].find((v) => !v.usada && v.img.complete && v.img.naturalWidth);
      if (pendente) { pendente.usada = true; return () => cartaoFoto(pendente); }
    }
    // de vez em quando, um diagrama ligando a ideia anterior à atual
    const fortes = limpas.filter((p) => p.length > 3 && !PEQUENAS.has(p.toLowerCase()));
    const chave = fortes.sort((x, y) => y.length - x.length)[0];
    if (!grafico && batidasSemGrafico >= 5 && chave && ultimoForte && norm(ultimoForte) !== norm(chave)) {
      const a = ultimoForte;
      ultimoForte = chave;
      return () => nos(a, chave, "conectando");
    }
    if (chave) ultimoForte = chave;
    return null;
  }

  function mostrar(b, nB) {
    batidasSemGrafico++;
    const desenhar = escolherGrafico(b.palavras, b.depois);
    if (desenhar) desenhar();
    const el = document.createElement("div");
    const palavras = b.palavras.map(limpar);
    const fortes = palavras.filter((p) => !PEQUENAS.has(semPont(p).toLowerCase()));
    const chave = [...fortes].sort((x, y) => semPont(y).length - semPont(x).length)[0] || palavras[palavras.length - 1];
    const ultimo = palavras[palavras.length - 1];
    const pergunta = /\?$/.test(ultimo), ponto = /[.!…]$/.test(ultimo);
    el.className = "k-batida";
    const vida = document.createElement("div"); vida.className = "k-vida"; el.append(vida);
    const linhas = [];
    let tipo;

    if (fortes.length <= 1 && palavras.join(" ").length <= 16) {
      // uma palavra só: GIGANTE e centralizada
      el.classList.add("centro");
      tipo = ["batida", "letras", "batida", "lado"][nB % 4];
      const pequenas = palavras.filter((p) => p !== chave);
      if (pequenas.length) linhas.push(linha(pequenas.map(semPont).join(" "), "k-pequena"));
      const g = linha(semPont(chave) + (pergunta && chave === ultimo ? "?" : ""), semPont(chave).length > 8 ? "k-grande" : "k-gigante");
      if (chave === ultimo && ponto) g.classList.add("k-ponto");
      linhas.push(g);
    } else {
      // empilhado à esquerda: palavras pequenas miúdas, a palavra-chave em vermelho
      el.classList.add("esquerda");
      tipo = ["lado", "baixo", "lado", "batida"][nB % 4];
      let pendente = [];
      palavras.forEach((p, k) => {
        const fraca = PEQUENAS.has(semPont(p).toLowerCase());
        if (fraca && k < palavras.length - 1) { pendente.push(semPont(p)); return; }
        if (pendente.length) { linhas.push(linha(pendente.join(" "), "k-pequena")); pendente = []; }
        const txt = semPont(p) + (k === palavras.length - 1 && pergunta ? "?" : "");
        const l = linha(txt, (txt.length > 10 ? "k-grande k-estreita" : "k-grande") + (p === chave ? " k-destaque" : ""));
        if (k === palavras.length - 1 && ponto) l.classList.add("k-ponto");
        if (nB % 5 === 3 && p !== chave) l.classList.add("k-contorno");
        linhas.push(l);
      });
      if (pendente.length) linhas.push(linha(pendente.join(" "), "k-pequena"));
    }
    linhas.forEach((l) => vida.append(l));
    camera.append(el);
    ajustar(el); // mede antes de animar: transform não afeta offsetWidth

    // a anterior sai com rastro para a esquerda enquanto a nova já está entrando (sobreposição)
    if (atual) sair(atual);
    atual = el;
    linhas.forEach((l, k) => (l.classList.contains("k-pequena") ? ENTRADAS.baixo : ENTRADAS[tipo])(l, k * 70));
    // vida: deriva lenta (zoom e deslize) enquanto está na tela
    animar(vida, [{ transform: "translate3d(0,0,0) scale(1)" }, { transform: `translate3d(${el.classList.contains("esquerda") ? "1.2vw" : "0"},0,0) scale(1.07)` }], { duration: 3200, easing: "linear" });
    // tranco de câmera em cada batida (um "punch-in" curtinho)
    animar(el, [{ transform: "scale(1.035)" }, { transform: "scale(1)" }], { duration: 380, easing: MOLA });
    raios = 1; chute = 1;
  }

  function sair(el) {
    el.classList.add("saindo");
    for (const l of el.querySelectorAll(".k-linha")) {
      animar(l.querySelector(".k-txt"), [{ transform: "translate3d(0,0,0)", opacity: 1 }, { transform: "translate3d(-9vw,0,0)", opacity: 0 }], { duration: 230, easing: SAIDA });
      animar(l.querySelector(".k-fantasma"), [{ transform: "translate3d(0,0,0) scaleX(1)", opacity: 0 }, { transform: "translate3d(-4vw,0,0) scaleX(1.5)", opacity: .55, offset: .4 }, { transform: "translate3d(-16vw,0,0) scaleX(2)", opacity: 0 }], { duration: 260, easing: SAIDA });
    }
    setTimeout(() => el.remove(), 300);
  }

  /* encolhe o texto que não cabe na largura da tela (medido sem as transformações) */
  function ajustar(el) {
    const max = window.innerWidth * (raiz.classList.contains("com-grafico") ? 0.44 : 0.9);
    if (max < 100) return; // janela minimizada: sem medidas confiáveis
    el.querySelectorAll(".k-linha").forEach((l) => {
      const w = l.offsetWidth;
      if (w > max) l.style.fontSize = `${(parseFloat(getComputedStyle(l).fontSize) * max * 0.97) / w}px`;
    });
  }

  /* troca de fundo entre frases: crossfade das camadas + um efeito de transição do vídeo */
  function trocarFundo() {
    const novo = FUNDOS[nFrase++ % FUNDOS.length];
    if (novo === fundo) return;
    const efeito = document.createElement("div");
    let espera = 140;
    if (novo === "vermelho") {
      efeito.className = "k-circulo";
      animar(efeito, [{ transform: "translate(-50%,-50%) scale(0)" }, { transform: "translate(-50%,-50%) scale(330)" }], { duration: 520, easing: "cubic-bezier(.7,0,.25,1)" });
      espera = 380;
    } else if (nFrase % 2) {
      efeito.className = "k-tiras";
      efeito.innerHTML = "<i></i><i></i><i></i><i></i><i></i><i></i>";
      [...efeito.children].forEach((t, k) => animar(t, [{ transform: `translate3d(${k % 2 ? 100 : -100}%,0,0)` }, { transform: "translate3d(0,0,0)", offset: .5 }, { transform: `translate3d(${k % 2 ? -100 : 100}%,0,0)` }], { duration: 420, delay: k * 18, easing: "cubic-bezier(.65,0,.35,1)" }));
      espera = 210;
    } else {
      efeito.className = "k-flash";
      animar(efeito, [{ transform: "scaleX(0)", opacity: 1 }, { transform: "scaleX(1)", opacity: 1, offset: .55 }, { transform: "scaleX(1) scaleY(.2)", opacity: 0 }], { duration: 480, easing: MOLA });
    }
    raiz.append(efeito);
    setTimeout(() => {
      fundo = novo; raiz.dataset.fundo = novo;
      raiz.querySelectorAll(".k-fundo").forEach((f) => f.classList.toggle("visivel", f.dataset.cor === novo));
    }, espera);
    setTimeout(() => efeito.remove(), 900);
  }

  function ligar() {
    criarRaiz();
    clearTimeout(timerFim);
    raiz.classList.add("ativo");
  }
  function desligarEmBreve(ms = 1500) {
    clearTimeout(timerFim);
    timerFim = setTimeout(() => {
      raiz?.classList.remove("ativo");
      clearTimeout(timerGrafico); if (grafico) { grafico.remove(); grafico = null; raiz?.classList.remove("com-grafico"); }
      setTimeout(() => { if (raiz && !raiz.classList.contains("ativo")) { raiz.querySelectorAll(".k-batida, .k-prompt, .k-rotulo").forEach((e) => e.remove()); atual = null; } }, 500);
    }, ms);
  }

  /* ---------- a pergunta do usuário aparece digitada numa caixa de prompt ---------- */
  function mostrarPergunta(texto) {
    if (muralAberto()) return;
    ligar();
    raiz.querySelectorAll(".k-batida, .k-prompt, .k-rotulo").forEach((e) => e.remove()); atual = null;
    if (grafico) { grafico.remove(); grafico = null; raiz.classList.remove("com-grafico"); }
    fundo = "preto"; raiz.dataset.fundo = "preto"; nFrase = 0;
    raiz.querySelectorAll(".k-fundo").forEach((f) => f.classList.toggle("visivel", f.dataset.cor === "preto"));
    const rotulo = document.createElement("div"); rotulo.className = "k-rotulo"; rotulo.textContent = "● J.A.R.V.I.S.";
    const caixa = document.createElement("div"); caixa.className = "k-prompt";
    const corpo = document.createElement("span"); const cursor = document.createElement("span"); cursor.className = "k-cursor";
    const enter = document.createElement("span"); enter.className = "k-enter"; enter.textContent = "↵";
    caixa.append(corpo, cursor, enter);
    camera.append(rotulo, caixa);
    animar(caixa, [{ transform: "translate(-50%,-30%) scale(.96)", opacity: 0 }, { transform: "translate(-50%,-50%) scale(1)", opacity: 1 }], { duration: 600, easing: MOLA });
    animar(rotulo, [{ opacity: 0, letterSpacing: ".6em" }, { opacity: 1, letterSpacing: ".3em" }], { duration: 700, easing: MOLA });
    const palavras = texto.trim().split(/\s+/);
    const marcadas = new Set([...palavras].filter((p) => !PEQUENAS.has(semPont(p).toLowerCase())).sort((a, b) => semPont(b).length - semPont(a).length).slice(0, 2));
    // digita letra a letra (mais macio que palavra a palavra)
    let k = 0, c = 0, alvo = null;
    const digitar = () => {
      if (!caixa.isConnected) return;
      if (!alvo) {
        if (k >= palavras.length) return;
        const p = palavras[k++];
        alvo = { texto: p, el: marcadas.has(p) ? document.createElement("mark") : document.createElement("span") };
        corpo.append(alvo.el);
        if (alvo.el.tagName === "MARK") animar(alvo.el, [{ transform: "scaleX(0)", transformOrigin: "left" }, { transform: "scaleX(1)", transformOrigin: "left" }], { duration: 260, easing: MOLA });
        c = 0;
      }
      alvo.el.textContent += alvo.texto[c++];
      if (c >= alvo.texto.length) { corpo.append(document.createTextNode(" ")); alvo = null; }
      setTimeout(digitar, 22 + Math.random() * 26);
    };
    digitar();
    desligarEmBreve(25000); // se a resposta não vier, some sozinho
  }

  /* ---------- liga na legenda sincronizada que já existe ---------- */
  const montarOriginal = window.montarLegenda;
  if (typeof montarOriginal === "function") {
    window.montarLegenda = function (trecho) {
      const leg = montarOriginal(trecho);
      if (muralAberto()) { raiz?.classList.remove("ativo"); return leg; }
      ligar();
      const velhos = raiz.querySelectorAll(".k-prompt, .k-rotulo");
      velhos.forEach((e) => { animar(e, [{ opacity: 1 }, { opacity: 0, filter: "blur(4px)" }], { duration: 220, easing: SAIDA }); setTimeout(() => e.remove(), 240); });
      const lista = batidas(leg.palavras);
      numerosDoTrecho = [];
      anosDoTrecho = leg.palavras.map(semPont).filter((p) => /^(1[0-9]|20)\d{2}$/.test(p)).map(Number);
      let proxima = 0, nB = 0, fraseNova = true, desdeTroca = 0;
      const marcar = leg.marcar;
      leg.marcar = function (i) {
        marcar.call(leg, i);
        if (muralAberto()) { raiz.classList.remove("ativo"); return; }
        while (proxima < lista.length && lista[proxima].inicio <= i) {
          if (fraseNova || desdeTroca >= 4) { trocarFundo(); fraseNova = false; desdeTroca = 0; }
          desdeTroca++;
          const b = lista[proxima++];
          mostrar(b, nB++);
          if (fimDeFrase(b.palavras[b.palavras.length - 1])) fraseNova = true;
        }
        if (i >= leg.palavras.length - 1) desligarEmBreve(1600); else clearTimeout(timerFim);
      };
      return leg;
    };
  }

  const legendaOriginal = window.legenda;
  if (typeof legendaOriginal === "function") {
    window.legenda = function (texto, classe) {
      legendaOriginal(texto, classe);
      if (classe === "usuario" && texto && texto.trim().split(/\s+/).length >= 3 && !/^pois n[aã]o/i.test(texto)) mostrarPergunta(texto);
    };
  }

  // tecla K liga/desliga o modo (fica lembrado neste navegador)
  let ligado = true;
  try { ligado = localStorage.getItem("jarvis-katana") !== "0"; } catch {}
  if (!ligado) { window.montarLegenda = montarOriginal; window.legenda = legendaOriginal; }
  document.addEventListener("keydown", (e) => {
    if (e.key.toLowerCase() !== "k" || /input|textarea/i.test(e.target.tagName)) return;
    ligado = !ligado;
    try { localStorage.setItem("jarvis-katana", ligado ? "1" : "0"); } catch {}
    location.reload();
  });
  window.katanaTeste = (texto, ms = 300) => { visuais = new Map(); pedirVisuais(texto); mostrarPergunta("o que é um buraco negro?"); setTimeout(() => { const leg = window.montarLegenda(texto); let i = 0; const t = setInterval(() => { leg.marcar(i++); if (i >= leg.palavras.length) clearInterval(t); }, ms); }, 2500); };
})();
