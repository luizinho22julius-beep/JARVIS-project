"use strict";
/* JARVIS — visual de cockpit: cidade noturna ao fundo, moldura, mapa 3D, missão do dia, terminal e objeto detectado.
   Carregado depois do script principal (usa $, criar, estado e registrar de lá). */

/* ================= cidade noturna (fundo) ================= */
(function cidade() {
  const c = $("fundo"), g = c.getContext("2d");
  let semente = 7;
  const aleatorio = () => ((semente = (semente * 16807) % 2147483647) / 2147483647);
  let base = null, gotas = [], luzes = [];

  function desenharBase(w, h) {
    semente = 7;
    const off = document.createElement("canvas"); off.width = w; off.height = h;
    const o = off.getContext("2d");
    const fuga = { x: w * .5, y: h * .52 };
    // céu
    const ceu = o.createLinearGradient(0, 0, 0, fuga.y);
    ceu.addColorStop(0, "#020614"); ceu.addColorStop(1, "#0c2452");
    o.fillStyle = ceu; o.fillRect(0, 0, w, h);
    // prédios ao fundo (silhuetas com janelas acesas)
    for (let x = 0; x < w; ) {
      const lb = 30 + aleatorio() * 90, alt = h * (.12 + aleatorio() * .3);
      o.fillStyle = `rgb(${8 + aleatorio() * 8},${14 + aleatorio() * 10},${28 + aleatorio() * 18})`;
      o.fillRect(x, fuga.y - alt, lb, alt);
      for (let jy = fuga.y - alt + 6; jy < fuga.y - 4; jy += 7) for (let jx = x + 4; jx < x + lb - 4; jx += 6) {
        if (aleatorio() < .22) { o.fillStyle = aleatorio() < .3 ? "rgba(255,214,150,.5)" : "rgba(140,205,255,.55)"; o.fillRect(jx, jy, 2.5, 3.5); }
      }
      x += lb + 2;
    }
    // prédios laterais em perspectiva (rua)
    for (const lado of [-1, 1]) {
      for (let k = 0; k < 9; k++) {
        const t0 = k / 9, t1 = (k + .85) / 9;
        const xa = fuga.x + lado * (w * .06 + Math.pow(t0, 1.6) * w * .6), xb = fuga.x + lado * (w * .06 + Math.pow(t1, 1.6) * w * .6);
        const topo = fuga.y - h * (.18 + t0 * 1.1 + aleatorio() * .2), chao = fuga.y + h * (t0 * .5);
        const topo2 = fuga.y - h * (.18 + t1 * 1.1), chao2 = fuga.y + h * (t1 * .5);
        o.fillStyle = `rgb(${6 + k},${10 + k * 2},${20 + k * 3})`;
        o.beginPath(); o.moveTo(xa, topo); o.lineTo(xb, topo2); o.lineTo(xb, chao2); o.lineTo(xa, chao); o.fill();
        for (let n = 0; n < 60 * (k + 1); n++) {
          const u = aleatorio(), v = aleatorio();
          const px = xa + (xb - xa) * u, py = (topo + (topo2 - topo) * u) + ((chao + (chao2 - chao) * u) - (topo + (topo2 - topo) * u)) * v;
          if (aleatorio() < .35) { o.fillStyle = aleatorio() < .25 ? "rgba(255,205,140,.55)" : "rgba(120,195,255,.6)"; o.fillRect(px, py, 1.5 + k * .4, 2 + k * .5); }
        }
      }
    }
    // rua
    const rua = o.createLinearGradient(0, fuga.y, 0, h);
    rua.addColorStop(0, "#0a1426"); rua.addColorStop(1, "#04070f");
    o.fillStyle = rua;
    o.beginPath(); o.moveTo(fuga.x - w * .05, fuga.y); o.lineTo(fuga.x + w * .05, fuga.y); o.lineTo(w * 1.1, h); o.lineTo(-w * .1, h); o.fill();
    o.strokeStyle = "rgba(255,210,140,.35)"; o.lineWidth = 2; o.setLineDash([18, 22]);
    o.beginPath(); o.moveTo(fuga.x, fuga.y); o.lineTo(fuga.x, h); o.stroke(); o.setLineDash([]);
    // reflexo azul do asfalto molhado
    const reflexo = o.createRadialGradient(fuga.x, h * .85, 0, fuga.x, h * .85, w * .5);
    reflexo.addColorStop(0, "rgba(60,140,255,.18)"); reflexo.addColorStop(1, "rgba(0,0,0,0)");
    o.fillStyle = reflexo; o.fillRect(0, 0, w, h);
    // névoa e escurecimento para os painéis lerem bem
    o.fillStyle = "rgba(3,6,16,.22)"; o.fillRect(0, 0, w, h);
    const vinheta = o.createRadialGradient(w / 2, h / 2, h * .2, w / 2, h / 2, w * .75);
    vinheta.addColorStop(0, "rgba(0,0,0,0)"); vinheta.addColorStop(1, "rgba(0,0,0,.75)");
    o.fillStyle = vinheta; o.fillRect(0, 0, w, h);
    luzes = Array.from({ length: 14 }, () => ({ x: fuga.x + (aleatorio() - .5) * w * .5, y: fuga.y + aleatorio() * h * .35, r: 2 + aleatorio() * 6, cor: aleatorio() < .5 ? "70,170,255" : "190,230,255", fase: aleatorio() * 6 }));
    return off;
  }

  function tamanho() {
    c.width = innerWidth * devicePixelRatio; c.height = innerHeight * devicePixelRatio;
    base = desenharBase(c.width, c.height);
    gotas = Array.from({ length: 90 }, () => ({ x: Math.random() * c.width, y: Math.random() * c.height, v: 6 + Math.random() * 8 }));
  }
  addEventListener("resize", tamanho); tamanho();
  let t = 0;
  (function quadro() {
    requestAnimationFrame(quadro); // agenda antes: um quadro com erro não para o fundo de vez
    t++;
    if (!base.width || !base.height || !c.width) { if (innerWidth > 0) tamanho(); return; } // janela minimizada ao abrir
    g.drawImage(base, 0, 0);
    // faróis e lanternas com brilho suave (bokeh)
    for (const l of luzes) {
      const a = .35 + .25 * Math.sin(t * .03 + l.fase);
      const r = g.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.r * 6 * devicePixelRatio);
      r.addColorStop(0, `rgba(${l.cor},${a})`); r.addColorStop(1, `rgba(${l.cor},0)`);
      g.fillStyle = r; g.fillRect(l.x - l.r * 6 * devicePixelRatio, l.y - l.r * 6 * devicePixelRatio, l.r * 12 * devicePixelRatio, l.r * 12 * devicePixelRatio);
    }
    // chuva fina
    g.strokeStyle = "rgba(160,200,255,.12)"; g.lineWidth = devicePixelRatio;
    g.beginPath();
    for (const d of gotas) { d.y += d.v; d.x -= d.v * .15; if (d.y > c.height) { d.y = -20; d.x = Math.random() * c.width * 1.1; } g.moveTo(d.x, d.y); g.lineTo(d.x + 2, d.y - 12); }
    g.stroke();
  })();
})();

/* ================= mapa 3D da cidade com marcador ================= */
(function mapa() {
  const c = $("mapa"); if (!c) return;
  const g = c.getContext("2d");
  let ang = 0;
  const blocos = [];
  let s = 11; const r = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  for (let i = -5; i <= 5; i++) for (let j = -5; j <= 5; j++) if (r() < .72) blocos.push({ i, j, h: 4 + r() * r() * 34 });
  (function quadro() {
    const w = c.clientWidth * devicePixelRatio, h = c.clientHeight * devicePixelRatio;
    if (c.width !== w) { c.width = w; c.height = h; }
    g.clearRect(0, 0, w, h);
    ang += .0025;
    const esc = Math.min(w, h) / 15, cx = w / 2, cy = h * .62;
    const proj = (x, y, z) => { const ca = Math.cos(ang), sa = Math.sin(ang); const rx = x * ca - y * sa, ry = x * sa + y * ca; return [cx + (rx - ry) * esc * .9, cy + (rx + ry) * esc * .45 - z * devicePixelRatio * 1.2]; };
    // grade do chão
    g.strokeStyle = "rgba(127,220,255,.18)"; g.lineWidth = devicePixelRatio;
    for (let k = -6; k <= 6; k++) { g.beginPath(); g.moveTo(...proj(k, -6, 0)); g.lineTo(...proj(k, 6, 0)); g.moveTo(...proj(-6, k, 0)); g.lineTo(...proj(6, k, 0)); g.stroke(); }
    // prédios em arame, de trás para frente
    const ordem = [...blocos].sort((a, b) => { const ca = Math.cos(ang), sa = Math.sin(ang); return (a.i * sa + a.j * ca + a.i * ca - a.j * sa) - (b.i * sa + b.j * ca + b.i * ca - b.j * sa); });
    for (const b of ordem) {
      const x = b.i, y = b.j, d = .38;
      const base = [proj(x - d, y - d, 0), proj(x + d, y - d, 0), proj(x + d, y + d, 0), proj(x - d, y + d, 0)];
      const topo = [proj(x - d, y - d, b.h), proj(x + d, y - d, b.h), proj(x + d, y + d, b.h), proj(x - d, y + d, b.h)];
      g.fillStyle = "rgba(20,70,140,.35)"; g.strokeStyle = "rgba(127,220,255,.55)";
      g.beginPath(); topo.forEach((p, k) => (k ? g.lineTo(...p) : g.moveTo(...p))); g.closePath(); g.fill(); g.stroke();
      g.beginPath(); for (let k = 0; k < 4; k++) { g.moveTo(...base[k]); g.lineTo(...topo[k]); } g.stroke();
    }
    // marcador pulsando no centro
    const [px, py] = proj(0, 0, 40);
    const pulso = (performance.now() / 900) % 1;
    g.strokeStyle = `rgba(127,220,255,${1 - pulso})`; g.lineWidth = 2 * devicePixelRatio;
    const [bx, by] = proj(0, 0, 0);
    g.beginPath(); g.ellipse(bx, by, pulso * esc * 1.6, pulso * esc * .8, 0, 0, 7); g.stroke();
    g.fillStyle = "#7fdcff"; g.shadowColor = "#7fdcff"; g.shadowBlur = 14 * devicePixelRatio;
    g.beginPath(); g.arc(px, py - 8 * devicePixelRatio, 7 * devicePixelRatio, Math.PI * .85, Math.PI * .15); g.lineTo(px, py + 8 * devicePixelRatio); g.closePath(); g.fill();
    g.shadowBlur = 0; g.fillStyle = "#04081a"; g.beginPath(); g.arc(px, py - 8 * devicePixelRatio, 3 * devicePixelRatio, 0, 7); g.fill();
    requestAnimationFrame(quadro);
  })();
  // nome da cidade vindo do clima
  const copiar = () => { const nome = $("cidade").textContent; if (nome && nome !== "—") $("localMapa").textContent = nome; };
  new MutationObserver(copiar).observe($("cidade"), { childList: true, characterData: true, subtree: true });
})();

/* ================= missão: objetivos do dia (ficam salvos neste navegador) ================= */
(function missao() {
  const lista = $("missao"); if (!lista) return;
  const PADRAO = [{ t: "Verificar os sistemas", f: false }, { t: "Ouvir o briefing do dia", f: false }, { t: "Revisar as mensagens", f: false }];
  let itens;
  try { itens = JSON.parse(localStorage.getItem("jarvis-missao")) ?? PADRAO; } catch { itens = PADRAO; }
  const salvar = () => { try { localStorage.setItem("jarvis-missao", JSON.stringify(itens)); } catch {} };
  function desenhar() {
    lista.innerHTML = "";
    itens.forEach((it, k) => {
      const li = criar("li", it.f ? "feito" : "");
      const caixa = criar("button", "caixa", it.f ? "✓" : ""); caixa.title = "Marcar como feito";
      caixa.onclick = () => { it.f = !it.f; salvar(); desenhar(); };
      const texto = criar("span", null, it.t);
      const apagar = criar("button", "apagar", "✕"); apagar.title = "Remover";
      apagar.onclick = () => { itens.splice(k, 1); salvar(); desenhar(); };
      li.append(caixa, texto, apagar); lista.append(li);
    });
  }
  $("formMissao").onsubmit = (e) => { e.preventDefault(); const v = $("novaMissao").value.trim(); if (!v) return; itens.push({ t: v.slice(0, 80), f: false }); $("novaMissao").value = ""; salvar(); desenhar(); };
  desenhar();
})();

/* ================= terminal, objeto detectado e bateria do topo ================= */
(function detalhes() {
  setInterval(() => { const d = $("objDist"); if (d) d.textContent = (18 + Math.sin(performance.now() / 4000) * 9).toFixed(1); }, 700);
  // o terminal mostra o último comando ouvido
  const log = $("log");
  new MutationObserver(() => {
    const ultimo = [...log.querySelectorAll(".msg.usuario span")].pop();
    if (ultimo) $("termUltimo").textContent = "» " + ultimo.textContent.slice(0, 42).toUpperCase();
  }).observe(log, { childList: true });
  // bateria do topo acompanha o anel de energia
  const copiar = () => { const pct = parseInt($("energia").textContent) || 100; $("bateriaTopo").style.width = pct + "%"; $("bateriaTopoTxt").textContent = pct + "%"; };
  new MutationObserver(copiar).observe($("energia"), { childList: true, characterData: true, subtree: true }); copiar();
})();
