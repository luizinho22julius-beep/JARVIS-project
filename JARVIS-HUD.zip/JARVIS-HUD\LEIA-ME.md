# J.A.R.V.I.S.

Assistente pessoal de voz para Windows, com HUD holográfico, respostas em tipografia cinética com gráficos animados, IA local e gratuita (Ollama) e um agente que programa, modela no Blender e mexe no Roblox Studio.

> Projeto de fã, sem vínculo com a Marvel ou a Disney. Tudo roda no seu PC; nada é enviado para servidores do projeto.

## Instalar (Windows 10 ou 11)

1. Baixe o arquivo `JARVIS-HUD.zip` e **extraia** para uma pasta (ex.: `Documentos\JARVIS`). Não rode de dentro do zip.
2. Dê dois cliques em **`instalar.bat`**. Ele:
   - instala o **Node.js** e o **Ollama** se ainda não tiver (pelo `winget`, que já vem no Windows);
   - escolhe e baixa o modelo de IA certo para a sua placa de vídeo (de 2 a 7 GB, só na primeira vez);
   - pergunta seu nome, como quer ser chamado e sua cidade (para o clima);
   - pede duas chaves **opcionais** e grátis (veja abaixo);
   - cria o atalho **JARVIS** na área de trabalho.
3. Abra pelo atalho **JARVIS**, clique em **ATIVAR SISTEMA** e permita o microfone.
4. Diga **"Jarvis, ..."** e o pedido. Ou clique no reator (ou aperte espaço) e fale direto.

Deixe a janela minimizada "J.A.R.V.I.S." aberta: fechá-la desliga o JARVIS.

## Requisitos

| | Mínimo | Recomendado |
|---|---|---|
| Sistema | Windows 10/11 64 bits | Windows 11 |
| Memória | 8 GB de RAM | 16 GB ou mais |
| Placa de vídeo | qualquer (roda no processador, mais devagar) | 8 GB+ de VRAM (NVIDIA ou AMD) |
| Disco | 6 GB livres | 15 GB livres |
| Navegador | Edge ou Chrome (reconhecimento de voz) | Edge |
| Internet | para clima, notícias, fotos e voz | |

O instalador escolhe o modelo sozinho: `qwen3.5:9b` (placa com 10 GB+), `qwen3.5:4b` (4 GB+ ou 16 GB de RAM) ou `qwen3.5:2b` (PCs modestos). Dá para trocar depois em `config.json`.

## Chaves opcionais (grátis)

| Para quê | Onde criar | Sem ela |
|---|---|---|
| **Voz do JARVIS** (Fish Audio) | https://fish.audio/app/api-keys | fala com a voz do Windows |
| **Modelos 3D reais** no Blender (Sketchfab) | sketchfab.com → Settings → Password & API | modela com peças feitas por código |

As chaves ficam só nas variáveis de usuário do seu Windows. Para adicionar depois, rode o `instalar.bat` de novo.

## O que ele faz

- **Conversa** em português, com respostas em **tipografia cinética**: palavras gigantes no ritmo da voz, fotos reais, linha do tempo, contadores, grade de pessoas, velocímetro, termômetro, rotas, gráficos de barra (tecla **K** liga/desliga).
- **Mural de imagens** para perguntas de história, notícias e ciência.
- Abre sites e programas, toca música, controla mídia e volume, bloqueia a tela.
- Clima, notícias, diagnóstico do PC e lembretes falados.
- **Agente programador** grátis: Python, JavaScript e Lua. Diga, por exemplo, "faça um jogo da cobrinha em Python".
- **Blender** (se instalado): "um dragão no Blender" busca um modelo real e renderiza com fotos de cenário reais.
- **Roblox Studio** (se instalado, com o MCP ligado nas configurações do Assistant): cria e edita coisas direto no jogo aberto.

## Problemas comuns

- **Ele não me ouve:** use o Edge ou o Chrome e permita o microfone (ícone de cadeado na barra de endereço).
- **Respostas lentas:** troque `modeloOllama` em `config.json` por um modelo menor (`qwen3.5:4b` ou `qwen3.5:2b`).
- **"Não consegui ligar o Ollama":** abra o app do Ollama pelo menu Iniciar e abra o JARVIS de novo.
- **A janela não abre:** acesse http://localhost:7777 no Edge ou no Chrome.

## Vozes de JARVIS no Fish Audio

Em **SISTEMA** (barra de baixo do HUD) você troca o ID da voz, a velocidade e o efeito.

| Voz | ID |
|---|---|
| JARVIS em português (padrão) | 82d13948027e4be69892dd3d0104e681 |
| JARVIS em português, versão 2 | d9a100f6d45f43dea41bd0c160d7e578 |
| JARVIS original (inglês) | 612b878b113047d9a770c069c8b4fdfe |

## Créditos

Fotos: Wikipedia/Wikimedia Commons, Openverse e NASA. Cenários e objetos 3D: Poly Haven (CC0). Modelos do Sketchfab: os créditos de cada autor ficam em `JARVIS-Projetos/assets/sketchfab/CREDITOS.txt`.
