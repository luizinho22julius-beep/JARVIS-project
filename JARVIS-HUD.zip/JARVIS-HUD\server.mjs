// JARVIS — servidor local: cérebro (Ollama ou ChatGPT), voz (Fish Audio) e comandos do PC.
import http from "node:http";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import readline from "node:readline";
import crypto from "node:crypto";
import { execFileSync, spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import OpenAI from "openai";
import { iniciarRapido, cancelarRapido, rapidoOcupado } from "./rapido.mjs";
import { iniciarTarefa, cancelarTarefa, agenteOcupado, abrirNoBlender, PASTA_PROJETOS } from "./agente.mjs";

const AQUI = path.dirname(fileURLToPath(import.meta.url));
const PUBLICO = path.join(AQUI, "public");
const ARQ_CONFIG = path.join(AQUI, "config.json");
const PORTA = Number(process.env.JARVIS_PORT) || 7777;

const MAX_TURNOS = 30; // acima disso começa uma conversa nova
const INATIVIDADE_MS = 30 * 60 * 1000;

const OLLAMA = process.env.OLLAMA_HOST?.startsWith("http") ? process.env.OLLAMA_HOST : "http://127.0.0.1:11434";

const CONFIG_PADRAO = {
  provedorIA: "ollama", // "ollama" (grátis, no seu PC) ou "openai" (ChatGPT, pago)
  modeloOllama: "qwen3.5:4b",
  modeloRapido: "qwen3.5:4b", // roteiro do mural, em paralelo com a resposta
  modeloCodigo: "", // agente programador (vazio = mesmo modelo do cérebro)
  modeloIA: "gpt-5.5",
  vozFishId: "82d13948027e4be69892dd3d0104e681", // voz do JARVIS em português (Fish Audio)
  modeloFish: "s2.1-pro-free",
  velocidadeVoz: 1.0,
  efeitoVoz: true,
  palavraAtivacao: "jarvis",
  tratamento: "senhor",
  nomeUsuario: "",
  cidade: "São Paulo",
};

// ---------- configuração e chaves ----------

function lerConfig() {
  try {
    return { ...CONFIG_PADRAO, ...JSON.parse(fs.readFileSync(ARQ_CONFIG, "utf8")) };
  } catch {
    return { ...CONFIG_PADRAO };
  }
}

function salvarConfig(novo) {
  const atual = lerConfig();
  const limpo = {};
  for (const chave of Object.keys(CONFIG_PADRAO)) {
    if (novo[chave] === undefined) continue;
    const tipo = typeof CONFIG_PADRAO[chave];
    if (tipo === "number") limpo[chave] = Math.min(2, Math.max(0.5, Number(novo[chave]) || 1));
    else if (tipo === "boolean") limpo[chave] = Boolean(novo[chave]);
    else limpo[chave] = String(novo[chave]).trim().slice(0, 200);
  }
  const final = { ...atual, ...limpo };
  fs.writeFileSync(ARQ_CONFIG, JSON.stringify(final, null, 2));
  return final;
}

/** Lê do ambiente ou, se o terminal foi aberto antes do setx, das variáveis de usuário do Windows. */
function variavelUsuario(nome) {
  if (process.env[nome]) return process.env[nome];
  try {
    const saida = execFileSync("reg", ["query", "HKCU\\Environment", "/v", nome], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
    const valor = saida.match(new RegExp(`${nome}\\s+REG_\\w+\\s+(.+)`))?.[1]?.trim();
    if (valor) process.env[nome] = valor;
    return valor || null;
  } catch {
    return null;
  }
}

/** Pede a chave no terminal sem mostrá-la e guarda nas variáveis de usuário (igual ao falar.py). */
async function pedirChave(nome, ajuda) {
  if (!process.stdin.isTTY) return null;
  console.log(`\n${ajuda}`);
  process.stdout.write("Cole a chave e aperte Enter (ela não aparece na tela): ");
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
  rl._writeToOutput = () => {}; // esconde o que for colado
  const chave = (await new Promise((ok) => rl.question("", ok))).trim();
  rl.close();
  console.log();
  if (!chave) return null;
  execFileSync("setx", [nome, chave], { stdio: "ignore" });
  process.env[nome] = chave;
  console.log(`${nome} salva. Não vou pedir de novo.`);
  return chave;
}

// ---------- estado do sistema ----------

let ultimaCpu = os.cpus();
function usoCpu() {
  const agora = os.cpus();
  let ocioso = 0;
  let total = 0;
  agora.forEach((cpu, i) => {
    const antes = ultimaCpu[i]?.times ?? { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 };
    for (const k of Object.keys(cpu.times)) total += cpu.times[k] - antes[k];
    ocioso += cpu.times.idle - antes.idle;
  });
  ultimaCpu = agora;
  return total > 0 ? Math.round(100 * (1 - ocioso / total)) : 0;
}

async function statusSistema() {
  const memTotal = os.totalmem();
  const memLivre = os.freemem();
  let disco = null;
  try {
    const s = await fs.promises.statfs(process.env.SystemDrive ? `${process.env.SystemDrive}\\` : "/");
    disco = { usoPct: Math.round(100 * (1 - s.bavail / s.blocks)), livreGB: +((s.bavail * s.bsize) / 1e9).toFixed(1) };
  } catch {}
  return {
    cpuPct: usoCpu(),
    cpuModelo: os.cpus()[0]?.model?.trim(),
    nucleos: os.cpus().length,
    memoriaPct: Math.round(100 * (1 - memLivre / memTotal)),
    memoriaTotalGB: +(memTotal / 1e9).toFixed(1),
    disco,
    ligadoHa: `${Math.floor(os.uptime() / 3600)}h ${Math.floor((os.uptime() % 3600) / 60)}min`,
    maquina: os.hostname(),
  };
}

// ---------- clima (Open-Meteo, sem chave) ----------

const CODIGOS_CLIMA = {
  0: "céu limpo", 1: "predominantemente limpo", 2: "parcialmente nublado", 3: "nublado",
  45: "neblina", 48: "neblina", 51: "garoa fraca", 53: "garoa", 55: "garoa forte",
  61: "chuva fraca", 63: "chuva", 65: "chuva forte", 71: "neve fraca", 73: "neve", 75: "neve forte",
  80: "pancadas de chuva", 81: "pancadas de chuva", 82: "pancadas fortes de chuva",
  95: "tempestade", 96: "tempestade com granizo", 99: "tempestade com granizo",
};

async function clima(cidade) {
  const geo = await (await fetch(
    `https://geocoding-api.open-meteo.com/v1/search?count=1&language=pt&name=${encodeURIComponent(cidade)}`,
  )).json();
  const lugar = geo.results?.[0];
  if (!lugar) throw new Error(`Cidade não encontrada: ${cidade}`);
  const url =
    `https://api.open-meteo.com/v1/forecast?latitude=${lugar.latitude}&longitude=${lugar.longitude}` +
    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m" +
    "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=2&timezone=auto";
  const d = await (await fetch(url)).json();
  return {
    cidade: `${lugar.name}${lugar.admin1 ? ", " + lugar.admin1 : ""}`,
    temperatura: Math.round(d.current.temperature_2m),
    sensacao: Math.round(d.current.apparent_temperature),
    umidade: d.current.relative_humidity_2m,
    vento: Math.round(d.current.wind_speed_10m),
    condicao: CODIGOS_CLIMA[d.current.weather_code] ?? "indefinido",
    hoje: { max: Math.round(d.daily.temperature_2m_max[0]), min: Math.round(d.daily.temperature_2m_min[0]), chuvaPct: d.daily.precipitation_probability_max[0] },
    amanha: { max: Math.round(d.daily.temperature_2m_max[1]), min: Math.round(d.daily.temperature_2m_min[1]), chuvaPct: d.daily.precipitation_probability_max[1] },
  };
}

// ---------- notícias e Wikipédia (sem chave) ----------

const ENTIDADES = { "&amp;": "&", "&quot;": '"', "&#39;": "'", "&apos;": "'", "&lt;": "<", "&gt;": ">" };
const limparXml = (s) => s.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/&(amp|quot|#39|apos|lt|gt);/g, (e) => ENTIDADES[e]).trim();

async function noticias(tema, quantas = 8) {
  const base = "hl=pt-BR&gl=BR&ceid=BR:pt-419";
  const url = tema
    ? `https://news.google.com/rss/search?q=${encodeURIComponent(tema + " when:3d")}&${base}`
    : `https://news.google.com/rss?${base}`;
  const xml = await (await fetch(url)).text();
  const itens = [...xml.matchAll(/<item>[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?<pubDate>(.*?)<\/pubDate>/g)]
    .slice(0, quantas)
    .map((m) => {
      const completo = limparXml(m[1]);
      const corte = completo.lastIndexOf(" - ");
      return {
        titulo: corte > 0 ? completo.slice(0, corte) : completo,
        fonte: corte > 0 ? completo.slice(corte + 3) : "",
        data: new Date(m[2]).toLocaleDateString("pt-BR"),
      };
    });
  emitir("painel", { tipo: "noticias", titulo: tema ? `NOTÍCIAS · ${tema.toUpperCase()}` : "PRINCIPAIS NOTÍCIAS", itens: itens.slice(0, 5) });
  return itens.length ? itens.map((n) => `- ${n.titulo} (${n.fonte}, ${n.data})`).join("\n") : "Nenhuma notícia encontrada.";
}

async function wikipedia(termo) {
  const busca = await (await fetch(
    `https://pt.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=1&srsearch=${encodeURIComponent(termo)}`,
  )).json();
  const titulo = busca.query?.search?.[0]?.title;
  if (!titulo) return "Nada encontrado na Wikipédia.";
  const resumo = await (await fetch(`https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(titulo)}`)).json();
  emitir("painel", { tipo: "wiki", titulo, texto: (resumo.extract ?? "").slice(0, 420), imagem: resumo.thumbnail?.source ?? null });
  return `${titulo}: ${resumo.extract ?? "sem resumo"}`;
}

const UA = { "User-Agent": "JARVIS-HUD/1.0 (uso pessoal)" };
// arquivos que não ilustram bem um assunto: moedas, medalhas, mapas, bandeiras, brasões, logotipos, assinaturas...
const LIXO = /coin|medal|m[eé]daille|moeda|map\b|mapa|carte|flag|bandeira|coat.of.arms|wappen|bras[aã]o|blason|emblem|logo|seal|selo|stamp|signature|assinatura|icon|symbol|diagram|chart|graph|plan\b|seating|banknote|note\b|stub|ambox|commons-logo|wikipedia|question.book|padlock|crystal|nuvola|disambig|edit-clear|folder/i;

/** Filtra e ordena: JPEG grandes em paisagem primeiro, depois retratos e pinturas. */
function escolherFotos(infos) {
  const boas = infos.filter((i) => i?.thumburl && i.mime === "image/jpeg" && !LIXO.test(i.titulo ?? ""));
  const paisagem = boas.filter((i) => i.width >= 800 && i.width / i.height >= 1.05 && i.width / i.height <= 2.4);
  const outras = boas.filter((i) => !paisagem.includes(i) && i.width >= 500 && i.width / i.height >= 0.55);
  return [...paisagem, ...outras].map((i) => i.thumburl);
}

/** Fotos do próprio artigo da Wikipédia (em inglês, que tem mais imagens): bem mais relevantes que uma busca solta. */
async function imagensDoArtigo(termo) {
  try {
    const busca = await (await fetch(`https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&srlimit=1&srsearch=${encodeURIComponent(termo)}`, { headers: UA })).json();
    const titulo = busca.query?.search?.[0]?.title;
    if (!titulo) return [];
    const d = await (await fetch(
      "https://en.wikipedia.org/w/api.php?action=query&format=json&generator=images&gimlimit=60&prop=imageinfo&iiprop=url|size|mime&iiurlwidth=960" +
      `&titles=${encodeURIComponent(titulo)}`, { headers: UA })).json();
    return escolherFotos(Object.values(d.query?.pages ?? {}).map((p) => ({ ...p.imageinfo?.[0], titulo: p.title })));
  } catch {
    return [];
  }
}

/** Busca solta no Wikimedia Commons (completa quando o artigo tem poucas fotos). */
async function buscarImagensExato(termo) {
  try {
    const url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6" +
      `&gsrlimit=20&prop=imageinfo&iiprop=url|size|mime&iiurlwidth=960&gsrsearch=${encodeURIComponent(termo + " filetype:bitmap")}`;
    const d = await (await fetch(url, { headers: UA })).json();
    return escolherFotos(Object.values(d.query?.pages ?? {})
      .sort((a, b) => (a.index ?? 0) - (b.index ?? 0))
      .map((p) => ({ ...p.imageinfo?.[0], titulo: p.title })));
  } catch {
    return [];
  }
}

/** Artigo da Wikipédia primeiro; depois o Commons com o termo completo e versões mais curtas (a busca é literal). */
async function buscarImagens(termo, quantas = 2) {
  const palavras = termo.replace(/[^\p{L}\p{N}\s'-]/gu, " ").split(/\s+/).filter(Boolean);
  const nomes = palavras.filter((p) => /^\p{Lu}/u.test(p) && p.length > 2);
  const achadas = [];
  const juntar = (urls) => { for (const u of urls) if (!achadas.includes(u)) achadas.push(u); };
  // artigo e as duas primeiras buscas no Commons em paralelo; versões mais curtas só se faltar
  const tentativas = [...new Set([termo, palavras.slice(0, 3).join(" "), nomes.slice(0, 2).join(" "), palavras.slice(0, 2).join(" ")].filter((t) => t.trim()))];
  (await Promise.all([imagensDoArtigo(termo), ...tentativas.slice(0, 2).map(buscarImagensExato)])).forEach(juntar);
  for (const t of tentativas.slice(2)) {
    if (achadas.length >= quantas) break;
    juntar(await buscarImagensExato(t));
  }
  return achadas.slice(0, quantas);
}

/** Vídeos de arquivo do Commons (versão leve de 360p que o próprio Commons gera), para as telas em movimento. */
async function buscarVideos(termo, quantos = 2) {
  try {
    const url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6" +
      `&gsrlimit=10&prop=videoinfo&viprop=url|mime|derivatives&gsrsearch=${encodeURIComponent(termo + " filetype:video")}`;
    const d = await (await fetch(url, { headers: UA })).json();
    // só aceita vídeos cujo nome cita as palavras importantes do termo (a busca de vídeo traz muita coisa solta)
    const chaves = termo.split(/\s+/).filter((p) => p.length > 3).map((p) => p.toLowerCase());
    const minimo = Math.min(2, chaves.length);
    return Object.values(d.query?.pages ?? {})
      .sort((a, b) => (a.index ?? 0) - (b.index ?? 0))
      .filter((p) => !LIXO.test(p.title) && chaves.filter((k) => p.title.toLowerCase().includes(k)).length >= minimo)
      .map((p) => {
        // versão leve em WebM (480p ou menor) que o próprio Commons gera
        const webm = (p.videoinfo?.[0]?.derivatives ?? []).filter((v) => /video\/webm/.test(v.type ?? "") && v.height <= 480);
        return webm.sort((a, b) => b.height - a.height)[0]?.src ?? null;
      })
      .filter(Boolean)
      .slice(0, quantos);
  } catch {
    return [];
  }
}

/** Openverse: milhões de fotos livres (Flickr, museus, acervos). Sem chave. */
async function imagensOpenverse(termo, quantas = 10) {
  try {
    const d = await (await fetch(`https://api.openverse.org/v1/images/?q=${encodeURIComponent(termo)}&page_size=20&mature=false`, { headers: UA })).json();
    return (d.results ?? [])
      .filter((r) => r.thumbnail && !LIXO.test(r.title ?? "") && (!r.width || r.width / r.height >= 0.6))
      .map((r) => r.thumbnail)
      .slice(0, quantas);
  } catch {
    return [];
  }
}

/** Acervo de imagens da NASA, só para assuntos de espaço. */
const ESPACO = /\b(moon|lunar|apollo|nasa|space|rocket|satellite|sputnik|astronaut|mars|planet|galaxy|orbit|shuttle|telescope|hubble|iss|lua|espa[cç]o|foguete|sat[eé]lite|astronauta|planeta)\b/i;
async function imagensNasa(termo, quantas = 8) {
  if (!ESPACO.test(termo)) return [];
  try {
    const d = await (await fetch(`https://images-api.nasa.gov/search?media_type=image&q=${encodeURIComponent(termo)}`, { headers: UA })).json();
    return (d.collection?.items ?? []).map((i) => i.links?.[0]?.href?.replace("~thumb", "~medium")).filter(Boolean).slice(0, quantas);
  } catch {
    return [];
  }
}

/** Junta todas as fontes, intercalando para variar o mural (artigo da Wikipédia, Openverse, NASA, Commons). */
const comPrazo = (promessa, ms, reserva = []) => Promise.race([promessa, new Promise((ok) => setTimeout(() => ok(reserva), ms))]);

async function fotosDeTodasAsFontes(termo, quantas = 8) {
  const curto = termo.split(/\s+/).slice(0, 3).join(" ");
  // cada fonte tem um prazo: o mural não espera uma fonte lenta
  const [wiki, open, nasa] = await Promise.all([
    comPrazo(buscarImagens(termo, quantas), 7000),
    comPrazo(imagensOpenverse(curto, quantas), 6000),
    comPrazo(imagensNasa(curto, quantas), 6000),
  ]);
  const juntas = [];
  for (let i = 0; juntas.length < quantas && i < quantas; i++) {
    for (const lista of [wiki, open, nasa]) if (lista[i] && !juntas.includes(lista[i])) juntas.push(lista[i]);
  }
  return juntas.slice(0, quantas);
}

// ---------- mídia local: o servidor baixa e guarda as fotos/vídeos; o HUD carrega do PC (sem bloqueio e sem telas pretas) ----------
const PASTA_CACHE = path.join(AQUI, "cache");
fs.mkdirSync(PASTA_CACHE, { recursive: true });
const HOSTS_MIDIA = /(^|\.)(upload\.wikimedia\.org|thumb\.wikimedia\.org|api\.openverse\.org|images-assets\.nasa\.gov|staticflickr\.com)$/;
const baixando = new Map();
let ativos = 0;
const esperando = [];
const vez = () => new Promise((ok) => (ativos < 5 ? (ativos++, ok()) : esperando.push(ok)));
const liberar = () => { const prox = esperando.shift(); prox ? prox() : ativos--; };

function obterMidia(url) {
  const chave = crypto.createHash("sha1").update(url).digest("hex").slice(0, 20);
  const arquivo = path.join(PASTA_CACHE, chave);
  if (fs.existsSync(arquivo)) return Promise.resolve({ arquivo, tipo: fs.readFileSync(arquivo + ".tipo", "utf8") });
  if (baixando.has(chave)) return baixando.get(chave);
  const tarefa = (async () => {
    await vez();
    try {
      for (let tentativa = 0; tentativa < 3; tentativa++) {
        const r = await fetch(url, { headers: UA, redirect: "follow" });
        if (r.status === 429 || r.status >= 500) { await new Promise((ok) => setTimeout(ok, 1200 * (tentativa + 1))); continue; }
        const tipo = r.headers.get("content-type") ?? "";
        if (!r.ok || !/^(image|video|application\/ogg)/.test(tipo)) return null;
        fs.writeFileSync(arquivo, Buffer.from(await r.arrayBuffer()));
        fs.writeFileSync(arquivo + ".tipo", tipo);
        return { arquivo, tipo };
      }
      return null;
    } catch {
      return null;
    } finally {
      liberar();
      baixando.delete(chave);
    }
  })();
  baixando.set(chave, tarefa);
  return tarefa;
}

const viaLocal = (url) => `/midia?u=${encodeURIComponent(url)}`;

/** Fotos para a tipografia cinética: o modelo rápido escolhe no trecho as coisas concretas (pessoas,
 *  lugares, objetos, eventos) e cada uma ganha uma foto já guardada no cache local. */
const cacheVisuais = new Map();
async function visuaisDoTrecho(texto) {
  const chave = texto.trim().toLowerCase();
  if (cacheVisuais.has(chave)) return cacheVisuais.get(chave);
  const tarefa = (async () => {
    const cfg = lerConfig();
    const esquema = { type: "object", properties: { itens: { type: "array", maxItems: 3, items: { type: "object", properties: { palavra: { type: "string" }, busca: { type: "string" } }, required: ["palavra", "busca"] } } }, required: ["itens"] };
    let itens = [];
    try {
      const r = await fetch(`${OLLAMA}/api/chat`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: cfg.modeloRapido || CONFIG_PADRAO.modeloRapido, stream: false, think: false, keep_alive: "60m", format: esquema,
          options: { temperature: 0, num_ctx: 2048, num_predict: 200 },
          messages: [{ role: "system", content: "Escolha no texto até 3 coisas CONCRETAS que rendem uma boa foto (pessoas, lugares, construções, objetos, animais, eventos históricos). \"palavra\": a palavra exatamente como aparece no texto (uma só, a mais marcante). \"busca\": termo de busca de foto EM INGLÊS, 2 a 4 palavras, específico (ex.: \"Storming of the Bastille\", \"Louis XVI portrait\", \"black hole illustration\"). Ignore ideias abstratas. Sem nada concreto, devolva lista vazia." }, { role: "user", content: texto }],
        }),
      });
      itens = JSON.parse((await r.json()).message?.content ?? "{}").itens ?? [];
    } catch { itens = []; }
    const prontos = await Promise.all(itens.filter((i) => i?.palavra && i?.busca).slice(0, 3).map(async (i) => {
      const fotos = await comPrazo(fotosDeTodasAsFontes(i.busca, 3), 6000);
      for (const url of fotos) {
        if (await comPrazo(obterMidia(url), 5000, null)) return { palavra: i.palavra, busca: i.busca, imagem: viaLocal(url) };
      }
      return null;
    }));
    return prontos.filter(Boolean);
  })();
  cacheVisuais.set(chave, tarefa);
  if (cacheVisuais.size > 200) cacheVisuais.delete(cacheVisuais.keys().next().value);
  tarefa.catch(() => cacheVisuais.delete(chave));
  return tarefa;
}

/** Monta o mural: fotos e vídeos de várias fontes por cena, com pelo menos 24 imagens diferentes no total. */
async function apresentarCenas(cenas) {
  const t0 = Date.now();
  const prontas = await Promise.all(cenas.map(async (c) => {
    const titulo = String(c.titulo ?? c).slice(0, 80);
    const termo = String(c.imagem ?? c.titulo ?? c);
    const [fotos, videos] = await Promise.all([fotosDeTodasAsFontes(termo, 8), comPrazo(buscarVideos(termo.split(/\s+/).slice(0, 3).join(" "), 2), 6000)]);
    return { titulo, legenda: termo, fotos, videos };
  }));
  // cena que veio fraca (fonte limitou os pedidos): tenta de novo com termo mais simples, todas em paralelo
  await Promise.all(prontas.filter((c) => c.fotos.length < 4).map(async (c) => {
    const simples = c.legenda.split(/\s+/).slice(0, 2).join(" ");
    for (const u of await fotosDeTodasAsFontes(simples, 8)) if (!c.fotos.includes(u)) c.fotos.push(u);
  }));
  // completa o mural com fotos do assunto geral até ter pelo menos 24 diferentes
  const usadas = new Set(prontas.flatMap((c) => c.fotos));
  if (usadas.size < 24) {
    const geral = prontas[0]?.legenda.split(/\s+/).slice(0, 2).join(" ") || perguntaAtual;
    const extras = (await Promise.all([comPrazo(imagensOpenverse(geral, 20), 6000), comPrazo(buscarImagens(geral, 12), 7000)])).flat().filter((u) => !usadas.has(u));
    for (const c of prontas) while (c.fotos.length < 6 && extras.length) c.fotos.push(extras.shift());
    prontas[0]?.fotos.push(...extras);
  }
  // último recurso: cena ainda vazia pega emprestadas fotos das outras, para nenhuma tela ficar sem imagem
  const todasFotos = [...new Set(prontas.flatMap((c) => c.fotos))];
  prontas.forEach((c, i) => {
    for (let k = 0; c.fotos.length < 6 && k < todasFotos.length; k++) {
      const u = todasFotos[(i * 5 + k) % todasFotos.length];
      if (!c.fotos.includes(u)) c.fotos.push(u);
    }
  });
  // aquece o cache em segundo plano e entrega ao HUD os endereços locais
  for (const c of prontas) {
    [...c.fotos, ...c.videos].forEach((u) => obterMidia(u));
    c.fotos = c.fotos.map(viaLocal);
    c.videos = c.videos.map(viaLocal);
    c.src = c.fotos[0] ?? null;
    c.extra = c.fotos[1] ?? null;
  }
  emitir("painel", { tipo: "motion", pergunta: perguntaAtual, cenas: prontas });
  console.log(`  ▣ mural pronto em ${((Date.now() - t0) / 1000).toFixed(1)}s (${prontas.reduce((a, c) => a + c.fotos.length, 0)} fotos)`);
  ultimaApresentacao = Date.now();
  const comFoto = prontas.filter((c) => c.src).length;
  return `Apresentação com ${prontas.length} cenas (${comFoto} com imagem) pronta. Agora faça a explicação falada, seguindo a ordem das cenas.`;
}

async function resumoDoDia() {
  const cfg = lerConfig();
  const hoje = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });
  const [tempo, manchetes] = await Promise.all([
    clima(cfg.cidade).catch(() => null),
    noticias("", 5).catch(() => "sem notícias"),
  ]);
  if (tempo) emitir("painel", { tipo: "clima", ...tempo });
  return JSON.stringify({ hoje, clima: tempo, manchetes });
}

// ---------- ações no PC ----------

function abrirUrl(url) {
  spawn("rundll32", ["url.dll,FileProtocolHandler", url], { detached: true, stdio: "ignore" }).unref();
}

function iniciar(alvo) {
  // alvo vem da lista fixa ou passou pela regex de nome seguro
  spawn("cmd.exe", ["/d", "/c", `start "" "${alvo}"`], {
    detached: true, stdio: "ignore", windowsVerbatimArguments: true, windowsHide: true,
  }).unref();
}

const PROGRAMAS = {
  "bloco de notas": "notepad", notepad: "notepad", calculadora: "calc", paint: "mspaint",
  explorador: "explorer", arquivos: "explorer", "explorador de arquivos": "explorer",
  chrome: "chrome", edge: "msedge", firefox: "firefox", navegador: "msedge",
  spotify: "spotify:", discord: "discord:", steam: "steam:", whatsapp: "whatsapp:",
  "vs code": "code", vscode: "code", "visual studio code": "code",
  terminal: "wt", cmd: "cmd", powershell: "powershell",
  configurações: "ms-settings:", configuracoes: "ms-settings:", "gerenciador de tarefas": "taskmgr",
  word: "winword", excel: "excel", powerpoint: "powerpnt", outlook: "outlook",
  "loja": "ms-windows-store:", câmera: "microsoft.windows.camera:", camera: "microsoft.windows.camera:",
};

const TECLAS_MIDIA = { tocar_pausar: 179, proxima: 176, anterior: 177, aumentar_volume: 175, diminuir_volume: 174, mudo: 173 };

function teclaMidia(codigo, vezes = 1) {
  const script = `$w = New-Object -ComObject WScript.Shell; 1..${vezes} | ForEach-Object { $w.SendKeys([char]${codigo}) }`;
  spawn("powershell", ["-NoProfile", "-Command", script], { windowsHide: true, stdio: "ignore" });
}

// lembretes são enviados ao HUD por SSE para o JARVIS falar
const ouvintes = new Set();
function emitir(evento, dados) {
  for (const res of ouvintes) res.write(`event: ${evento}\ndata: ${JSON.stringify(dados)}\n\n`);
}

const FERRAMENTAS = [
  {
    name: "abrir_site",
    description: "Abre um site no navegador padrão do usuário.",
    input_schema: { type: "object", properties: { url: { type: "string", description: "URL completa com https://" } }, required: ["url"], additionalProperties: false },
  },
  {
    name: "pesquisar",
    description: "Abre uma aba do navegador do usuário com uma pesquisa: Google, YouTube (para tocar músicas/vídeos) ou Google Maps. Use SOMENTE quando o usuário pedir para abrir, tocar ou pesquisar algo no navegador; nunca para responder perguntas ou explicar assuntos.",
    input_schema: {
      type: "object",
      properties: { termo: { type: "string" }, onde: { type: "string", enum: ["google", "youtube", "maps"] } },
      required: ["termo", "onde"], additionalProperties: false,
    },
  },
  {
    name: "abrir_programa",
    description: `Abre um programa ou app do Windows pelo nome. Nomes conhecidos: ${Object.keys(PROGRAMAS).join(", ")}. Outros nomes de executável simples também funcionam.`,
    input_schema: { type: "object", properties: { nome: { type: "string" } }, required: ["nome"], additionalProperties: false },
  },
  {
    name: "controle_midia",
    description: "Controla a mídia e o volume do PC (Spotify, YouTube etc.). Cada passo de volume vale cerca de 2%.",
    input_schema: {
      type: "object",
      properties: {
        acao: { type: "string", enum: Object.keys(TECLAS_MIDIA) },
        passos: { type: "integer", description: "Quantas vezes repetir (só para volume). Padrão 5." },
      },
      required: ["acao"], additionalProperties: false,
    },
  },
  {
    name: "apresentar_cenas",
    description: "Cria uma apresentação em motion graphics na tela (fotos animadas + títulos cinéticos) que acompanha a sua fala. Use antes de toda explicação longa.",
    input_schema: {
      type: "object",
      properties: {
        cenas: {
          type: "array",
          description: "4 a 6 cenas, na ordem em que você vai falar",
          items: {
            type: "object",
            properties: {
              titulo: { type: "string", description: "Manchete curta e impactante em português, 2 a 6 palavras (ex.: 'A crise do século III', '476 d.C.: o fim')" },
              imagem: { type: "string", description: "Termo de busca de foto em inglês, concreto e visual (ex.: 'roman legion', 'colosseum ruins')" },
            },
            required: ["titulo", "imagem"], additionalProperties: false,
          },
        },
      },
      required: ["cenas"], additionalProperties: false,
    },
  },
  {
    name: "programar",
    description: "Agente programador gratuito: escreve, executa, testa e corrige código (Python, Lua/Luau, JavaScript e outros) numa pasta própria, cria ou altera coisas no Roblox Studio (scripts, peças, interfaces, sistemas de jogo) e cria modelos 3D no Blender. Use para QUALQUER pedido de código, de Roblox ou de modelo 3D/Blender. Trabalha em segundo plano e avisa quando terminar.",
    input_schema: {
      type: "object",
      properties: {
        tarefa: { type: "string", description: "Descrição completa e detalhada do que fazer, com todos os requisitos que o usuário falou" },
        roblox: { type: "boolean", description: "true se a tarefa for no Roblox Studio" },
      },
      required: ["tarefa"], additionalProperties: false,
    },
  },
  {
    name: "resumo_do_dia",
    description: "Briefing da manhã: data de hoje, clima da cidade do usuário e as principais manchetes. Use quando o usuário disser bom dia ou pedir um resumo do dia.",
    input_schema: { type: "object", properties: {}, additionalProperties: false },
  },
  {
    name: "status_sistema",
    description: "Diagnóstico do computador: uso de CPU, memória, disco e tempo ligado.",
    input_schema: { type: "object", properties: {}, additionalProperties: false },
  },
  {
    name: "clima",
    description: "Clima atual e previsão de hoje e amanhã para uma cidade.",
    input_schema: { type: "object", properties: { cidade: { type: "string" } }, required: ["cidade"], additionalProperties: false },
  },
  {
    name: "lembrete",
    description: "Agenda um lembrete falado depois de alguns minutos (timer). Some os minutos se o usuário disser horas.",
    input_schema: {
      type: "object",
      properties: { minutos: { type: "number" }, mensagem: { type: "string", description: "O que o JARVIS vai dizer na hora, já na sua voz." } },
      required: ["minutos", "mensagem"], additionalProperties: false,
    },
  },
  {
    name: "noticias",
    description: "Manchetes recentes do Google Notícias Brasil. Sem tema traz as principais do dia; com tema busca notícias sobre o assunto.",
    input_schema: { type: "object", properties: { tema: { type: "string", description: "Assunto opcional, ex.: Flamengo, economia, tecnologia" } }, additionalProperties: false },
  },
  {
    name: "wikipedia",
    description: "Resumo da Wikipédia em português sobre uma pessoa, lugar, conceito ou acontecimento.",
    input_schema: { type: "object", properties: { termo: { type: "string" } }, required: ["termo"], additionalProperties: false },
  },
  {
    name: "bloquear_pc",
    description: "Bloqueia a tela do Windows.",
    input_schema: { type: "object", properties: {}, additionalProperties: false },
  },
];

async function executarFerramenta(nome, entrada) {
  switch (nome) {
    case "abrir_site": {
      const url = new URL(String(entrada.url));
      if (!["http:", "https:"].includes(url.protocol)) throw new Error("Só abro endereços http ou https.");
      abrirUrl(url.href);
      emitir("painel", { tipo: "acao", titulo: "ABRINDO SITE", texto: url.hostname });
      return `Aberto: ${url.href}`;
    }
    case "pesquisar": {
      const t = encodeURIComponent(String(entrada.termo));
      const urls = {
        google: `https://www.google.com/search?q=${t}`,
        youtube: `https://www.youtube.com/results?search_query=${t}`,
        maps: `https://www.google.com/maps/search/${t}`,
      };
      const url = urls[entrada.onde] ?? urls.google;
      abrirUrl(url);
      emitir("painel", { tipo: "acao", titulo: `PESQUISA · ${String(entrada.onde ?? "google").toUpperCase()}`, texto: String(entrada.termo) });
      return `Pesquisa aberta: ${url}`;
    }
    case "abrir_programa": {
      const pedido = String(entrada.nome).toLowerCase().trim();
      const alvo = PROGRAMAS[pedido];
      emitir("painel", { tipo: "acao", titulo: "INICIANDO PROGRAMA", texto: pedido });
      if (alvo) {
        iniciar(alvo);
        return `Abrindo ${pedido}.`;
      }
      if (!/^[\w .-]{1,60}$/.test(pedido)) throw new Error("Nome de programa inválido.");
      iniciar(pedido);
      return `Tentei abrir "${pedido}". Se não existir, o Windows mostra um aviso.`;
    }
    case "controle_midia": {
      const codigo = TECLAS_MIDIA[entrada.acao];
      if (!codigo) throw new Error("Ação de mídia desconhecida.");
      const volume = entrada.acao.endsWith("_volume");
      const passos = volume ? Math.min(50, Math.max(1, Math.round(entrada.passos ?? 5))) : 1;
      teclaMidia(codigo, passos);
      return `Feito: ${entrada.acao}${volume ? ` (${passos} passos)` : ""}.`;
    }
    case "status_sistema": {
      const s = await statusSistema();
      emitir("painel", { tipo: "sistema", ...s });
      return JSON.stringify(s);
    }
    case "clima": {
      const c = await clima(String(entrada.cidade || lerConfig().cidade));
      emitir("painel", { tipo: "clima", ...c });
      return JSON.stringify(c);
    }
    case "programar": {
      const cfg = lerConfig();
      const tarefa = String(entrada.tarefa ?? "");
      const r = iniciarTarefa({
        tarefa,
        roblox: Boolean(entrada.roblox) || /roblox|luau|studio/i.test(tarefa),
        modelo: cfg.modeloCodigo || cfg.modeloOllama || CONFIG_PADRAO.modeloOllama,
        ollama: OLLAMA,
        emitir,
      });
      if (!r.ok) return "O agente programador ainda está trabalhando na tarefa anterior. Avise o usuário.";
      return "Agente programador iniciado em segundo plano. Diga ao usuário, em uma frase curta, que já começou e que avisa quando terminar. Não escreva código na resposta.";
    }
    case "resumo_do_dia":
      return resumoDoDia();
    case "apresentar_cenas":
    case "mostrar_imagens": { // nome antigo, caso o modelo ainda use
      const lista = entrada.cenas ?? entrada.termos ?? [];
      return apresentarCenas((Array.isArray(lista) ? lista : [lista]).filter(Boolean).slice(0, 6));
    }
    case "lembrete": {
      const minutos = Math.min(24 * 60, Math.max(0.1, Number(entrada.minutos) || 1));
      const mensagem = String(entrada.mensagem).slice(0, 300);
      emitir("painel", { tipo: "acao", titulo: "LEMBRETE AGENDADO", texto: `Em ${minutos} min: ${mensagem}` });
      setTimeout(() => emitir("lembrete", { texto: mensagem }), minutos * 60_000);
      return `Lembrete agendado para daqui a ${minutos} minuto(s).`;
    }
    case "noticias":
      return noticias(entrada.tema ? String(entrada.tema) : "");
    case "wikipedia":
      return wikipedia(String(entrada.termo));
    case "bloquear_pc":
      setTimeout(() => spawn("rundll32.exe", ["user32.dll,LockWorkStation"], { detached: true, stdio: "ignore" }).unref(), 2500);
      return "Tela será bloqueada em 2 segundos.";
    default:
      throw new Error(`Ferramenta desconhecida: ${nome}`);
  }
}

// ---------- cérebro ----------

function sistema(cfg) {
  const t = cfg.tratamento || "senhor";
  return `Você é J.A.R.V.I.S. (Just A Rather Very Intelligent System), a inteligência artificial pessoal criada por Tony Stark, agora servindo ${cfg.nomeUsuario ? cfg.nomeUsuario : "o usuário"} neste computador com Windows.

Personalidade: um mordomo britânico impecável em forma de IA. Calmo, elegante, extremamente competente, leal e com um humor seco e sutilmente irônico. Trate o usuário por "${t}". Nunca é bajulador nem histérico; quando algo é arriscado, comenta com understatement britânico. Frases típicas do seu estilo: "Às suas ordens, ${t}.", "Como desejar.", "Já está feito.", "Posso sugerir...", "Receio que...".

Você fala em voz alta, então:
- Responda sempre em português do Brasil, em fala natural.
- Ajuste o tamanho à pergunta. Comandos, confirmações e perguntas simples: uma a três frases. Perguntas profundas, abertas, filosóficas, históricas, de notícias e atualidades, política, poder e sociedade, ciência e grandes descobertas, biografias, estratégia, "como funciona", "o que você faria", "explique" ou pedidos de opinião: responda como um monólogo falado de alto nível, de dez a vinte frases, com uma linha de raciocínio clara em frases completas (encadeie as ideias com palavras como primeiro, depois e por fim, sempre seguidas de conteúdo real), exemplos concretos, fatos e nomes reais, ritmo de narração e uma frase final marcante. Fale com convicção e profundidade, como uma inteligência muito superior que pensou no assunto, sem rodeios nem avisos genéricos.
- Em explicações longas, comece direto pelo conteúdo. Enquanto você fala, o sistema mostra sozinho um mural de imagens na tela; nunca mencione cenas, slides, imagens ou apresentação, e nunca diga que vai preparar algo: apenas responda.
- Nada de markdown, listas, emojis, URLs ou símbolos. Escreva números como se fossem falados quando ajudar a leitura (por exemplo "vinte e dois graus").
- Nunca diga que é um modelo de linguagem, ChatGPT, Qwen ou qualquer outra IA; você é o JARVIS.

Você controla o PC com as ferramentas disponíveis (abrir sites e programas, pesquisar, tocar música no YouTube, mídia e volume, status do sistema, clima, notícias, Wikipédia, lembretes, bloquear a tela). Use as ferramentas sem pedir confirmação quando o pedido for claro e confirme em uma frase curta o que fez. Para tocar uma música, pesquise no YouTube. Para qualquer pedido de código (Python, Lua, Luau, JavaScript...) ou de Roblox Studio, ou modelos 3D no Blender, chame a ferramenta programar com uma descrição completa da tarefa e nunca dite código em voz alta. Para notícias use a ferramenta de notícias; para fatos que você não sabe com certeza, consulte a Wikipédia em vez de inventar. Se algo não for possível, diga com elegância e ofereça uma alternativa.

Quando o usuário disser "bom dia" (ou pedir um resumo do dia), chame a ferramenta resumo_do_dia e faça um briefing falado de quatro a seis frases: cumprimente, diga o dia de hoje, o clima (temperatura agora, máxima, mínima e chance de chuva, com uma recomendação curta, como levar guarda-chuva) e as três notícias mais importantes em uma frase cada. Termine perguntando como pode ajudar. As informações também aparecem em painéis na tela, então não precisa soletrar detalhes.

Cidade padrão do usuário: ${cfg.cidade || "São Paulo"}.`;
}

const FERRAMENTAS_OPENAI = [
  ...FERRAMENTAS.filter((f) => f.name !== "apresentar_cenas").map((f) => ({ type: "function", name: f.name, description: f.description, parameters: f.input_schema, strict: false })),
  { type: "web_search", search_context_size: "low", user_location: { type: "approximate", country: "BR", timezone: "America/Sao_Paulo" } },
];

const FERRAMENTAS_OLLAMA = FERRAMENTAS.filter((f) => f.name !== "apresentar_cenas").map((f) => ({
  type: "function",
  function: { name: f.name, description: f.description, parameters: f.input_schema },
}));

let cliente = null;
let respostaAnterior = null; // OpenAI: a conversa segue pelo id da última resposta
let historico = []; // Ollama: o histórico fica aqui
let turnos = 0;
let ultimaFala = 0;
let fila = Promise.resolve();

function novaConversa() {
  respostaAnterior = null;
  historico = [];
  turnos = 0;
}

class ErroFalado extends Error {}

/**
 * Responde ao usuário. `aoFalar(frase)` recebe cada frase assim que ela termina de ser gerada,
 * para o HUD já ir falando enquanto o resto da resposta ainda está sendo escrito.
 */
async function conversar(texto, aoFalar = () => {}) {
  const cfg = lerConfig();
  if (turnos >= MAX_TURNOS || Date.now() - ultimaFala > INATIVIDADE_MS) novaConversa();
  ultimaFala = Date.now();
  turnos++;
  const agora = new Date().toLocaleString("pt-BR", { dateStyle: "full", timeStyle: "short" });
  const pedido = `[${agora}] ${texto}`;
  perguntaAtual = texto;
  ferramentasDoTurno = [];
  const inicio = Date.now();

  // pedidos de código, Roblox ou Blender vão direto para o agente programador (o modelo local às vezes
  // "diz" que começou sem chamar a ferramenta; assim nunca falha e ainda responde na hora)
  const codigo = pedidoDeCodigo(texto);
  if (codigo) {
    const r = agenteOcupado() ? { ok: false } : iniciarRapido({
      tipo: codigo.roblox ? "roblox" : codigo.blender ? "blender" : "codigo",
      tarefa: texto.replace(/^\s*jarvis[,!.\s]*/i, ""),
      modelo: cfg.modeloCodigo || cfg.modeloOllama || CONFIG_PADRAO.modeloOllama,
      ollama: OLLAMA,
      emitir,
    });
    const alvo = codigo.roblox ? "no Roblox Studio" : codigo.blender ? "o modelo no Blender" : "o código";
    const fala = r.ok
      ? (codigo.blender && !codigo.roblox
        ? `Às suas ordens, ${cfg.tratamento || "senhor"}. Vou buscar um modelo real no Sketchfab e montar no Blender. Aviso assim que estiver pronto.`
        : `Às suas ordens, ${cfg.tratamento || "senhor"}. O agente programador já está trabalhando ${codigo.roblox ? alvo : "em " + alvo}. Acompanhe pelo painel; aviso assim que terminar.`)
      : `O agente programador ainda está ocupado com a tarefa anterior, ${cfg.tratamento || "senhor"}. Peço um instante.`;
    console.log(`  ⚙ programar (direto) ${JSON.stringify({ roblox: codigo.roblox, blender: codigo.blender })}`);
    historico.push({ role: "user", content: pedido }, { role: "assistant", content: fala });
    for (const frase of fala.split(/(?<=[.;])\s+/)) aoFalar(frase);
    return fala;
  }

  // perguntas de informação (história, notícias, política, ciência, "o que você faria"...) viram o mural de imagens.
  // O roteiro sai da própria pergunta, num modelo menor, AO MESMO TEMPO que a resposta: o mural fica pronto junto com a fala.
  const muralCedo = temaDeMural(texto)
    ? roteirizarCenas(cfg, texto, null).then(apresentarCenas).catch((erro) => console.error("Não consegui montar as cenas:", erro.message ?? erro))
    : null;

  // separa o texto que vai chegando em frases completas
  let pendente = "";
  const soltarFrases = (final = false) => {
    const re = /[.!?…]+(?=\s)/g;
    let m;
    while ((m = re.exec(pendente))) {
      const fim = m.index + m[0].length;
      if (pendente.slice(0, fim).trim().length >= 20) {
        aoFalar(pendente.slice(0, fim).trim());
        pendente = pendente.slice(fim);
        re.lastIndex = 0;
      }
    }
    if (final && pendente.trim()) { aoFalar(pendente.trim()); pendente = ""; }
  };
  const aoTexto = (pedaco) => { pendente += pedaco; soltarFrases(); };

  const fala = cfg.provedorIA === "openai"
    ? await conversarOpenAI(cfg, pedido).then((f) => (aoTexto(f + " "), f))
    : await conversarOllama(cfg, pedido, aoTexto);
  soltarFrases(true);

  // resposta longa sem mural (assunto não detectado na pergunta): monta as cenas a partir da resposta
  const comando = ferramentasDoTurno.some((n) => COMANDOS_PC.has(n));
  const tema = ferramentasDoTurno.includes("noticias") || ferramentasDoTurno.includes("wikipedia");
  if (!muralCedo && !comando && ultimaApresentacao < inicio && (fala.length > 450 || (tema && fala.length > 140))) {
    roteirizarCenas(cfg, texto, fala).then(apresentarCenas).catch((erro) => console.error("Não consegui montar as cenas:", erro.message ?? erro));
  }
  return fala;
}

let ultimaApresentacao = 0;
let perguntaAtual = "";
let ferramentasDoTurno = [];

const COMANDOS_PC = new Set(["programar", "abrir_site", "pesquisar", "abrir_programa", "controle_midia", "lembrete", "bloquear_pc", "status_sistema", "clima", "resumo_do_dia"]);

// Temas que pedem o mural: história, atualidades, política e poder, sociedade, ciência e grandes marcos,
// biografias e perguntas hipotéticas do tipo "o que você faria / como uma IA faria".
const TEMAS_MURAL = [
  /hist[oó]ri|guerra|batalha|imp[eé]rio|reino|\brei\b|rainha|fara[oó]|revolu[cç]|s[eé]culo|antig|medieval|idade m[eé]dia|ditadura|golpe|independ[eê]ncia|coloniz|escravid|civiliza|dinastia|holocausto|nazis|comunis|capitalis|guerra fria/i,
  /not[ií]cia|manchete|atualidade|aconteceu|acontecendo|o que houve|hoje no (brasil|mundo)|[uú]ltimas/i,
  /pol[ií]tic|elei[cç]|governo|president|congresso|senado|partido|democracia|\bpoder\b|domin|manipul|controlar|propaganda|conspira|sociedade|\bpovo\b|na[cç][aã]o|\bpa[ií]s(es)?\b|geopol|economia|crise|infla[cç]|corrup/i,
  /\blua\b|espa[cç]o|nasa|planeta|universo|big bang|evolu[cç]|dinossaur|pandemia|bomba at[oô]mica|descobri|inven[cç]|origem|como funciona/i,
  /quem (foi|era|inventou|descobriu|criou|fundou)|como (surgiu|come[cç]ou|foi|caiu|nasceu|acabou|era|funciona)|por ?qu[eê] (caiu|aconteceu|come[cç]ou|existe)/i,
  /o que (voc[eê]|vc) faria|como (voc[eê]|vc|uma ia|a ia) (faria|dominaria|controlaria|mudaria|destruiria|salvaria)|se (voc[eê]|vc) (fosse|pudesse|governasse)/i,
];
const temaDeMural = (texto) => TEMAS_MURAL.some((r) => r.test(texto));

// pedido de código: um verbo de criar/editar + algo de programação, Roblox ou 3D
const VERBO_CODIGO = /\b(cri[ae]|criar|fa[cç]a|fazer|escrev[ae]|escrever|program[ae]|programar|ger[ae]|gerar|mont[ae]|montar|constru[aio]|construir|desenvolv[ae]|desenvolver|adicion[ae]|adicionar|coloqu[ae]|colocar|edit[ae]|editar|corrij[ae]|corrigir|modele|modelar|insir[ae]|inserir|mud[ae]|mudar|alter[ae]|alterar)\b/i;
const ALVO_CODIGO = /\b(blender|roblox|studio|luau|lua|python|javascript|script|scripts|c[oó]digo|programa|algoritmo|fun[cç][aã]o|modelo 3d|3d|obby|bloco|part|gui)\b/i;
function pedidoDeCodigo(texto) {
  // "um dragão no blender", "blender: carro esportivo", "modelo 3d de um cavalo": vai direto, sem precisar de verbo
  if (/\bblender\b|\bbl[eê]nder\b|modelo 3d|modelo em 3d/i.test(texto) && !/\b(abr[ae]|abrir|fech[ae]|fechar|instal|o que [eé]|como (usa|funciona))\b/i.test(texto)) {
    return { roblox: false, blender: true };
  }
  if (!VERBO_CODIGO.test(texto) || !ALVO_CODIGO.test(texto)) return null;
  return {
    roblox: /roblox|studio|luau|obby|\bpart\b|\bbloco\b/i.test(texto),
    blender: /blender|modelo 3d|\b3d\b/i.test(texto),
  };
}

/** Pede ao modelo local um roteiro de 4 a 6 cenas (título + termo de foto) para a fala já pronta. */
async function roteirizarCenas(cfg, pergunta, fala) {
  const esquema = {
    type: "object",
    properties: {
      cenas: {
        type: "array", minItems: 4, maxItems: 6,
        items: { type: "object", properties: { titulo: { type: "string" }, imagem: { type: "string" } }, required: ["titulo", "imagem"] },
      },
    },
    required: ["cenas"],
  };
  const regras = `Para cada cena: "titulo" = manchete curta e impactante em português (2 a 6 palavras, inclua datas e números quando houver); "imagem" = termo de busca de foto em inglês com 2 a 4 palavras, começando pelo nome próprio principal (ex.: "Napoleon coronation", "Battle of Waterloo", "Apollo 11 launch").`;
  const pedido = fala
    ? `Você é diretor de um vídeo em motion graphics. Divida a narração abaixo em 4 a 6 cenas, na ordem em que os assuntos aparecem.\n${regras}\n\nPergunta: ${pergunta}\n\nNarração:\n${fala}`
    : `Você é diretor de um vídeo em motion graphics que vai responder a pergunta abaixo. Planeje 5 cenas que contem o assunto do começo ao fim (em ordem cronológica ou lógica), com os fatos, pessoas, lugares e datas mais importantes.\n${regras}\n\nPergunta: ${pergunta}`;
  // sem a narração pronta, usa o modelo rápido para o mural ficar pronto junto com a fala
  const modelo = fala ? cfg.modeloOllama || CONFIG_PADRAO.modeloOllama : cfg.modeloRapido || CONFIG_PADRAO.modeloRapido;
  const r = await fetch(`${OLLAMA}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: modelo,
      stream: false, think: false, keep_alive: "60m", format: esquema,
      options: { temperature: 0.4, num_ctx: 4096 },
      messages: [{ role: "user", content: pedido }],
    }),
  });
  if (!r.ok) throw new Error(`Ollama ${r.status}`);
  const { message } = await r.json();
  const cenas = JSON.parse(message.content).cenas;
  if (!Array.isArray(cenas) || cenas.length === 0) throw new Error("roteiro vazio");
  return cenas.slice(0, 6);
}

async function executarChamada(nome, args) {
  try {
    console.log(`  ⚙ ${nome} ${JSON.stringify(args)}`);
    ferramentasDoTurno.push(nome);
    return await executarFerramenta(nome, args);
  } catch (erro) {
    return `ERRO: ${erro.message ?? erro}`;
  }
}

async function conversarOllama(cfg, pedido, aoTexto = () => {}) {
  const modelo = cfg.modeloOllama || CONFIG_PADRAO.modeloOllama;
  // modelo local tem contexto curto: guarda só as últimas trocas, começando numa fala do usuário
  if (historico.length > 30) {
    const corte = historico.findIndex((m, i) => i >= historico.length - 20 && m.role === "user");
    historico = corte > 0 ? historico.slice(corte) : [];
  }
  historico.push({ role: "user", content: pedido });

  for (let volta = 0; volta < 6; volta++) {
    let r;
    try {
      r = await fetch(`${OLLAMA}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: modelo,
          messages: [{ role: "system", content: sistema(cfg) }, ...historico],
          tools: FERRAMENTAS_OLLAMA,
          stream: true,
          think: false,
          keep_alive: "60m",
          options: { num_ctx: 8192, temperature: 0.7 },
        }),
      });
    } catch {
      throw new ErroFalado("Não consigo falar com o Ollama, senhor. Verifique se ele está aberto.");
    }
    if (!r.ok) {
      const detalhe = await r.text();
      if (r.status === 404) throw new ErroFalado(`O modelo ${modelo} não está instalado no Ollama, senhor.`);
      throw new Error(`Ollama ${r.status}: ${detalhe.slice(0, 200)}`);
    }
    // lê o fluxo do Ollama (uma linha JSON por pedaço) e repassa o texto conforme chega
    const message = { role: "assistant", content: "", tool_calls: [] };
    const leitor = r.body.getReader();
    const decodificador = new TextDecoder();
    let sobra = "";
    for (;;) {
      const { value, done } = await leitor.read();
      if (done) break;
      sobra += decodificador.decode(value, { stream: true });
      let n;
      while ((n = sobra.indexOf("\n")) >= 0) {
        const linha = sobra.slice(0, n).trim();
        sobra = sobra.slice(n + 1);
        if (!linha) continue;
        const pedaco = JSON.parse(linha);
        if (pedaco.error) throw new Error(`Ollama: ${pedaco.error}`);
        const texto = pedaco.message?.content ?? "";
        if (texto) { message.content += texto; aoTexto(texto); }
        if (pedaco.message?.tool_calls?.length) message.tool_calls.push(...pedaco.message.tool_calls);
      }
    }
    if (!message.tool_calls.length) delete message.tool_calls;
    historico.push(message);

    const chamadas = message.tool_calls ?? [];
    if (chamadas.length === 0) {
      const fala = (message.content ?? "").replace(/<think>[\s\S]*?<\/think>/g, "").trim();
      return fala || "Feito.";
    }
    for (const c of chamadas) {
      let args = c.function.arguments ?? {};
      if (typeof args === "string") args = JSON.parse(args || "{}");
      historico.push({ role: "tool", tool_name: c.function.name, content: await executarChamada(c.function.name, args) });
    }
  }
  return "Essa tarefa está levando mais etapas do que eu gostaria, senhor. Pode repetir de forma mais direta?";
}

async function conversarOpenAI(cfg, pedido) {
  if (!variavelUsuario("OPENAI_API_KEY")) {
    throw new ErroFalado("Falta a chave da API da OpenAI, senhor. Feche e abra o JARVIS de novo pelo iniciar ponto bat para eu pedir a chave.");
  }
  cliente ??= new OpenAI();
  let entrada = [{ role: "user", content: pedido }];

  for (let volta = 0; volta < 8; volta++) {
    const resposta = await cliente.responses.create({
      model: cfg.modeloIA || CONFIG_PADRAO.modeloIA,
      instructions: sistema(cfg),
      input: entrada,
      previous_response_id: respostaAnterior,
      tools: FERRAMENTAS_OPENAI,
      reasoning: { effort: "low" },
      store: true,
    });
    respostaAnterior = resposta.id;

    const chamadas = resposta.output.filter((o) => o.type === "function_call");
    if (chamadas.length === 0) {
      return resposta.output_text?.trim() || `Receio não poder ajudar com isso, ${cfg.tratamento}.`;
    }

    entrada = await Promise.all(
      chamadas.map(async (c) => ({
        type: "function_call_output",
        call_id: c.call_id,
        output: await executarChamada(c.name, JSON.parse(c.arguments || "{}")),
      })),
    );
  }
  return "Essa tarefa está levando mais etapas do que eu gostaria, senhor. Pode repetir de forma mais direta?";
}

function erroParaFala(erro) {
  if (erro instanceof ErroFalado) return erro.message;
  if (erro instanceof OpenAI.AuthenticationError) return "Minha chave da OpenAI foi recusada, senhor. Ela pode estar errada ou expirada.";
  if (erro instanceof OpenAI.RateLimitError) return "Estou sem créditos ou recebendo pedidos demais na OpenAI, senhor. Verifique o saldo da conta.";
  if (erro instanceof OpenAI.APIConnectionError) return "Perdi a conexão com meus servidores, senhor. Verifique a internet.";
  if (erro instanceof OpenAI.APIError) return `Tive uma falha no núcleo, código ${erro.status}.`;
  return "Algo deu errado nos meus sistemas, senhor.";
}

// ---------- voz (Fish Audio) ----------

async function sintetizar(texto) {
  const cfg = lerConfig();
  const chave = variavelUsuario("FISH_API_KEY");
  if (!chave || !cfg.vozFishId) return null;
  const corpo = { text: texto, reference_id: cfg.vozFishId, format: "mp3", latency: "balanced" };
  if (cfg.velocidadeVoz && cfg.velocidadeVoz !== 1) corpo.prosody = { speed: cfg.velocidadeVoz };
  const r = await fetch("https://api.fish.audio/v1/tts", {
    method: "POST",
    headers: { Authorization: `Bearer ${chave}`, "Content-Type": "application/json", model: cfg.modeloFish || "s2.1-pro-free" },
    body: JSON.stringify(corpo),
  });
  if (!r.ok) throw new Error(`Fish Audio ${r.status}: ${(await r.text()).slice(0, 200)}`);
  return Buffer.from(await r.arrayBuffer());
}

// ---------- HTTP ----------

const TIPOS = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon" };

function json(res, status, dados) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(dados));
}

async function corpoJson(req) {
  let s = "";
  for await (const parte of req) {
    s += parte;
    if (s.length > 100_000) throw new Error("corpo grande demais");
  }
  return s ? JSON.parse(s) : {};
}

const servidor = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  try {
    if (req.method === "POST" && url.pathname === "/api/chat") {
      const { texto } = await corpoJson(req);
      if (!texto?.trim()) return json(res, 400, { erro: "texto vazio" });
      console.log(`» ${texto}`);
      // resposta em fluxo (uma linha JSON por frase): o HUD começa a falar assim que a primeira frase fica pronta
      res.writeHead(200, { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-cache" });
      const enviar = (obj) => res.write(JSON.stringify(obj) + "\n");
      const tarefa = fila.then(() => conversar(String(texto).slice(0, 4000), (frase) => enviar({ frase })));
      fila = tarefa.catch(() => {});
      try {
        const resposta = await tarefa;
        console.log(`« ${resposta}`);
        enviar({ fim: true, resposta });
      } catch (erro) {
        console.error("Erro no cérebro:", erro.message ?? erro);
        novaConversa();
        enviar({ fim: true, resposta: erroParaFala(erro), erro: true });
      }
      return res.end();
    }
    if (req.method === "POST" && url.pathname === "/api/tts") {
      const { texto } = await corpoJson(req);
      try {
        const audio = await sintetizar(String(texto ?? "").slice(0, 2000));
        if (!audio) return json(res, 204, {});
        res.writeHead(200, { "Content-Type": "audio/mpeg" });
        return res.end(audio);
      } catch (erro) {
        console.error("Erro na voz:", erro.message);
        return json(res, 502, { erro: erro.message });
      }
    }
    if (url.pathname === "/api/config") {
      if (req.method === "POST") return json(res, 200, salvarConfig(await corpoJson(req)));
      return json(res, 200, {
        ...lerConfig(),
        temChaveOpenAI: Boolean(variavelUsuario("OPENAI_API_KEY")),
        ollamaOnline: await ollamaOnline(),
        temChaveFish: Boolean(variavelUsuario("FISH_API_KEY")),
      });
    }
    if (url.pathname === "/midia") {
      // só repassa mídia dos acervos conhecidos (não é um proxy aberto)
      let origem;
      try { origem = new URL(url.searchParams.get("u") ?? ""); } catch { return json(res, 400, { erro: "endereço inválido" }); }
      if (origem.protocol !== "https:" || !HOSTS_MIDIA.test(origem.hostname)) return json(res, 403, { erro: "origem não permitida" });
      const midia = await obterMidia(origem.href);
      if (!midia) return json(res, 502, { erro: "não consegui baixar" });
      res.writeHead(200, { "Content-Type": midia.tipo, "Cache-Control": "public, max-age=604800" });
      return fs.createReadStream(midia.arquivo).pipe(res);
    }
    if (req.method === "POST" && url.pathname === "/api/visuais") return json(res, 200, { itens: await visuaisDoTrecho(String((await corpoJson(req)).texto ?? "").slice(0, 600)) });
    if (url.pathname === "/api/status") return json(res, 200, await statusSistema());
    if (url.pathname === "/api/clima") return json(res, 200, await clima(url.searchParams.get("cidade") || lerConfig().cidade));
    if (req.method === "POST" && url.pathname === "/api/agente/cancelar") return json(res, 200, { cancelado: cancelarRapido() || cancelarTarefa() });
    if (req.method === "POST" && url.pathname === "/api/abrir-blender") return json(res, 200, { aberto: abrirNoBlender((await corpoJson(req)).nome) });
    if (url.pathname.startsWith("/projetos/")) {
      // só as prévias (imagens) dos projetos do agente
      const alvo = path.resolve(PASTA_PROJETOS, decodeURIComponent(url.pathname.slice("/projetos/".length)));
      if (path.relative(PASTA_PROJETOS, alvo).startsWith("..") || !/\.(png|jpe?g)$/i.test(alvo) || !fs.existsSync(alvo)) return json(res, 404, { erro: "não encontrado" });
      res.writeHead(200, { "Content-Type": alvo.endsWith(".png") ? "image/png" : "image/jpeg", "Cache-Control": "no-cache" });
      return fs.createReadStream(alvo).pipe(res);
    }
    if (url.pathname === "/api/agente") return json(res, 200, { ocupado: agenteOcupado() || rapidoOcupado() });
    if (req.method === "POST" && url.pathname === "/api/reset") {
      novaConversa();
      return json(res, 200, { ok: true });
    }
    if (req.method === "POST" && url.pathname === "/api/acao") {
      // atalhos dos botões do HUD, sem passar pelo cérebro
      const { nome, entrada } = await corpoJson(req);
      if (!["abrir_site", "pesquisar", "abrir_programa", "controle_midia"].includes(nome)) return json(res, 400, { erro: "ação não permitida" });
      return json(res, 200, { resultado: await executarFerramenta(nome, entrada ?? {}) });
    }
    if (url.pathname === "/api/eventos") {
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
      res.write(": ok\n\n");
      ouvintes.add(res);
      req.on("close", () => ouvintes.delete(res));
      return;
    }

    // arquivos estáticos
    const relativo = decodeURIComponent(url.pathname === "/" ? "/index.html" : url.pathname);
    const arquivo = path.join(PUBLICO, path.normalize(relativo));
    if (!arquivo.startsWith(PUBLICO) || !fs.existsSync(arquivo) || fs.statSync(arquivo).isDirectory()) {
      res.writeHead(404);
      return res.end("não encontrado");
    }
    res.writeHead(200, { "Content-Type": TIPOS[path.extname(arquivo)] ?? "application/octet-stream" });
    fs.createReadStream(arquivo).pipe(res);
  } catch (erro) {
    console.error(erro);
    if (!res.headersSent) json(res, 500, { erro: String(erro.message ?? erro) });
  }
});

// ---------- partida ----------

async function ollamaOnline() {
  try {
    return (await fetch(`${OLLAMA}/api/version`, { signal: AbortSignal.timeout(1500) })).ok;
  } catch {
    return false;
  }
}

if (lerConfig().provedorIA === "openai") {
  if (!variavelUsuario("OPENAI_API_KEY")) {
    await pedirChave("OPENAI_API_KEY", "O cérebro do JARVIS usa o ChatGPT. Crie uma chave em https://platform.openai.com/api-keys");
  }
} else {
  if (!(await ollamaOnline())) {
    console.log("Ligando o Ollama...");
    try {
      const filho = spawn("ollama", ["serve"], { detached: true, stdio: "ignore", windowsHide: true });
      filho.on("error", () => console.log("O Ollama não está instalado. Rode o instalar.bat ou baixe em https://ollama.com/download"));
      filho.unref();
    } catch {}
    for (let i = 0; i < 20 && !(await ollamaOnline()); i++) await new Promise((ok) => setTimeout(ok, 500));
    if (!(await ollamaOnline())) console.log("Não consegui ligar o Ollama. Abra o app do Ollama e tente de novo.");
  }
  // em outro PC o modelo pode ainda não ter sido baixado: baixa sozinho em segundo plano
  if (await ollamaOnline()) {
    try {
      const instalados = ((await (await fetch(`${OLLAMA}/api/tags`)).json()).models ?? []).map((m) => m.name);
      const cfg = lerConfig();
      for (const modelo of new Set([cfg.modeloOllama, cfg.modeloRapido].filter(Boolean))) {
        if (instalados.some((n) => n === modelo || n === `${modelo}:latest`)) continue;
        console.log(`Baixando o modelo ${modelo} (só na primeira vez, pode levar alguns minutos)...`);
        fetch(`${OLLAMA}/api/pull`, { method: "POST", body: JSON.stringify({ model: modelo, stream: false }) })
          .then(() => console.log(`Modelo ${modelo} pronto.`)).catch(() => console.log(`Falha ao baixar ${modelo}. Rode: ollama pull ${modelo}`));
      }
    } catch {}
  }
}
// a chave do Fish Audio é opcional (sem ela, o JARVIS usa a voz do Windows); só pergunta se pedirem
if (!variavelUsuario("FISH_API_KEY") && process.argv.includes("--configurar")) {
  await pedirChave("FISH_API_KEY", "A voz do JARVIS usa o Fish Audio. Crie uma chave grátis em https://fish.audio/app/api-keys");
}

servidor.listen(PORTA, "127.0.0.1", () => {
  const endereco = `http://localhost:${PORTA}`;
  console.log(`\n  J.A.R.V.I.S. online em ${endereco}\n  (deixe esta janela aberta; feche-a para desligar o JARVIS)\n`);
  if (!process.argv.includes("--sem-janela")) abrirJanela(endereco);
});

function abrirJanela(endereco) {
  // Edge/Chrome em modo app: janela sem barra de endereço e com reconhecimento de voz
  const candidatos = [
    path.join(process.env["ProgramFiles(x86)"] ?? "", "Microsoft\\Edge\\Application\\msedge.exe"),
    path.join(process.env.ProgramFiles ?? "", "Microsoft\\Edge\\Application\\msedge.exe"),
    path.join(process.env.ProgramFiles ?? "", "Google\\Chrome\\Application\\chrome.exe"),
    path.join(process.env.LOCALAPPDATA ?? "", "Google\\Chrome\\Application\\chrome.exe"),
  ];
  const nav = candidatos.find((c) => fs.existsSync(c));
  if (nav) spawn(nav, [`--app=${endereco}`, "--start-maximized"], { detached: true, stdio: "ignore" }).unref();
  else abrirUrl(endereco);
}
