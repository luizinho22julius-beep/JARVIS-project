@echo off
chcp 65001 >nul
title J.A.R.V.I.S.
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando componentes do JARVIS pela primeira vez...
  call npm install --no-audit --no-fund
)
node server.mjs
pause
