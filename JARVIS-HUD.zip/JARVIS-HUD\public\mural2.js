"use strict";
/* JARVIS — efeitos do mural: vinhetas de abertura, capítulo e encerramento, letreiro de notícias,
   textos-destaque com os nomes falados, zoom de foco e glitch nas telas. Envolve o iniciarPalco do script principal. */
(function efeitosDoMural() {
  const original = iniciarPalco;
  const limparPergunta = (t) => String(t || "").replace(/^\s*jarvis[,!.\s]*/i, "");
  const PALAVRAS_COMUNS = new Set(["Senhor", "Primeiro", "Depois", "Por", "Em", "No", "Na", "Nos", "Nas", "O", "A", "Os", "As", "Um", "Uma", "Isso", "Esse", "Essa", "Este", "Esta", "Ele", "Ela", "Eles", "Elas", "Mas", "E", "De", "Do", "Da", "Com", "Para", "Quando", "Hoje", "Assim", "Além", "Então", "Contudo", "Porém", "Também", "Durante", "Após", "Antes", "Finalmente", "Inicialmente", "Afinal", "Aqui"]);

  /** Nomes próprios da frase (sequências de palavras com maiúscula que não começam a frase). */
  function nomesDaFrase(texto) {
    const achados = [];
    const re = /(?:^|[^.!?…]\s)((?:[A-ZÁÉÍÓÚÂÊÔÃÕÇ][\p{L}'-]+)(?:\s(?:de|da|do|dos|das|von|van)?\s?[A-ZÁÉÍÓÚÂÊÔÃÕÇ][\p{L}'-]+)*)/gu;
    let m;
    while ((m = re.exec(texto))) {
      const nome = m[1].trim();
      if (nome.length > 3 && !PALAVRAS_COMUNS.has(nome.split(" ")[0]) && !achados.includes(nome)) achados.push(nome);
    }
    const anos = texto.match(/\b(1[0-9]{3}|20[0-9]{2})\b/g) ?? [];
    return [...anos, ...achados].slice(0, 2);
  }

  iniciarPalco = function (dados) {
    const controle = original(dados);
    const palco = $("palco");
    const monitor = palco.querySelector(".mu-monitor");
    const parede = palco.querySelector(".mu-parede");
    const timers = [];

    // vinheta de abertura
    const vinheta = criar("div", "mu-vinheta");
    vinheta.append(criar("div", "mu-vin-feixe"), criar("div", "mu-vin-logo", "J.A.R.V.I.S."), criar("div", "mu-vin-sub", "ANÁLISE EM ANDAMENTO"), criar("div", "mu-vin-titulo", limparPergunta(dados.pergunta)));
    palco.append(vinheta);
    timers.push(setTimeout(() => vinheta.remove(), 2600));

    // letreiro de notícias rolando embaixo do monitor
    const letreiro = criar("div", "mu-letreiro");
    const faixa = criar("div", "mu-letreiro-faixa");
    const itens = ["● AO VIVO · J.A.R.V.I.S.", ...dados.cenas.map((c, i) => `CAPÍTULO ${String(i + 1).padStart(2, "0")} · ${c.titulo.toUpperCase()}`)];
    faixa.textContent = [...itens, ...itens].join("     ◆     ");
    letreiro.append(criar("b", null, "ÚLTIMAS"), faixa);
    monitor.append(letreiro);

    // telas vivas: zoom de foco e glitch de vez em quando
    const telas = () => [...parede.querySelectorAll(".mu-tile")];
    timers.push(setInterval(() => {
      const t = telas()[Math.floor(Math.random() * 18)];
      if (!t) return;
      t.classList.add("foco"); setTimeout(() => t.classList.remove("foco"), 1500);
    }, 3800));
    timers.push(setInterval(() => {
      const t = telas()[Math.floor(Math.random() * 18)];
      if (!t) return;
      t.classList.add("glitch"); setTimeout(() => t.classList.remove("glitch"), 380);
    }, 1700));

    // vinheta de capítulo
    const irPara = controle.irPara;
    controle.irPara = (i) => {
      const novo = i !== controle._ultimo;
      irPara(i);
      if (!novo || i >= dados.cenas.length) return;
      controle._ultimo = i;
      if (i === 0) return; // o capítulo 1 entra junto com a vinheta de abertura
      const cartao = criar("div", "mu-capcard");
      cartao.append(criar("div", "mu-cap-num", String(i + 1).padStart(2, "0")), criar("div", "mu-cap-rotulo", "CAPÍTULO"), criar("div", "mu-cap-titulo", dados.cenas[i].titulo));
      monitor.append(cartao);
      setTimeout(() => cartao.remove(), 1900);
    };

    // textos-destaque com os nomes e anos que estão sendo falados
    controle.destacar = (trecho) => {
      nomesDaFrase(trecho).forEach((nome, k) => {
        setTimeout(() => {
          if (!parede.isConnected) return;
          const pop = criar("div", "mu-pop");
          pop.append(criar("i"), criar("span", null, nome.toUpperCase()));
          pop.style.left = `${8 + Math.random() * 62}%`;
          pop.style.top = `${10 + Math.random() * 70}%`;
          parede.append(pop);
          setTimeout(() => pop.classList.add("saindo"), 3600);
          setTimeout(() => pop.remove(), 4100);
        }, 600 + k * 1400);
      });
    };

    // vinheta de encerramento
    const encerrar = controle.encerrar;
    controle.encerrar = () => {
      timers.forEach((t) => { clearTimeout(t); clearInterval(t); });
      if (palco.isConnected && !palco.hidden) {
        const fim = criar("div", "mu-vinheta mu-fim");
        fim.append(criar("div", "mu-vin-feixe"), criar("div", "mu-vin-logo", "ANÁLISE CONCLUÍDA"), criar("div", "mu-vin-sub", "J.A.R.V.I.S."));
        palco.append(fim);
      }
      encerrar();
    };
    return controle;
  };
})();
