# JARVIS — modelos 3D reais e gratuitos do Sketchfab (licenças Creative Commons).
# Busca é aberta; baixar exige o token gratuito da conta (variável de usuário SKETCHFAB_TOKEN).
# Os arquivos ficam em cache em ~/JARVIS-Projetos/assets/sketchfab e os créditos em CREDITOS.txt.
import json
import os
import re
import urllib.parse
import urllib.request

API = "https://api.sketchfab.com/v3"
AGENTE = "JARVIS-HUD/1.0 (assistente local)"
PASTA = os.path.join(os.path.expanduser("~"), "JARVIS-Projetos", "assets", "sketchfab")
LICENCA_OK = re.compile(r"^CC", re.I)  # CC0 e todas as Creative Commons (uso pessoal)
# fora: pacotes/cenas e estilos que não parecem reais
ESTILO_RUIM = re.compile(r"low.?poly|cartoon|toon|stylized|stylised|voxel|pixel|burn|dirty|rust|wreck|destroyed|damaged|abandoned|toy|lego|minecraft", re.I)
PACOTE = re.compile(r"\b(pack|kit|collection|bundle|asset ?set|mega ?set)\b", re.I)
MILITAR = re.compile(r"military|armou?red|tank|apc|vehicles|series|mrap|army|war", re.I)
EVITAR = re.compile(r"\b(pack|kit|collection|scene|city|set|parts|interior only|wheel only|rig only|road|diorama|island|environment|landscape|garage|street|parking|showroom)\b", re.I)


def token():
    valor = os.environ.get("SKETCHFAB_TOKEN", "").strip()
    if not valor and os.name == "nt":  # lê direto do registro: funciona sem reiniciar o JARVIS
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as chave:
                valor = str(winreg.QueryValueEx(chave, "SKETCHFAB_TOKEN")[0]).strip()
        except OSError:
            valor = ""
    return valor


def _json(url, autenticar=False):
    cabecalhos = {"User-Agent": AGENTE}
    if autenticar:
        cabecalhos["Authorization"] = "Token " + token()
    with urllib.request.urlopen(urllib.request.Request(url, headers=cabecalhos), timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def buscar(busca, max_faces=600000, quantidade=48, min_faces=40000, categoria=None, exigir=None, estrito=True):
    """Modelos baixáveis e gratuitos, do mais curtido para o menos.
    Sempre fora: pacotes. Com categoria (carros): fora cenários e militares. estrito: fora estilos não realistas."""
    parametros = urllib.parse.urlencode({"type": "models", "q": busca, "downloadable": "true", "count": quantidade,
                                         "sort_by": "-likeCount", "max_face_count": max_faces, "min_face_count": min_faces,
                                         **({"categories": categoria} if categoria else {})})
    resultados = _json(f"{API}/search?{parametros}").get("results", [])
    bons = []
    for m in resultados:
        licenca = (m.get("license") or {}).get("label", "")
        nome = m.get("name", "")
        if not LICENCA_OK.search(licenca) or PACOTE.search(nome):
            continue
        if categoria and (EVITAR.search(nome) or MILITAR.search(nome)):
            continue
        if estrito and ESTILO_RUIM.search(nome):
            continue
        if exigir:  # o tipo pedido tem que aparecer no nome ou nas etiquetas
            etiquetas = " ".join(t.get("name", "") if isinstance(t, dict) else str(t) for t in m.get("tags", []))
            if not re.search(exigir, nome + " " + etiquetas, re.I):
                continue
        if not m.get("faceCount") or m["faceCount"] > max_faces:
            continue
        bons.append(m)
    return bons


def baixar(modelo):
    """Baixa o .glb do modelo (uma vez só) e registra o crédito exigido pela licença."""
    uid = modelo["uid"]
    destino = os.path.join(PASTA, uid + ".glb")
    if os.path.exists(destino) and os.path.getsize(destino) > 0:
        return destino
    if not token():
        raise RuntimeError("falta o token gratuito do Sketchfab (variável SKETCHFAB_TOKEN)")
    links = _json(f"{API}/models/{uid}/download", autenticar=True)
    glb = links.get("glb")
    if not glb:
        raise RuntimeError("modelo sem versão .glb: " + uid)
    if glb.get("size", 0) > 60 * 1024 * 1024:
        raise RuntimeError("modelo grande demais: " + uid)
    os.makedirs(PASTA, exist_ok=True)
    temporario = destino + ".parcial"
    with urllib.request.urlopen(urllib.request.Request(glb["url"], headers={"User-Agent": AGENTE}), timeout=180) as r, open(temporario, "wb") as f:
        while True:
            bloco = r.read(1 << 16)
            if not bloco:
                break
            f.write(bloco)
    os.replace(temporario, destino)
    autor = (modelo.get("user") or {}).get("displayName", "?")
    licenca = (modelo.get("license") or {}).get("label", "?")
    with open(os.path.join(PASTA, "CREDITOS.txt"), "a", encoding="utf-8") as f:
        f.write(f"{modelo.get('name')} — por {autor} — {licenca} — https://sketchfab.com/3d-models/{uid}\n")
    return destino


VARIANTES = ("skeleton", "skull", "bone", "anatomy", "statue", "sculpture", "bust", "figurine", "toy", "scene", "diorama",
             "collection", "showcase", "display", "room", "interior", "head", "rig", "animated", "animation", "pose", "fan art",
             "chibi", "cute", "miniature", "model kit", "papercraft", "skin", "wip", "test", "broken", "ruin",
             # peças avulsas em vez da coisa inteira
             "tire", "tyre", "wheel", "rim", "engine", "part", "helmet", "seat", "headlight", "exhaust", "door", "interior",
             "cockpit", "steering", "brake", "glove", "logo", "emblem", "texture", "material", "hdri")
VAZIAS = {"the", "and", "with", "model", "for", "free", "low", "high", "poly", "realistic", "old", "new"}


def _relevancia(m, palavras):
    """Quantas palavras da busca aparecem no nome (vale mais) e nas etiquetas do modelo."""
    nome = m.get("name", "").lower()
    etiquetas = " ".join(t.get("name", "") if isinstance(t, dict) else str(t) for t in m.get("tags", [])).lower()
    no_nome = sum(1 for p in palavras if re.search(r"\b" + re.escape(p), nome))
    nas_etiquetas = sum(1 for p in palavras if re.search(r"\b" + re.escape(p), etiquetas))
    return no_nome, nas_etiquetas


def obter(busca, max_faces=400000, categoria=None, exigir=None):
    """Busca e baixa o melhor modelo; devolve (caminho do .glb, informações do modelo).
    Ordem: o nome tem que bater com a busca; depois os mais detalhados/realistas; desempate pelas curtidas."""
    palavras = [p for p in re.findall(r"[a-z0-9]+", busca.lower()) if len(p) > 2 and p not in VAZIAS] or [busca.lower()]
    erros = []
    candidatos = []
    for filtros in ({"min_faces": 30000}, {"min_faces": 0}, {"min_faces": 0, "estrito": False}):
        lista = buscar(busca, max_faces, categoria=categoria, exigir=exigir, **filtros)
        if exigir and lista:  # carros: o filtro do tipo já garante a relevância
            candidatos = lista
            break
        def chave(item):
            (no_nome, nas_etiquetas), m = item
            nome = m.get("name", "").lower()
            # variantes que quase nunca são o que se quer, a menos que a busca peça
            ruim = sum(1 for v in VARIANTES if v in nome and v not in busca.lower())
            sobra = len(re.findall(r"[a-z]{3,}", nome)) - no_nome  # nomes curtos e diretos primeiro
            return (-no_nome, ruim, -nas_etiquetas, min(sobra, 6) // 2, -(m.get("likeCount") or 0))
        com_nota = sorted(((_relevancia(m, palavras), m) for m in lista), key=chave)
        if com_nota and com_nota[0][0][0] > 0:  # achou modelos cujo NOME bate com o pedido
            candidatos = [m for nota, m in com_nota if nota[0] > 0]
            break
        if not candidatos and com_nota:
            candidatos = [m for _, m in com_nota]  # guarda como reserva
    for m in candidatos[:4]:
        try:
            return baixar(m), m
        except Exception as erro:
            erros.append(f"{m.get('name')}: {erro}")
            if "token" in str(erro):
                break
    raise RuntimeError(f"nenhum modelo do Sketchfab para '{busca}'. " + " | ".join(erros))
