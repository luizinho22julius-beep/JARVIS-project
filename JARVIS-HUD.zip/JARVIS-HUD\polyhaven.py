# JARVIS — recursos reais e gratuitos (CC0) do Poly Haven: fundos HDRI de fotos reais, texturas PBR
# escaneadas e objetos 3D escaneados. Tudo fica em cache em ~/JARVIS-Projetos/assets (baixa uma vez só).
import json
import os
import re
import time
import urllib.request

API = "https://api.polyhaven.com"
AGENTE = "JARVIS-HUD/1.0 (assistente local)"
CACHE = os.path.join(os.path.expanduser("~"), "JARVIS-Projetos", "assets")

# ambientes prontos: (HDRI, textura do chão, metros por repetição da textura)
AMBIENTES = {
    "estacionamento": ("suburban_parking_area", "asphalt_02", 3.0),
    "rua": ("wide_street_01", "asphalt_02", 3.0),
    "cidade": ("urban_street_01", "asphalt_02", 3.0),
    "garagem": ("parking_garage", "concrete_floor_02", 2.0),
    "estudio": ("blocky_photo_studio", None, 1.0),
    "campo": ("autumn_field", "aerial_grass_rock", 3.0),
    "floresta": ("autumn_forest_01", "forrest_ground_01", 2.0),
    "por_do_sol": ("belfast_sunset", "asphalt_02", 3.0),
    "noite": ("cobblestone_street_night", "cobblestone_floor_01", 2.0),
    "interior": ("art_studio", "wood_floor", 2.0),
}
SINONIMOS_AMBIENTE = {
    "parking": "estacionamento", "street": "rua", "city": "cidade", "urbano": "cidade", "estúdio": "estudio",
    "studio": "estudio", "garage": "garagem", "field": "campo", "grama": "campo", "fazenda": "campo",
    "forest": "floresta", "mata": "floresta", "pôr do sol": "por_do_sol", "sunset": "por_do_sol", "night": "noite",
    "casa": "interior", "sala": "interior", "quarto": "interior", "indoor": "interior",
}

# português -> palavras em inglês usadas nos nomes e etiquetas do Poly Haven
TRADUCAO = {
    "sofa": "sofa couch", "sofá": "sofa couch", "poltrona": "armchair chair", "cadeira": "chair", "banco": "stool bench",
    "mesa": "table", "escrivaninha": "desk", "cama": "bed", "estante": "shelf bookshelf", "prateleira": "shelf",
    "luminaria": "lamp", "luminária": "lamp", "abajur": "lamp", "lampada": "lamp light", "planta": "plant potted",
    "vaso": "vase pot plant", "arvore": "tree", "árvore": "tree", "arbusto": "bush shrub", "pedra": "rock stone",
    "rocha": "rock", "tronco": "log stump", "caixa": "box crate", "barril": "barrel", "garrafa": "bottle",
    "copo": "glass cup", "xicara": "cup mug", "caneca": "mug", "prato": "plate", "livro": "book", "relogio": "clock",
    "relógio": "clock", "tv": "television tv", "televisao": "television", "televisão": "television", "radio": "radio",
    "rádio": "radio", "camera": "camera", "câmera": "camera", "telefone": "phone", "computador": "computer",
    "ferramenta": "tool", "martelo": "hammer", "chave": "wrench key", "escada": "ladder stairs", "porta": "door",
    "janela": "window", "tapete": "rug carpet", "almofada": "pillow cushion", "fruta": "fruit", "comida": "food",
    "maca": "apple", "maçã": "apple", "banana": "banana", "pao": "bread", "pão": "bread", "bolo": "cake",
    "estatua": "statue bust", "estátua": "statue bust", "cone": "traffic cone", "hidrante": "hydrant",
    "lixeira": "trash bin", "bicicleta": "bicycle", "carrinho": "cart", "pneu": "tire wheel", "roda": "wheel",
    "carro coberto": "covered car", "capacete": "helmet", "espada": "sword", "machado": "axe", "lanterna": "lantern",
    "vela": "candle", "sapato": "shoe", "bota": "boot", "bola": "ball", "cogumelo": "mushroom", "flor": "flower",
    "palmeira": "palm", "cerca": "fence", "poste": "lamp post street", "hidrante": "hydrant", "balde": "bucket",
}

_memoria = {}


def _baixar(url, destino, tentativas=3):
    if os.path.exists(destino) and os.path.getsize(destino) > 0:
        return destino
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    temporario = destino + ".parcial"
    for t in range(tentativas):
        try:
            pedido = urllib.request.Request(url, headers={"User-Agent": AGENTE})
            with urllib.request.urlopen(pedido, timeout=60) as resposta, open(temporario, "wb") as arquivo:
                while True:
                    bloco = resposta.read(1 << 16)
                    if not bloco:
                        break
                    arquivo.write(bloco)
            os.replace(temporario, destino)
            return destino
        except Exception as erro:
            print("JARVIS_AVISO: download falhou", url, erro)
            time.sleep(1 + t)
    raise RuntimeError("não consegui baixar " + url)


def _api(caminho, validade=7 * 86400):
    if caminho in _memoria:
        return _memoria[caminho]
    arquivo = os.path.join(CACHE, "api", re.sub(r"[^\w]+", "_", caminho) + ".json")
    if not (os.path.exists(arquivo) and time.time() - os.path.getmtime(arquivo) < validade):
        try:
            if os.path.exists(arquivo):
                os.remove(arquivo)
            _baixar(API + caminho, arquivo)
        except Exception:
            if not os.path.exists(arquivo):
                raise
    with open(arquivo, encoding="utf-8") as f:
        dados = json.load(f)
    _memoria[caminho] = dados
    return dados


def hdri(id_hdri, resolucao="4k"):
    """Caminho local do HDRI (foto 360° real) — baixa na primeira vez."""
    arquivos = _api("/files/" + id_hdri)
    for r in (resolucao, "2k", "1k"):
        info = arquivos.get("hdri", {}).get(r, {}).get("hdr")
        if info:
            return _baixar(info["url"], os.path.join(CACHE, "hdri", f"{id_hdri}_{r}.hdr"))
    raise RuntimeError("HDRI sem arquivo: " + id_hdri)


def textura(id_textura, resolucao="2k"):
    """Mapas PBR de uma textura escaneada: {'cor', 'normal', 'rugosidade', 'metros'}."""
    arquivos = _api("/files/" + id_textura)
    info = _api("/info/" + id_textura)
    mapas = {}
    for chave, nomes in (("cor", ("Diffuse", "diffuse")), ("normal", ("nor_gl",)), ("rugosidade", ("Rough", "rough"))):
        for n in nomes:
            item = arquivos.get(n, {}).get(resolucao, {})
            item = item.get("jpg") or item.get("png")
            if item:
                mapas[chave] = _baixar(item["url"], os.path.join(CACHE, "texturas", id_textura, os.path.basename(item["url"])))
                break
    metros = (info.get("dimensions") or [2000])[0] / 1000.0
    mapas["metros"] = metros if metros > 0 else 2.0
    return mapas


def material_real(bpy, id_textura, nome=None, metros=None):
    """Material com fotos reais (cor, relevo e rugosidade), projetado em metros pelas coordenadas do objeto."""
    mapas = textura(id_textura)
    m = bpy.data.materials.new(nome or id_textura)
    try:
        m.use_nodes = True
    except Exception:
        pass
    arv = m.node_tree
    bsdf = arv.nodes.get("Principled BSDF")
    coord = arv.nodes.new("ShaderNodeTexCoord")
    mapa = arv.nodes.new("ShaderNodeMapping")
    s = 1.0 / (metros or mapas["metros"])
    mapa.inputs["Scale"].default_value = (s, s, s)
    arv.links.new(coord.outputs["Object"], mapa.inputs["Vector"])
    # anti-repetição: entorta as coordenadas com um ruído largo (as emendas deixam de formar grade)
    ruido = arv.nodes.new("ShaderNodeTexNoise")
    ruido.inputs["Scale"].default_value = 0.35
    arv.links.new(mapa.outputs["Vector"], ruido.inputs["Vector"])
    escala_ruido = arv.nodes.new("ShaderNodeVectorMath")
    escala_ruido.operation = "MULTIPLY_ADD"
    escala_ruido.inputs[1].default_value = (0.9, 0.9, 0.0)
    arv.links.new(ruido.outputs["Color"], escala_ruido.inputs[0])
    arv.links.new(mapa.outputs["Vector"], escala_ruido.inputs[2])
    vetor = escala_ruido.outputs["Vector"]

    def imagem(caminho, dados):
        no = arv.nodes.new("ShaderNodeTexImage")
        no.image = bpy.data.images.load(caminho, check_existing=True)
        if dados:
            no.image.colorspace_settings.name = "Non-Color"
        no.projection = "BOX"
        no.projection_blend = 0.2
        arv.links.new(vetor, no.inputs["Vector"])
        return no

    if "cor" in mapas:  # cor real com manchas largas de desgaste
        manchas = arv.nodes.new("ShaderNodeTexNoise")
        manchas.inputs["Scale"].default_value = 0.08
        arv.links.new(mapa.outputs["Vector"], manchas.inputs["Vector"])
        faixa = arv.nodes.new("ShaderNodeMapRange")
        faixa.inputs["To Min"].default_value = 0.75
        faixa.inputs["To Max"].default_value = 1.15
        arv.links.new(manchas.outputs["Fac"], faixa.inputs["Value"])
        tom = arv.nodes.new("ShaderNodeVectorMath")
        tom.operation = "SCALE"
        arv.links.new(imagem(mapas["cor"], False).outputs["Color"], tom.inputs[0])
        arv.links.new(faixa.outputs["Result"], tom.inputs["Scale"])
        arv.links.new(tom.outputs["Vector"], bsdf.inputs["Base Color"])
    if "rugosidade" in mapas:
        arv.links.new(imagem(mapas["rugosidade"], True).outputs["Color"], bsdf.inputs["Roughness"])
    if "normal" in mapas:
        nm = arv.nodes.new("ShaderNodeNormalMap")
        arv.links.new(imagem(mapas["normal"], True).outputs["Color"], nm.inputs["Color"])
        arv.links.new(nm.outputs["Normal"], bsdf.inputs["Normal"])
    return m


def _palavras(texto):
    return set(re.findall(r"[a-z0-9]+", texto.lower()))


def buscar_modelo(busca):
    """Acha o objeto escaneado que mais combina com a busca (português ou inglês)."""
    modelos = _api("/assets?t=models")
    busca = str(busca).lower().strip()
    if busca in modelos:
        return busca
    termos = set()
    for pt, en in TRADUCAO.items():
        if re.search(r"\b" + re.escape(pt) + r"s?\b", busca):
            termos |= _palavras(en)
    termos |= _palavras(busca)
    melhor, nota_max = None, 0.0
    for id_m, info in modelos.items():
        nome = _palavras(id_m.replace("_", " ") + " " + info.get("name", ""))
        etiquetas = _palavras(" ".join(info.get("tags", [])))
        categorias = _palavras(" ".join(info.get("categories", [])))
        nota = 3 * len(termos & nome) + 1.5 * len(termos & etiquetas) + len(termos & categorias)
        if nota:
            nota += min(info.get("download_count", 0), 50000) / 100000.0  # desempate: os mais populares
        if nota > nota_max:
            melhor, nota_max = id_m, nota
    return melhor


def modelo(id_modelo, resolucao="1k"):
    """Baixa o objeto escaneado (glTF + texturas) e devolve o caminho do .gltf."""
    arquivos = _api("/files/" + id_modelo)
    gltf = arquivos.get("gltf", {})
    for r in (resolucao, "2k", "4k"):
        info = gltf.get(r, {}).get("gltf")
        if info:
            pasta = os.path.join(CACHE, "modelos", id_modelo, r)
            for relativo, extra in info.get("include", {}).items():
                _baixar(extra["url"], os.path.join(pasta, relativo))
            return _baixar(info["url"], os.path.join(pasta, os.path.basename(info["url"])))
    raise RuntimeError("modelo sem glTF: " + id_modelo)
